import java.lang.Object;
import java.awt.Color;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import sun.util.logging.PlatformLogger;
import java.awt.*;
import javax.swing.*;
import javax.imageio.*;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import java.util.Arrays;
import java.awt.Desktop;
import java.net.URI;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dines
 */

 
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import AppPackage.AnimationClass;
import java.awt.geom.AffineTransform;

import java.util.TimerTask;
import javafx.animation.Animation;

public class index extends javax.swing.JFrame {

    /**
     * Creates new form index
     */
   // Thread t;
    
    Connection con;
Statement stmt;
static String movie="";
static String dhoni="";
static String watch_movie="";
static String watch_show="";
static int search_flag=0;

static int ram=0; 
    public index() {
        initComponents();
        Connect();
   
         
    }
    public index(String user_2)
    {
       initComponents();
       Connect();
       setExtendedState(JFrame.MAXIMIZED_BOTH);
       jLabel16.setText(user_2);
       JButton [] btn=new JButton[1000];
        btn[0]=jButton40;
        btn[1]=jButton56;
        btn[2]=jButton57;
        btn[3]=jButton58;
        btn[4]=jButton59;
        btn[5]=jButton60;
        JButton [] btn1=new JButton[1000];
        btn1[0]=jButton178;
        btn1[1]=jButton179;
        btn1[2]=jButton180;
        btn1[3]=jButton181;
        btn1[4]=jButton182;
       
        int p=0;
        String trump="movie";
      //  System.out.println("movie----->"+trump);
        String trump1="show";
        try
        {
            String sql=null;
            ResultSet res=null;
        try{
        sql="select * from my_list where users='"+user_2+"' and type='"+trump+"' ";
        res=stmt.executeQuery(sql);
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(this, "990.......");
        }
        while(res.next())
        {
            String list=res.getString("flick");
            String loc="C://Users//dines//Desktop//se7en//originals//";
                                    loc=loc+list+".png";
                                   // btn[p].setVisible(true);
                                    btn[p].setIcon(new ImageIcon(loc));
                                   // jButton43.setI
                                   btn[p].setText(list);
                                    p++;
                                    if(p>5)
                                    {
                                        break;
                                    }
        }
        p=0;
        sql="select * from my_list where users='"+user_2+"' and type='"+trump1+"'";
        res=stmt.executeQuery(sql);
        while(res.next())
        {
            String list=res.getString("flick");
            String list1[]=list.split(" [0-9]$");
            String loc="C://Users//dines//Desktop//se7en//originals//";
                                    loc=loc+list1[0]+".png";
                                   // btn[p].setVisible(true);
                                    btn1[p].setIcon(new ImageIcon(loc));
                                   // jButton43.setI
                                   btn1[p].setText(list);
                                    p++;
                                    if(p>4)
                                    {
                                        break;
                                    }
                                    
        }
        p=0;
        JButton [] btnx=new JButton[100];
         btnx[0]=jButton68;
        btnx[1]=jButton69;
        btnx[2]=jButton70;
        btnx[3]=jButton71;
        btnx[4]=jButton72;
        btnx[5]=jButton78;
        btnx[6]=jButton84;
        btnx[7]=jButton87;
        btnx[8]=jButton88;
        btnx[9]=jButton89;
        btnx[10]=jButton90;
        btnx[11]=jButton96;
        btnx[12]=jButton98;
        btnx[13]=jButton99;
        btnx[14]=jButton100;
        btnx[15]=jButton101;
        btnx[16]=jButton102;
        btnx[17]=jButton103;
        btnx[18]=jButton104;
        btnx[19]=jButton105;
        try{
        sql="select * from my_list where users='"+user_2+"' order by id desc";
        res=stmt.executeQuery(sql);
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(this, "2.fdgh......");
        }
        while(res.next())
        {
            String list=res.getString("flick");
            String list1[]=list.split(" [0-9]$");
           String loc="C://Users//dines//Desktop//se7en//originals//";
                                    loc=loc+list1[0]+".png";
                                   // btn[p].setVisible(true);
                                    btnx[p].setIcon(new ImageIcon(loc));
                                   // jButton43.setI
                                   btnx[p].setText(list);
                                    p++;
                                    ram++;
                                    if(p>19)
                                    {
                                        break;
                                    }
        }
                        for(int i=ram;i<20;i++)
                           {
                                btnx[i].setVisible(false);
                            }
        }
        catch(Exception ex)
        {
             JOptionPane.showMessageDialog(this,ex);
        }
        move_panel40();
    }
public void move_panel40()
{
    Thread th=new Thread()
    {
        @Override
        public void run()
        {
            jPanel40.setBounds(0,205,jPanel40.getWidth(),jPanel40.getHeight());
            
            try
            {
                int phd=0;
                while(phd<75)
                {
                        Thread.sleep(10);
                        jPanel40.setBounds(0,jPanel40.getY()+1,jPanel40.getWidth(),jPanel40.getHeight());
                        phd++;
                }
                
            }
           catch(Exception ex)
           {
               
           }
        }
        
    };th.start();
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
        public void Connect()
    {
        try
        {
      con=   DriverManager.getConnection("jdbc:mysql://localhost:3306/se7en","root","");
      stmt = con.createStatement();
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(this, "HERE");
        }
    }
        

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel15 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        search = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton222 = new javax.swing.JButton();
        jLabel40 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jPanel37 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jButton27 = new javax.swing.JButton();
        jButton28 = new javax.swing.JButton();
        jButton29 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jButton26 = new javax.swing.JButton();
        jButton106 = new javax.swing.JButton();
        jButton189 = new javax.swing.JButton();
        jButton190 = new javax.swing.JButton();
        jButton218 = new javax.swing.JButton();
        jLabel30 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jButton219 = new javax.swing.JButton();
        jButton220 = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jPasswordField1 = new javax.swing.JPasswordField();
        jPasswordField2 = new javax.swing.JPasswordField();
        jPasswordField3 = new javax.swing.JPasswordField();
        jLabel31 = new javax.swing.JLabel();
        jPanel40 = new javax.swing.JPanel();
        jPanel91 = new javax.swing.JPanel();
        jPanel92 = new javax.swing.JPanel();
        jPanel93 = new javax.swing.JPanel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jButton324 = new javax.swing.JButton();
        jPanel94 = new javax.swing.JPanel();
        jPanel95 = new javax.swing.JPanel();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jLabel105 = new javax.swing.JLabel();
        jButton327 = new javax.swing.JButton();
        jPanel96 = new javax.swing.JPanel();
        jPanel97 = new javax.swing.JPanel();
        jLabel80 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jLabel104 = new javax.swing.JLabel();
        jButton326 = new javax.swing.JButton();
        jPanel98 = new javax.swing.JPanel();
        jPanel99 = new javax.swing.JPanel();
        jLabel83 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabel103 = new javax.swing.JLabel();
        jButton323 = new javax.swing.JButton();
        jPanel100 = new javax.swing.JPanel();
        jPanel101 = new javax.swing.JPanel();
        jLabel86 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jLabel102 = new javax.swing.JLabel();
        jButton325 = new javax.swing.JButton();
        jPanel103 = new javax.swing.JPanel();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jLabel101 = new javax.swing.JLabel();
        jButton322 = new javax.swing.JButton();
        jPanel102 = new javax.swing.JPanel();
        jPanel105 = new javax.swing.JPanel();
        jLabel92 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        jButton321 = new javax.swing.JButton();
        jPanel104 = new javax.swing.JPanel();
        jPanel107 = new javax.swing.JPanel();
        jLabel95 = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        jLabel99 = new javax.swing.JLabel();
        jButton320 = new javax.swing.JButton();
        jPanel106 = new javax.swing.JPanel();
        jLabel98 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel30 = new javax.swing.JPanel();
        sarkar_wt8 = new javax.swing.JButton();
        sarkar_add_list8 = new javax.swing.JButton();
        sarkar_fav8 = new javax.swing.JButton();
        recom_panel = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jButton40 = new javax.swing.JButton();
        jButton56 = new javax.swing.JButton();
        jButton57 = new javax.swing.JButton();
        jButton58 = new javax.swing.JButton();
        jButton59 = new javax.swing.JButton();
        jButton60 = new javax.swing.JButton();
        jPanel55 = new javax.swing.JPanel();
        jButton62 = new javax.swing.JButton();
        jButton63 = new javax.swing.JButton();
        jButton64 = new javax.swing.JButton();
        jButton65 = new javax.swing.JButton();
        jButton66 = new javax.swing.JButton();
        jButton67 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        rom_com_panel = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jButton9 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        sarkar = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jButton12 = new javax.swing.JButton();
        jPanel54 = new javax.swing.JPanel();
        recom_btn1 = new javax.swing.JButton();
        recom_btn2 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        rom_com_btn1 = new javax.swing.JButton();
        rom_com_btn2 = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        action_panel = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jButton13 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        sarkar1 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jPanel21 = new javax.swing.JPanel();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        sarkar2 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jPanel26 = new javax.swing.JPanel();
        action_btn1 = new javax.swing.JButton();
        action_btn2 = new javax.swing.JButton();
        thriller_panel = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        sarkar3 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jButton22 = new javax.swing.JButton();
        jPanel33 = new javax.swing.JPanel();
        jButton23 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        sarkar4 = new javax.swing.JButton();
        jPanel39 = new javax.swing.JPanel();
        thriller_btn1 = new javax.swing.JButton();
        thriller_btn2 = new javax.swing.JButton();
        jButton61 = new javax.swing.JButton();
        jButton34 = new javax.swing.JButton();
        jButton33 = new javax.swing.JButton();
        jButton32 = new javax.swing.JButton();
        jButton31 = new javax.swing.JButton();
        jButton25 = new javax.swing.JButton();
        drama_panel = new javax.swing.JPanel();
        jPanel47 = new javax.swing.JPanel();
        jButton91 = new javax.swing.JButton();
        jButton92 = new javax.swing.JButton();
        jButton93 = new javax.swing.JButton();
        jButton94 = new javax.swing.JButton();
        jButton95 = new javax.swing.JButton();
        jPanel44 = new javax.swing.JPanel();
        jButton97 = new javax.swing.JButton();
        jPanel48 = new javax.swing.JPanel();
        scifi_btn1 = new javax.swing.JButton();
        scifi_btn2 = new javax.swing.JButton();
        jPanel42 = new javax.swing.JPanel();
        drama_btn1 = new javax.swing.JButton();
        drama_btn2 = new javax.swing.JButton();
        scifi_panel = new javax.swing.JPanel();
        jPanel46 = new javax.swing.JPanel();
        jButton79 = new javax.swing.JButton();
        jButton80 = new javax.swing.JButton();
        jButton81 = new javax.swing.JButton();
        jButton82 = new javax.swing.JButton();
        jButton83 = new javax.swing.JButton();
        jPanel43 = new javax.swing.JPanel();
        jButton85 = new javax.swing.JButton();
        jButton86 = new javax.swing.JButton();
        horror_panel = new javax.swing.JPanel();
        jPanel45 = new javax.swing.JPanel();
        jButton73 = new javax.swing.JButton();
        jButton74 = new javax.swing.JButton();
        jButton75 = new javax.swing.JButton();
        jButton76 = new javax.swing.JButton();
        jButton77 = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        jPanel89 = new javax.swing.JPanel();
        jPanel53 = new javax.swing.JPanel();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jPanel88 = new javax.swing.JPanel();
        jPanel52 = new javax.swing.JPanel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jPanel87 = new javax.swing.JPanel();
        jPanel51 = new javax.swing.JPanel();
        jLabel65 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jPanel86 = new javax.swing.JPanel();
        jPanel50 = new javax.swing.JPanel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jPanel85 = new javax.swing.JPanel();
        jPanel49 = new javax.swing.JPanel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jPanel75 = new javax.swing.JPanel();
        jPanel36 = new javax.swing.JPanel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jPanel84 = new javax.swing.JPanel();
        jPanel34 = new javax.swing.JPanel();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jPanel90 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jPanel35 = new javax.swing.JPanel();
        sug1 = new javax.swing.JButton();
        sug2 = new javax.swing.JButton();
        sug3 = new javax.swing.JButton();
        jLabel51 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jButton224 = new javax.swing.JButton();
        jButton227 = new javax.swing.JButton();
        jButton228 = new javax.swing.JButton();
        jButton229 = new javax.swing.JButton();
        jButton230 = new javax.swing.JButton();
        jButton225 = new javax.swing.JButton();
        jButton226 = new javax.swing.JButton();
        jPanel16 = new javax.swing.JPanel();
        jButton231 = new javax.swing.JButton();
        jButton232 = new javax.swing.JButton();
        jButton233 = new javax.swing.JButton();
        jButton234 = new javax.swing.JButton();
        jButton235 = new javax.swing.JButton();
        jPanel19 = new javax.swing.JPanel();
        jButton248 = new javax.swing.JButton();
        jButton249 = new javax.swing.JButton();
        jButton250 = new javax.swing.JButton();
        jButton251 = new javax.swing.JButton();
        jButton252 = new javax.swing.JButton();
        jButton253 = new javax.swing.JButton();
        jButton254 = new javax.swing.JButton();
        jPanel20 = new javax.swing.JPanel();
        jButton255 = new javax.swing.JButton();
        jButton256 = new javax.swing.JButton();
        jButton257 = new javax.swing.JButton();
        jButton258 = new javax.swing.JButton();
        jButton259 = new javax.swing.JButton();
        jPanel17 = new javax.swing.JPanel();
        jButton236 = new javax.swing.JButton();
        jButton237 = new javax.swing.JButton();
        jButton238 = new javax.swing.JButton();
        jButton239 = new javax.swing.JButton();
        jButton240 = new javax.swing.JButton();
        jButton241 = new javax.swing.JButton();
        jButton242 = new javax.swing.JButton();
        jPanel18 = new javax.swing.JPanel();
        jButton243 = new javax.swing.JButton();
        jButton244 = new javax.swing.JButton();
        jButton245 = new javax.swing.JButton();
        jButton246 = new javax.swing.JButton();
        jButton247 = new javax.swing.JButton();
        jPanel22 = new javax.swing.JPanel();
        jButton260 = new javax.swing.JButton();
        jButton261 = new javax.swing.JButton();
        jButton262 = new javax.swing.JButton();
        jButton263 = new javax.swing.JButton();
        jButton264 = new javax.swing.JButton();
        jButton265 = new javax.swing.JButton();
        jButton266 = new javax.swing.JButton();
        jPanel23 = new javax.swing.JPanel();
        jButton267 = new javax.swing.JButton();
        jButton268 = new javax.swing.JButton();
        jButton269 = new javax.swing.JButton();
        jButton270 = new javax.swing.JButton();
        jButton271 = new javax.swing.JButton();
        jPanel24 = new javax.swing.JPanel();
        jButton272 = new javax.swing.JButton();
        jButton273 = new javax.swing.JButton();
        jButton274 = new javax.swing.JButton();
        jButton275 = new javax.swing.JButton();
        jButton276 = new javax.swing.JButton();
        jPanel25 = new javax.swing.JPanel();
        jButton277 = new javax.swing.JButton();
        jButton278 = new javax.swing.JButton();
        jButton279 = new javax.swing.JButton();
        jButton280 = new javax.swing.JButton();
        jButton281 = new javax.swing.JButton();
        jButton282 = new javax.swing.JButton();
        jButton283 = new javax.swing.JButton();
        jPanel28 = new javax.swing.JPanel();
        jButton284 = new javax.swing.JButton();
        jButton285 = new javax.swing.JButton();
        jButton286 = new javax.swing.JButton();
        jButton287 = new javax.swing.JButton();
        jButton288 = new javax.swing.JButton();
        jPanel29 = new javax.swing.JPanel();
        jButton289 = new javax.swing.JButton();
        jButton290 = new javax.swing.JButton();
        jButton291 = new javax.swing.JButton();
        jButton292 = new javax.swing.JButton();
        jButton293 = new javax.swing.JButton();
        jButton294 = new javax.swing.JButton();
        jButton295 = new javax.swing.JButton();
        jPanel32 = new javax.swing.JPanel();
        jButton301 = new javax.swing.JButton();
        jButton302 = new javax.swing.JButton();
        jButton303 = new javax.swing.JButton();
        jButton304 = new javax.swing.JButton();
        jButton305 = new javax.swing.JButton();
        jLabel48 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jPanel58 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jPanel57 = new javax.swing.JPanel();
        jButton108 = new javax.swing.JButton();
        jButton127 = new javax.swing.JButton();
        jButton128 = new javax.swing.JButton();
        jPanel59 = new javax.swing.JPanel();
        jButton109 = new javax.swing.JButton();
        jButton110 = new javax.swing.JButton();
        jButton111 = new javax.swing.JButton();
        jButton112 = new javax.swing.JButton();
        jButton113 = new javax.swing.JButton();
        jButton114 = new javax.swing.JButton();
        jButton115 = new javax.swing.JButton();
        jButton116 = new javax.swing.JButton();
        jButton117 = new javax.swing.JButton();
        jPanel74 = new javax.swing.JPanel();
        jButton163 = new javax.swing.JButton();
        jButton164 = new javax.swing.JButton();
        jButton165 = new javax.swing.JButton();
        jButton166 = new javax.swing.JButton();
        jButton167 = new javax.swing.JButton();
        jButton168 = new javax.swing.JButton();
        jButton169 = new javax.swing.JButton();
        jButton170 = new javax.swing.JButton();
        jButton171 = new javax.swing.JButton();
        ep_btn4 = new javax.swing.JButton();
        ep_btn3 = new javax.swing.JButton();
        jPanel60 = new javax.swing.JPanel();
        jButton118 = new javax.swing.JButton();
        jButton119 = new javax.swing.JButton();
        jButton120 = new javax.swing.JButton();
        jButton121 = new javax.swing.JButton();
        jButton122 = new javax.swing.JButton();
        jButton123 = new javax.swing.JButton();
        jButton124 = new javax.swing.JButton();
        jButton125 = new javax.swing.JButton();
        jButton126 = new javax.swing.JButton();
        ep_btn2 = new javax.swing.JButton();
        ep_btn1 = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        thriller_show = new javax.swing.JPanel();
        jPanel62 = new javax.swing.JPanel();
        jButton132 = new javax.swing.JButton();
        jButton131 = new javax.swing.JButton();
        jButton130 = new javax.swing.JButton();
        jButton129 = new javax.swing.JButton();
        jButton107 = new javax.swing.JButton();
        jPanel63 = new javax.swing.JPanel();
        drama_show = new javax.swing.JPanel();
        jPanel64 = new javax.swing.JPanel();
        jButton133 = new javax.swing.JButton();
        jButton134 = new javax.swing.JButton();
        jButton135 = new javax.swing.JButton();
        jButton136 = new javax.swing.JButton();
        jButton137 = new javax.swing.JButton();
        jPanel65 = new javax.swing.JPanel();
        crime_show = new javax.swing.JPanel();
        jPanel67 = new javax.swing.JPanel();
        jButton143 = new javax.swing.JButton();
        jButton144 = new javax.swing.JButton();
        jButton145 = new javax.swing.JButton();
        jButton146 = new javax.swing.JButton();
        jButton147 = new javax.swing.JButton();
        jPanel68 = new javax.swing.JPanel();
        top10_show = new javax.swing.JPanel();
        jPanel71 = new javax.swing.JPanel();
        jButton153 = new javax.swing.JButton();
        jButton154 = new javax.swing.JButton();
        jButton155 = new javax.swing.JButton();
        jButton156 = new javax.swing.JButton();
        jButton157 = new javax.swing.JButton();
        jPanel72 = new javax.swing.JPanel();
        jButton158 = new javax.swing.JButton();
        jButton159 = new javax.swing.JButton();
        jButton160 = new javax.swing.JButton();
        jButton161 = new javax.swing.JButton();
        jButton162 = new javax.swing.JButton();
        comedy_show = new javax.swing.JPanel();
        jPanel69 = new javax.swing.JPanel();
        jButton148 = new javax.swing.JButton();
        jButton149 = new javax.swing.JButton();
        jButton150 = new javax.swing.JButton();
        jButton151 = new javax.swing.JButton();
        jButton152 = new javax.swing.JButton();
        jPanel70 = new javax.swing.JPanel();
        scifi_show = new javax.swing.JPanel();
        jPanel66 = new javax.swing.JPanel();
        jButton138 = new javax.swing.JButton();
        jButton139 = new javax.swing.JButton();
        jButton140 = new javax.swing.JButton();
        jButton141 = new javax.swing.JButton();
        jButton142 = new javax.swing.JButton();
        jPanel61 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jPanel78 = new javax.swing.JPanel();
        recomshow_btn1 = new javax.swing.JButton();
        recomshow_btn2 = new javax.swing.JButton();
        jPanel73 = new javax.swing.JPanel();
        top10_btn1 = new javax.swing.JButton();
        top10_btn2 = new javax.swing.JButton();
        jButton172 = new javax.swing.JButton();
        jButton173 = new javax.swing.JButton();
        jButton174 = new javax.swing.JButton();
        jButton175 = new javax.swing.JButton();
        jButton176 = new javax.swing.JButton();
        jButton177 = new javax.swing.JButton();
        recom_show = new javax.swing.JPanel();
        jPanel77 = new javax.swing.JPanel();
        jButton183 = new javax.swing.JButton();
        jButton184 = new javax.swing.JButton();
        jButton185 = new javax.swing.JButton();
        jButton186 = new javax.swing.JButton();
        jButton187 = new javax.swing.JButton();
        jPanel76 = new javax.swing.JPanel();
        jButton178 = new javax.swing.JButton();
        jButton179 = new javax.swing.JButton();
        jButton180 = new javax.swing.JButton();
        jButton181 = new javax.swing.JButton();
        jButton182 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jPanel56 = new javax.swing.JPanel();
        jButton68 = new javax.swing.JButton();
        jButton69 = new javax.swing.JButton();
        jButton70 = new javax.swing.JButton();
        jButton71 = new javax.swing.JButton();
        jButton72 = new javax.swing.JButton();
        jButton78 = new javax.swing.JButton();
        jButton84 = new javax.swing.JButton();
        jButton87 = new javax.swing.JButton();
        jButton88 = new javax.swing.JButton();
        jButton89 = new javax.swing.JButton();
        jButton90 = new javax.swing.JButton();
        jButton96 = new javax.swing.JButton();
        jButton98 = new javax.swing.JButton();
        jButton99 = new javax.swing.JButton();
        jButton100 = new javax.swing.JButton();
        jButton101 = new javax.swing.JButton();
        jButton102 = new javax.swing.JButton();
        jButton103 = new javax.swing.JButton();
        jButton104 = new javax.swing.JButton();
        jButton105 = new javax.swing.JButton();
        jPanel79 = new javax.swing.JPanel();
        jButton188 = new javax.swing.JButton();
        jPanel80 = new javax.swing.JPanel();
        jButton191 = new javax.swing.JButton();
        jButton192 = new javax.swing.JButton();
        jButton193 = new javax.swing.JButton();
        jButton194 = new javax.swing.JButton();
        jButton195 = new javax.swing.JButton();
        jButton196 = new javax.swing.JButton();
        jButton197 = new javax.swing.JButton();
        jButton198 = new javax.swing.JButton();
        jButton199 = new javax.swing.JButton();
        jPanel81 = new javax.swing.JPanel();
        jButton200 = new javax.swing.JButton();
        jButton201 = new javax.swing.JButton();
        jButton202 = new javax.swing.JButton();
        jButton203 = new javax.swing.JButton();
        jButton204 = new javax.swing.JButton();
        jButton205 = new javax.swing.JButton();
        jButton206 = new javax.swing.JButton();
        jButton207 = new javax.swing.JButton();
        jButton208 = new javax.swing.JButton();
        ep_btn5 = new javax.swing.JButton();
        ep_btn6 = new javax.swing.JButton();
        jPanel82 = new javax.swing.JPanel();
        jButton209 = new javax.swing.JButton();
        jButton210 = new javax.swing.JButton();
        jButton211 = new javax.swing.JButton();
        jButton212 = new javax.swing.JButton();
        jButton213 = new javax.swing.JButton();
        jButton214 = new javax.swing.JButton();
        jButton215 = new javax.swing.JButton();
        jButton216 = new javax.swing.JButton();
        jButton217 = new javax.swing.JButton();
        ep_btn7 = new javax.swing.JButton();
        ep_btn8 = new javax.swing.JButton();
        jPanel38 = new javax.swing.JPanel();
        jButton30 = new javax.swing.JButton();
        jButton35 = new javax.swing.JButton();
        jButton36 = new javax.swing.JButton();
        jButton38 = new javax.swing.JButton();
        jButton39 = new javax.swing.JButton();
        jButton41 = new javax.swing.JButton();
        jButton42 = new javax.swing.JButton();
        jButton43 = new javax.swing.JButton();
        jButton44 = new javax.swing.JButton();
        jButton45 = new javax.swing.JButton();
        jButton46 = new javax.swing.JButton();
        jButton47 = new javax.swing.JButton();
        jButton48 = new javax.swing.JButton();
        jButton49 = new javax.swing.JButton();
        jButton50 = new javax.swing.JButton();
        jButton51 = new javax.swing.JButton();
        jButton52 = new javax.swing.JButton();
        jButton53 = new javax.swing.JButton();
        jButton54 = new javax.swing.JButton();
        jButton55 = new javax.swing.JButton();
        jPanel41 = new javax.swing.JPanel();
        search_wt = new javax.swing.JButton();
        search_add_list = new javax.swing.JButton();
        search_fav = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jButton37 = new javax.swing.JButton();
        jPanel83 = new javax.swing.JPanel();
        jButton223 = new javax.swing.JButton();
        jButton296 = new javax.swing.JButton();
        jButton297 = new javax.swing.JButton();
        jButton298 = new javax.swing.JButton();
        jButton299 = new javax.swing.JButton();
        jButton300 = new javax.swing.JButton();
        jButton306 = new javax.swing.JButton();
        jButton307 = new javax.swing.JButton();
        jButton308 = new javax.swing.JButton();
        jButton309 = new javax.swing.JButton();
        jButton310 = new javax.swing.JButton();
        jButton311 = new javax.swing.JButton();
        jButton312 = new javax.swing.JButton();
        jButton313 = new javax.swing.JButton();
        jButton314 = new javax.swing.JButton();
        jButton315 = new javax.swing.JButton();
        jButton316 = new javax.swing.JButton();
        jButton317 = new javax.swing.JButton();
        jButton318 = new javax.swing.JButton();
        jButton319 = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jButton221 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        getContentPane().setLayout(null);

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane2.setPreferredSize(new java.awt.Dimension(2200, 5800));

        jPanel15.setBackground(new java.awt.Color(0, 0, 0));
        jPanel15.setPreferredSize(new java.awt.Dimension(2100, 4790));
        jPanel15.setLayout(new java.awt.GridLayout(1, 0));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(null);

        jButton6.setBackground(new java.awt.Color(255, 153, 0));
        jButton6.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("SEARCH");
        jButton6.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(255, 51, 51)));
        jButton6.setContentAreaFilled(false);
        jButton6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton6);
        jButton6.setBounds(1130, 210, 90, 40);

        jButton1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("MOVIES");
        jButton1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 0, 0)));
        jButton1.setContentAreaFilled(false);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(570, 140, 100, 40);

        search.setBackground(new java.awt.Color(0, 0, 0));
        search.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        search.setForeground(new java.awt.Color(255, 255, 255));
        search.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        jPanel1.add(search);
        search.setBounds(710, 210, 510, 40);

        jButton3.setBackground(new java.awt.Color(0, 0, 0));
        jButton3.setFont(new java.awt.Font("Bahnschrift", 0, 22)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 0));
        jButton3.setText("PLANET");
        jButton3.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 2, 0, 2, new java.awt.Color(255, 153, 0)));
        jButton3.setContentAreaFilled(false);
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.setOpaque(true);
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton3MouseExited(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3);
        jButton3.setBounds(880, 140, 140, 30);

        jButton4.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("SUGGEST ME");
        jButton4.setContentAreaFilled(false);
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4);
        jButton4.setBounds(1050, 140, 153, 40);

        jButton2.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("TV SHOWS");
        jButton2.setContentAreaFilled(false);
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(710, 140, 130, 40);

        jButton222.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jButton222.setForeground(new java.awt.Color(255, 255, 255));
        jButton222.setText("COMING SOON");
        jButton222.setContentAreaFilled(false);
        jButton222.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton222.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton222ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton222);
        jButton222.setBounds(1340, 140, 170, 40);

        jLabel40.setVisible(false);
        jLabel40.setFont(new java.awt.Font("AMORICA SANS", 0, 80)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 0, 51));
        jLabel40.setText("7");
        jPanel1.add(jLabel40);
        jLabel40.setBounds(940, 115, 40, 80);

        jLabel39.setFont(new java.awt.Font("AMORICA SANS Stroke", 0, 80)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 0, 51));
        jLabel39.setText("7");
        jPanel1.add(jLabel39);
        jLabel39.setBounds(940, 115, 40, 80);

        jButton5.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("LATEST");
        jButton5.setContentAreaFilled(false);
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5);
        jButton5.setBounds(1220, 140, 110, 40);

        jPanel37.setBackground(new java.awt.Color(0, 0, 0));
        jPanel37.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(0, 153, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.RIGHT, javax.swing.border.TitledBorder.ABOVE_TOP, new java.awt.Font("Tahoma", 0, 13), new java.awt.Color(255, 153, 102))); // NOI18N
        jPanel2.setLayout(null);

        jLabel2.setFont(new java.awt.Font("AMORICA SANS Stroke", 0, 40)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("S E       E N");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(210, 20, 190, 40);

        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-play-70 - Copy.png")); // NOI18N
        jPanel2.add(jLabel3);
        jLabel3.setBounds(490, 0, 70, 70);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\icons8-vintage-camera-48.png")); // NOI18N
        jPanel2.add(jLabel1);
        jLabel1.setBounds(150, 10, 50, 50);

        jLabel12.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\icons8-film-reel-64.png")); // NOI18N
        jLabel12.setAlignmentY(0.8F);
        jPanel2.add(jLabel12);
        jLabel12.setBounds(255, 6, 60, 60);

        jLabel13.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-play-70.png")); // NOI18N
        jPanel2.add(jLabel13);
        jLabel13.setBounds(-20, 0, 70, 70);

        jPanel37.add(jPanel2);
        jPanel2.setBounds(670, 0, 540, 70);

        jButton27.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jButton27.setForeground(new java.awt.Color(255, 255, 255));
        jButton27.setText("WATCH LIST");
        jButton27.setContentAreaFilled(false);
        jButton27.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton27ActionPerformed(evt);
            }
        });
        jPanel37.add(jButton27);
        jButton27.setBounds(1390, 20, 150, 27);

        jButton28.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jButton28.setForeground(new java.awt.Color(255, 255, 255));
        jButton28.setText("MY FAV");
        jButton28.setContentAreaFilled(false);
        jButton28.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });
        jPanel37.add(jButton28);
        jButton28.setBounds(1580, 20, 110, 27);

        jButton29.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-menu-36.png")); // NOI18N
        jButton29.setContentAreaFilled(false);
        jButton29.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton29ActionPerformed(evt);
            }
        });
        jPanel37.add(jButton29);
        jButton29.setBounds(1840, 10, 50, 40);

        jLabel16.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel37.add(jLabel16);
        jLabel16.setBounds(1710, 40, 110, 20);

        jLabel24.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(102, 255, 102));
        jLabel24.setText("HELLO");
        jPanel37.add(jLabel24);
        jLabel24.setBounds(1750, 10, 60, 19);

        jPanel1.add(jPanel37);
        jPanel37.setBounds(0, 0, 1900, 70);

        jPanel9.setBackground(new java.awt.Color(0, 0, 0));
        jPanel9.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)));
        jPanel9.setOpaque(false);
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton26.setBackground(new java.awt.Color(0, 0, 0));
        jButton26.setFont(new java.awt.Font("Dialog", 0, 20)); // NOI18N
        jButton26.setForeground(new java.awt.Color(255, 255, 255));
        jButton26.setText("Contact Us");
        jButton26.setContentAreaFilled(false);
        jButton26.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton26.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jButton26.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jButton26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton26MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton26MouseExited(evt);
            }
        });
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton26, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 150, 180, -1));

        jButton106.setBackground(new java.awt.Color(0, 0, 0));
        jButton106.setFont(new java.awt.Font("Dialog", 0, 20)); // NOI18N
        jButton106.setForeground(new java.awt.Color(255, 255, 255));
        jButton106.setText("Profile");
        jButton106.setContentAreaFilled(false);
        jButton106.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton106.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jButton106.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jButton106.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton106MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton106MouseExited(evt);
            }
        });
        jButton106.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton106ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton106, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 140, -1));

        jButton189.setBackground(new java.awt.Color(0, 0, 0));
        jButton189.setFont(new java.awt.Font("Dialog", 0, 20)); // NOI18N
        jButton189.setForeground(new java.awt.Color(255, 255, 255));
        jButton189.setText("Change Password");
        jButton189.setContentAreaFilled(false);
        jButton189.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton189.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jButton189.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jButton189.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton189MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton189MouseExited(evt);
            }
        });
        jButton189.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton189ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton189, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 200, -1));

        jButton190.setBackground(new java.awt.Color(0, 0, 0));
        jButton190.setFont(new java.awt.Font("Dialog", 0, 20)); // NOI18N
        jButton190.setForeground(new java.awt.Color(255, 255, 255));
        jButton190.setText("Logout");
        jButton190.setContentAreaFilled(false);
        jButton190.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton190.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jButton190.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jButton190.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton190MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton190MouseExited(evt);
            }
        });
        jButton190.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton190ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton190, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 170, -1));

        jButton218.setBackground(new java.awt.Color(0, 0, 0));
        jButton218.setFont(new java.awt.Font("Dialog", 0, 20)); // NOI18N
        jButton218.setForeground(new java.awt.Color(255, 255, 255));
        jButton218.setText("Settings");
        jButton218.setContentAreaFilled(false);
        jButton218.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton218.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jButton218.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jButton218.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton218MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton218MouseExited(evt);
            }
        });
        jButton218.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton218ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton218, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 150, -1));

        jLabel30.setFont(new java.awt.Font("AMORICA SANS Stroke", 0, 280)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 3, 3));
        jLabel30.setText("7");
        jPanel9.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 18, 140, 230));

        jPanel1.add(jPanel9);
        jPanel9.setBounds(1260, 2550, 200, 230);

        jPanel10.setVisible(false);
        jPanel10.setBackground(new java.awt.Color(0, 0, 0));
        jPanel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jPanel10.setLayout(null);

        jButton219.setBackground(new java.awt.Color(0, 0, 0));
        jButton219.setFont(new java.awt.Font("Arial", 0, 22)); // NOI18N
        jButton219.setForeground(new java.awt.Color(255, 255, 255));
        jButton219.setText("Update");
        jButton219.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton219.setContentAreaFilled(false);
        jButton219.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton219.setOpaque(true);
        jButton219.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton219MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton219MouseExited(evt);
            }
        });
        jButton219.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton219ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton219);
        jButton219.setBounds(120, 280, 110, 35);

        jButton220.setBackground(new java.awt.Color(0, 0, 0));
        jButton220.setFont(new java.awt.Font("Arial", 0, 22)); // NOI18N
        jButton220.setForeground(new java.awt.Color(255, 255, 255));
        jButton220.setText("Cancel");
        jButton220.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton220.setContentAreaFilled(false);
        jButton220.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton220.setOpaque(true);
        jButton220.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton220MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton220MouseExited(evt);
            }
        });
        jButton220.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton220ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton220);
        jButton220.setBounds(250, 280, 110, 35);

        jLabel26.setFont(new java.awt.Font("Arial", 0, 22)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("Confirm Password");
        jLabel26.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 255, 204), 3, true));
        jPanel10.add(jLabel26);
        jLabel26.setBounds(200, 190, 190, 35);

        jLabel33.setFont(new java.awt.Font("Arial", 0, 22)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("  Old Password");
        jLabel33.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 255, 204), 3, true));
        jPanel10.add(jLabel33);
        jLabel33.setBounds(200, 40, 190, 35);

        jLabel34.setFont(new java.awt.Font("Arial", 0, 22)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("  New Password");
        jLabel34.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 255, 204), 3, true));
        jPanel10.add(jLabel34);
        jLabel34.setBounds(200, 120, 190, 35);

        jPasswordField1.setBackground(new java.awt.Color(0, 0, 0));
        jPasswordField1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jPasswordField1.setForeground(new java.awt.Color(255, 204, 51));
        jPasswordField1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(51, 51, 255)));
        jPasswordField1.setOpaque(false);
        jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField1ActionPerformed(evt);
            }
        });
        jPanel10.add(jPasswordField1);
        jPasswordField1.setBounds(205, 38, 171, 33);

        jPasswordField2.setBackground(new java.awt.Color(0, 0, 0));
        jPasswordField2.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jPasswordField2.setForeground(new java.awt.Color(255, 204, 51));
        jPasswordField2.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(51, 51, 255)));
        jPasswordField2.setOpaque(false);
        jPanel10.add(jPasswordField2);
        jPasswordField2.setBounds(205, 114, 171, 36);

        jPasswordField3.setBackground(new java.awt.Color(0, 0, 0));
        jPasswordField3.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jPasswordField3.setForeground(new java.awt.Color(255, 204, 51));
        jPasswordField3.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(51, 51, 255)));
        jPasswordField3.setOpaque(false);
        jPanel10.add(jPasswordField3);
        jPasswordField3.setBounds(205, 188, 171, 36);

        jLabel31.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 0, 51));
        jLabel31.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel31.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel10.add(jLabel31);
        jLabel31.setBounds(140, 250, 300, 20);

        jPanel1.add(jPanel10);
        jPanel10.setBounds(700, 3030, 510, 330);

        jPanel40.setBackground(new java.awt.Color(0, 0, 0));
        jPanel40.setLayout(null);

        jPanel91.setVisible(false);
        jPanel91.setBackground(new java.awt.Color(0, 0, 0));
        jPanel91.setLayout(null);

        jPanel92.setOpaque(false);
        jPanel92.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel92MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel92MouseExited(evt);
            }
        });
        jPanel92.setLayout(null);
        jPanel91.add(jPanel92);
        jPanel92.setBounds(0, 920, 900, 220);

        jPanel93.setBackground(new java.awt.Color(0, 0, 0));
        jPanel93.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel93.setOpaque(false);
        jPanel93.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel93MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel93MouseExited(evt);
            }
        });
        jPanel93.setLayout(null);

        jLabel74.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\class of 83.png")); // NOI18N
        jLabel74.setText("the great heist");
        jLabel74.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel74MouseEntered(evt);
            }
        });
        jPanel93.add(jLabel74);
        jLabel74.setBounds(10, 10, 340, 190);

        jLabel75.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel75.setForeground(new java.awt.Color(255, 255, 255));
        jLabel75.setText("<html>A child bride grows up to be an enigmatic woman <br>presiding over her household, harboring a <br>painful past as supernatural murders of men plague her village.</html>");
        jPanel93.add(jLabel75);
        jLabel75.setBounds(380, 10, 440, 100);

        jLabel76.setFont(new java.awt.Font("Gadugi", 0, 19)); // NOI18N
        jLabel76.setForeground(new java.awt.Color(255, 255, 255));
        jLabel76.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Mystery  <font style=\"color:red;size:20px\">&#9679;</font>Drama  <font style=\"color:red;size:20px\">&#9679;</font>Thriller  </p> </html> ");
        jPanel93.add(jLabel76);
        jLabel76.setBounds(380, 170, 230, 30);

        jLabel106.setBackground(new java.awt.Color(51, 51, 51));
        jLabel106.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel106.setForeground(new java.awt.Color(255, 255, 51));
        jLabel106.setText("  ARRIVAL @ 15 Aug");
        jLabel106.setAlignmentY(1.0F);
        jLabel106.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 51)));
        jLabel106.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel106.setOpaque(true);
        jLabel106.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel93.add(jLabel106);
        jLabel106.setBounds(380, 132, 200, 29);

        jButton324.setBackground(new java.awt.Color(255, 255, 255));
        jButton324.setFont(new java.awt.Font("Arial", 0, 17)); // NOI18N
        jButton324.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-play-26 (1).png")); // NOI18N
        jButton324.setText("TRAILER");
        jButton324.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton324.setContentAreaFilled(false);
        jButton324.setOpaque(true);
        jButton324.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton324ActionPerformed(evt);
            }
        });
        jPanel93.add(jButton324);
        jButton324.setBounds(600, 132, 130, 30);

        jPanel91.add(jPanel93);
        jPanel93.setBounds(0, 920, 900, 220);

        jPanel94.setOpaque(false);
        jPanel94.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel94MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel94MouseExited(evt);
            }
        });
        jPanel94.setLayout(null);
        jPanel91.add(jPanel94);
        jPanel94.setBounds(950, 920, 900, 220);

        jPanel95.setBackground(new java.awt.Color(0, 0, 0));
        jPanel95.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel95.setOpaque(false);
        jPanel95.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel95MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel95MouseExited(evt);
            }
        });
        jPanel95.setLayout(null);

        jLabel77.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\overlord.png")); // NOI18N
        jLabel77.setText("cursed");
        jLabel77.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel77MouseEntered(evt);
            }
        });
        jPanel95.add(jLabel77);
        jLabel77.setBounds(10, 10, 340, 190);

        jLabel78.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel78.setForeground(new java.awt.Color(255, 255, 255));
        jLabel78.setText("<html>A child bride grows up to be an enigmatic woman <br>presiding over her household, harboring a <br>painful past as supernatural murders of men plague her village.</html>");
        jPanel95.add(jLabel78);
        jLabel78.setBounds(380, 10, 440, 110);

        jLabel79.setFont(new java.awt.Font("Gadugi", 0, 19)); // NOI18N
        jLabel79.setForeground(new java.awt.Color(255, 255, 255));
        jLabel79.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Super Hero  <font style=\"color:red;size:20px\">&#9679;</font>War  <font style=\"color:red;size:20px\">&#9679;</font>Thriller  </p> </html> ");
        jPanel95.add(jLabel79);
        jLabel79.setBounds(380, 180, 240, 30);

        jLabel105.setBackground(new java.awt.Color(51, 51, 51));
        jLabel105.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel105.setForeground(new java.awt.Color(255, 255, 51));
        jLabel105.setText("  ARRIVAL @ tomorrow");
        jLabel105.setAlignmentY(1.0F);
        jLabel105.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 51)));
        jLabel105.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel105.setOpaque(true);
        jLabel105.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel95.add(jLabel105);
        jLabel105.setBounds(380, 140, 210, 29);

        jButton327.setBackground(new java.awt.Color(255, 255, 255));
        jButton327.setFont(new java.awt.Font("Arial", 0, 17)); // NOI18N
        jButton327.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-play-26 (1).png")); // NOI18N
        jButton327.setText("TRAILER");
        jButton327.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton327.setContentAreaFilled(false);
        jButton327.setOpaque(true);
        jButton327.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton327ActionPerformed(evt);
            }
        });
        jPanel95.add(jButton327);
        jButton327.setBounds(620, 140, 130, 30);

        jPanel91.add(jPanel95);
        jPanel95.setBounds(950, 920, 900, 220);

        jPanel96.setOpaque(false);
        jPanel96.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel96MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel96MouseExited(evt);
            }
        });
        jPanel96.setLayout(null);
        jPanel91.add(jPanel96);
        jPanel96.setBounds(950, 620, 900, 220);

        jPanel97.setBackground(new java.awt.Color(0, 0, 0));
        jPanel97.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel97.setOpaque(false);
        jPanel97.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel97MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel97MouseExited(evt);
            }
        });
        jPanel97.setLayout(null);

        jLabel80.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\spider man.png")); // NOI18N
        jLabel80.setText("signs");
        jLabel80.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel80MouseEntered(evt);
            }
        });
        jPanel97.add(jLabel80);
        jLabel80.setBounds(10, 10, 340, 190);

        jLabel81.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel81.setForeground(new java.awt.Color(255, 255, 255));
        jLabel81.setText("<html>A child bride grows up to be an enigmatic woman <br>presiding over her household, harboring a <br>painful past as supernatural murders of men plague her village.</html>");
        jPanel97.add(jLabel81);
        jLabel81.setBounds(380, 10, 440, 110);

        jLabel82.setFont(new java.awt.Font("Gadugi", 0, 19)); // NOI18N
        jLabel82.setForeground(new java.awt.Color(255, 255, 255));
        jLabel82.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Suspense  <font style=\"color:red;size:20px\">&#9679;</font>Thriller  <font style=\"color:red;size:20px\">&#9679;</font>Mystery  </p> </html> ");
        jPanel97.add(jLabel82);
        jLabel82.setBounds(380, 180, 250, 20);

        jLabel104.setBackground(new java.awt.Color(51, 51, 51));
        jLabel104.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel104.setForeground(new java.awt.Color(255, 255, 51));
        jLabel104.setText("  ARRIVAL @ this tuesday");
        jLabel104.setAlignmentY(1.0F);
        jLabel104.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 51)));
        jLabel104.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel104.setOpaque(true);
        jLabel104.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel97.add(jLabel104);
        jLabel104.setBounds(380, 138, 230, 29);

        jButton326.setBackground(new java.awt.Color(255, 255, 255));
        jButton326.setFont(new java.awt.Font("Arial", 0, 17)); // NOI18N
        jButton326.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-play-26 (1).png")); // NOI18N
        jButton326.setText("TRAILER");
        jButton326.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton326.setContentAreaFilled(false);
        jButton326.setOpaque(true);
        jButton326.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton326ActionPerformed(evt);
            }
        });
        jPanel97.add(jButton326);
        jButton326.setBounds(630, 137, 130, 30);

        jPanel91.add(jPanel97);
        jPanel97.setBounds(950, 620, 900, 220);

        jPanel98.setOpaque(false);
        jPanel98.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel98MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel98MouseExited(evt);
            }
        });
        jPanel98.setLayout(null);
        jPanel91.add(jPanel98);
        jPanel98.setBounds(0, 620, 900, 220);

        jPanel99.setBackground(new java.awt.Color(0, 0, 0));
        jPanel99.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel99.setOpaque(false);
        jPanel99.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel99MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel99MouseExited(evt);
            }
        });
        jPanel99.setLayout(null);

        //jLabel62.setEnabled(false);
        jLabel83.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the crimes that bind.png")); // NOI18N
        jLabel83.setText("project power");
        jLabel83.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel83MouseEntered(evt);
            }
        });
        jPanel99.add(jLabel83);
        jLabel83.setBounds(10, 10, 340, 190);

        //jLabel63.setEnabled(false);
        jLabel84.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel84.setForeground(new java.awt.Color(255, 255, 255));
        jLabel84.setText("<html>A child bride grows up to be an enigmatic woman <br>presiding over her household, harboring a <br>painful past as supernatural murders of men plague her village.</html>");
        jPanel99.add(jLabel84);
        jLabel84.setBounds(380, 20, 440, 110);

        jLabel85.setFont(new java.awt.Font("Gadugi", 0, 19)); // NOI18N
        jLabel85.setForeground(new java.awt.Color(255, 255, 255));
        jLabel85.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Suspense  <font style=\"color:red;size:20px\">&#9679;</font>Thriller  <font style=\"color:red;size:20px\">&#9679;</font>Mystery  </p> </html> ");
        jPanel99.add(jLabel85);
        jLabel85.setBounds(380, 190, 260, 20);

        jLabel103.setBackground(new java.awt.Color(51, 51, 51));
        jLabel103.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel103.setForeground(new java.awt.Color(255, 255, 51));
        jLabel103.setText("  ARRIVAL @ this week");
        jLabel103.setAlignmentY(1.0F);
        jLabel103.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 51)));
        jLabel103.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel103.setOpaque(true);
        jLabel103.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel99.add(jLabel103);
        jLabel103.setBounds(380, 150, 200, 29);

        jButton323.setBackground(new java.awt.Color(255, 255, 255));
        jButton323.setFont(new java.awt.Font("Arial", 0, 17)); // NOI18N
        jButton323.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-play-26 (1).png")); // NOI18N
        jButton323.setText("TRAILER");
        jButton323.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton323.setContentAreaFilled(false);
        jButton323.setOpaque(true);
        jButton323.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton323ActionPerformed(evt);
            }
        });
        jPanel99.add(jButton323);
        jButton323.setBounds(600, 148, 130, 30);

        jPanel91.add(jPanel99);
        jPanel99.setBounds(0, 620, 900, 220);

        jPanel100.setOpaque(false);
        jPanel100.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel100MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel100MouseExited(evt);
            }
        });
        jPanel100.setLayout(null);
        jPanel91.add(jPanel100);
        jPanel100.setBounds(960, 330, 900, 220);

        jPanel101.setBackground(new java.awt.Color(0, 0, 0));
        jPanel101.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel101.setOpaque(false);
        jPanel101.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel101MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel101MouseExited(evt);
            }
        });
        jPanel101.setLayout(null);

        jLabel86.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\rita.png")); // NOI18N
        jLabel86.setText("stranger");
        jLabel86.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel86MouseEntered(evt);
            }
        });
        jPanel101.add(jLabel86);
        jLabel86.setBounds(10, 10, 340, 190);

        jLabel87.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel87.setForeground(new java.awt.Color(255, 255, 255));
        jLabel87.setText("<html>With the help of a gutsy female detective, a <br>prosecutor who has lost the ability to feel<br> empathy tackles a murder case amid political corruption.</html> ");
        jPanel101.add(jLabel87);
        jLabel87.setBounds(380, 10, 410, 110);

        jLabel88.setFont(new java.awt.Font("Gadugi", 0, 19)); // NOI18N
        jLabel88.setForeground(new java.awt.Color(255, 255, 255));
        jLabel88.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Mystery  <font style=\"color:red;size:20px\">&#9679;</font>scifi  <font style=\"color:red;size:20px\">&#9679;</font>Thriller  </p> </html> ");
        jPanel101.add(jLabel88);
        jLabel88.setBounds(380, 184, 210, 26);

        jLabel102.setBackground(new java.awt.Color(51, 51, 51));
        jLabel102.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel102.setForeground(new java.awt.Color(255, 255, 51));
        jLabel102.setText("  ARRIVAL @ this week");
        jLabel102.setAlignmentY(1.0F);
        jLabel102.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 51)));
        jLabel102.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel102.setOpaque(true);
        jLabel102.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel101.add(jLabel102);
        jLabel102.setBounds(380, 140, 200, 29);

        jButton325.setBackground(new java.awt.Color(255, 255, 255));
        jButton325.setFont(new java.awt.Font("Arial", 0, 17)); // NOI18N
        jButton325.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-play-26 (1).png")); // NOI18N
        jButton325.setText("TRAILER");
        jButton325.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton325.setContentAreaFilled(false);
        jButton325.setOpaque(true);
        jButton325.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton325ActionPerformed(evt);
            }
        });
        jPanel101.add(jButton325);
        jButton325.setBounds(600, 140, 130, 30);

        jPanel91.add(jPanel101);
        jPanel101.setBounds(960, 330, 900, 220);

        jPanel103.setBackground(new java.awt.Color(0, 0, 0));
        jPanel103.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel103.setOpaque(false);
        jPanel103.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel103MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel103MouseExited(evt);
            }
        });
        jPanel103.setLayout(null);

        jLabel89.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\hoops.png")); // NOI18N
        jLabel89.setText("skyscraper");
        jLabel89.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel89.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel89MouseEntered(evt);
            }
        });
        jPanel103.add(jLabel89);
        jLabel89.setBounds(10, 10, 340, 190);

        jLabel90.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel90.setForeground(new java.awt.Color(255, 255, 255));
        jLabel90.setText("<html>When terrorists attack the tallest building in the <br>world, a security consultant will do anything <br>to save his family from the carnage.</html> ");
        jPanel103.add(jLabel90);
        jLabel90.setBounds(380, 20, 420, 80);

        jLabel91.setFont(new java.awt.Font("Gadugi", 0, 17)); // NOI18N
        jLabel91.setForeground(new java.awt.Color(255, 255, 255));
        jLabel91.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Suspense  <font style=\"color:red;size:20px\">&#9679;</font>Action  <font style=\"color:red;size:20px\">&#9679;</font>Thriller  </p> </html> ");
        jPanel103.add(jLabel91);
        jLabel91.setBounds(380, 180, 220, 30);

        jLabel101.setBackground(new java.awt.Color(51, 51, 51));
        jLabel101.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel101.setForeground(new java.awt.Color(255, 255, 51));
        jLabel101.setText("  ARRIVAL @ this week");
        jLabel101.setAlignmentY(1.0F);
        jLabel101.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 51)));
        jLabel101.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel101.setOpaque(true);
        jLabel101.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel103.add(jLabel101);
        jLabel101.setBounds(380, 132, 200, 29);

        jButton322.setBackground(new java.awt.Color(255, 255, 255));
        jButton322.setFont(new java.awt.Font("Arial", 0, 17)); // NOI18N
        jButton322.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-play-26 (1).png")); // NOI18N
        jButton322.setText("TRAILER");
        jButton322.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton322.setContentAreaFilled(false);
        jButton322.setOpaque(true);
        jButton322.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton322ActionPerformed(evt);
            }
        });
        jPanel103.add(jButton322);
        jButton322.setBounds(600, 132, 130, 30);

        jPanel91.add(jPanel103);
        jPanel103.setBounds(0, 330, 900, 220);

        jPanel102.setOpaque(false);
        jPanel102.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel102MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel102MouseExited(evt);
            }
        });
        jPanel102.setLayout(null);
        jPanel91.add(jPanel102);
        jPanel102.setBounds(0, 330, 900, 220);

        jPanel105.setBackground(new java.awt.Color(0, 0, 0));
        jPanel105.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel105.setOpaque(false);
        jPanel105.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel105MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel105MouseExited(evt);
            }
        });
        jPanel105.setLayout(null);

        jLabel92.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\bio hackers.png")); // NOI18N
        jLabel92.setText("3%");
        jLabel92.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel92MouseEntered(evt);
            }
        });
        jPanel105.add(jLabel92);
        jLabel92.setBounds(10, 10, 340, 190);

        jLabel93.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel93.setForeground(new java.awt.Color(255, 255, 255));
        jLabel93.setText("<html>In a future where the elite inhabit an island <br>paradise far from the crowded slums, you get one <br>chance to join the 3% saved from squalor.</html> ");
        jPanel105.add(jLabel93);
        jLabel93.setBounds(380, 10, 440, 130);

        jLabel94.setFont(new java.awt.Font("Gadugi", 0, 19)); // NOI18N
        jLabel94.setForeground(new java.awt.Color(255, 255, 255));
        jLabel94.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Korean  <font style=\"color:red;size:20px\">&#9679;</font>War  <font style=\"color:red;size:20px\">&#9679;</font>Drama  </p> </html> ");
        jPanel105.add(jLabel94);
        jLabel94.setBounds(380, 180, 200, 20);

        jLabel100.setBackground(new java.awt.Color(51, 51, 51));
        jLabel100.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel100.setForeground(new java.awt.Color(255, 255, 51));
        jLabel100.setText("  ARRIVAL @ this month");
        jLabel100.setAlignmentY(1.0F);
        jLabel100.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 51)));
        jLabel100.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel100.setOpaque(true);
        jLabel100.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel105.add(jLabel100);
        jLabel100.setBounds(380, 132, 220, 29);

        jButton321.setBackground(new java.awt.Color(255, 255, 255));
        jButton321.setFont(new java.awt.Font("Arial", 0, 17)); // NOI18N
        jButton321.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-play-26 (1).png")); // NOI18N
        jButton321.setText("TRAILER");
        jButton321.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton321.setContentAreaFilled(false);
        jButton321.setOpaque(true);
        jButton321.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton321ActionPerformed(evt);
            }
        });
        jPanel105.add(jButton321);
        jButton321.setBounds(620, 130, 130, 30);

        jPanel91.add(jPanel105);
        jPanel105.setBounds(950, 20, 900, 220);

        jPanel104.setOpaque(false);
        jPanel104.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel104MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel104MouseExited(evt);
            }
        });
        jPanel104.setLayout(null);
        jPanel91.add(jPanel104);
        jPanel104.setBounds(950, 20, 900, 220);

        jPanel107.setBackground(new java.awt.Color(0, 0, 0));
        jPanel107.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel107.setOpaque(false);
        jPanel107.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel107MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel107MouseExited(evt);
            }
        });
        jPanel107.setLayout(null);

        jLabel95.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\nigerian prince.png")); // NOI18N
        jLabel95.setText("bulbbul");
        jLabel95.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel95MouseEntered(evt);
            }
        });
        jPanel107.add(jLabel95);
        jLabel95.setBounds(10, 10, 340, 190);

        jLabel96.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel96.setForeground(new java.awt.Color(255, 255, 255));
        jLabel96.setText("<html>A child bride grows up to be an enigmatic <br>woman presiding over her household, <br> harboring a painful past as supernatural <br>murders of men plague her village.</html>");
        jLabel96.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel96MouseEntered(evt);
            }
        });
        jPanel107.add(jLabel96);
        jLabel96.setBounds(380, 10, 370, 110);

        jLabel97.setFont(new java.awt.Font("Gadugi", 0, 19)); // NOI18N
        jLabel97.setForeground(new java.awt.Color(255, 255, 255));
        jLabel97.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Suspense  <font style=\"color:red;size:20px\">&#9679;</font>Thriller  <font style=\"color:red;size:20px\">&#9679;</font>Mystery  </p> </html> ");
        jPanel107.add(jLabel97);
        jLabel97.setBounds(380, 180, 250, 20);

        jLabel99.setBackground(new java.awt.Color(51, 51, 51));
        jLabel99.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel99.setForeground(new java.awt.Color(255, 255, 51));
        jLabel99.setText("  ARRIVAL @ this week");
        jLabel99.setAlignmentY(1.0F);
        jLabel99.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 51)));
        jLabel99.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel99.setOpaque(true);
        jLabel99.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel107.add(jLabel99);
        jLabel99.setBounds(380, 132, 200, 29);

        jButton320.setBackground(new java.awt.Color(255, 255, 255));
        jButton320.setFont(new java.awt.Font("Arial", 0, 17)); // NOI18N
        jButton320.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-play-26 (1).png")); // NOI18N
        jButton320.setText("TRAILER");
        jButton320.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton320.setContentAreaFilled(false);
        jButton320.setOpaque(true);
        jButton320.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton320ActionPerformed(evt);
            }
        });
        jPanel107.add(jButton320);
        jButton320.setBounds(600, 132, 130, 30);

        jPanel91.add(jPanel107);
        jPanel107.setBounds(0, 20, 900, 220);

        jPanel106.setOpaque(false);
        jPanel106.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel106MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel106MouseExited(evt);
            }
        });
        jPanel106.setLayout(null);
        jPanel91.add(jPanel106);
        jPanel106.setBounds(0, 20, 900, 220);

        jLabel98.setBackground(new java.awt.Color(51, 51, 51));
        jLabel98.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 0, new java.awt.Color(0, 204, 204)));
        jLabel98.setOpaque(true);
        jPanel91.add(jLabel98);
        jLabel98.setBounds(40, 1210, 0, 220);

        jPanel40.add(jPanel91);
        jPanel91.setBounds(0, 0, 1930, 3120);

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));
        jPanel3.setLayout(null);

        jPanel30.setVisible(false);
        jPanel30.setBackground(new java.awt.Color(0, 0, 0));
        jPanel30.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));
        jPanel30.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        sarkar_wt8.setBackground(new java.awt.Color(0, 0, 0));
        sarkar_wt8.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-play-30.png")); // NOI18N
        sarkar_wt8.setContentAreaFilled(false);
        sarkar_wt8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sarkar_wt8ActionPerformed(evt);
            }
        });
        jPanel30.add(sarkar_wt8, new org.netbeans.lib.awtextra.AbsoluteConstraints(-1, 5, 40, -1));

        sarkar_add_list8.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-plus-30.png")); // NOI18N
        sarkar_add_list8.setContentAreaFilled(false);
        sarkar_add_list8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                sarkar_add_list8MouseEntered(evt);
            }
        });
        sarkar_add_list8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sarkar_add_list8ActionPerformed(evt);
            }
        });
        jPanel30.add(sarkar_add_list8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 40, -1));

        sarkar_fav8.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-star-35.png")); // NOI18N
        sarkar_fav8.setContentAreaFilled(false);
        sarkar_fav8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sarkar_fav8ActionPerformed(evt);
            }
        });
        jPanel30.add(sarkar_fav8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 40, 40));

        jPanel3.add(jPanel30);
        jPanel30.setBounds(990, 2550, 40, 190);

        recom_panel.setLayout(null);

        jPanel4.setBackground(new java.awt.Color(0, 0, 0));
        jPanel4.setLayout(null);

        jButton40.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton40.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton40.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton40MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton40MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton40MouseReleased(evt);
            }
        });
        jButton40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton40ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton40);
        jButton40.setBounds(0, 20, 300, 190);

        jButton56.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton56.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton56.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton56MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton56MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton56MouseReleased(evt);
            }
        });
        jButton56.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton56ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton56);
        jButton56.setBounds(320, 20, 300, 190);

        jButton57.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton57.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton57.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton57MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton57MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton57MouseReleased(evt);
            }
        });
        jButton57.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton57ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton57);
        jButton57.setBounds(640, 20, 300, 190);

        jButton58.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton58.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton58.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton58MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton58MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton58MouseReleased(evt);
            }
        });
        jButton58.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton58ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton58);
        jButton58.setBounds(960, 20, 300, 190);

        jButton59.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton59.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton59.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton59MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton59MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton59MouseReleased(evt);
            }
        });
        jButton59.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton59ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton59);
        jButton59.setBounds(1280, 20, 300, 190);

        jButton60.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton60.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton60.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton60MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton60MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton60MouseReleased(evt);
            }
        });
        jButton60.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton60ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton60);
        jButton60.setBounds(1600, 20, 300, 190);

        recom_panel.add(jPanel4);
        jPanel4.setBounds(0, 0, 1910, 240);

        jPanel55.setVisible(false);
        jPanel55.setBackground(new java.awt.Color(0, 0, 0));
        jPanel55.setLayout(null);

        jButton62.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton62.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton62.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton62MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton62MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton62MouseReleased(evt);
            }
        });
        jButton62.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton62ActionPerformed(evt);
            }
        });
        jPanel55.add(jButton62);
        jButton62.setBounds(0, 20, 300, 190);

        jButton63.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton63.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton63.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton63MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton63MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton63MouseReleased(evt);
            }
        });
        jButton63.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton63ActionPerformed(evt);
            }
        });
        jPanel55.add(jButton63);
        jButton63.setBounds(320, 20, 300, 190);

        jButton64.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton64.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton64.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton64MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton64MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton64MouseReleased(evt);
            }
        });
        jButton64.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton64ActionPerformed(evt);
            }
        });
        jPanel55.add(jButton64);
        jButton64.setBounds(640, 20, 300, 190);

        jButton65.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton65.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton65.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton65MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton65MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton65MouseReleased(evt);
            }
        });
        jButton65.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton65ActionPerformed(evt);
            }
        });
        jPanel55.add(jButton65);
        jButton65.setBounds(960, 20, 300, 190);

        jButton66.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton66.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton66.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton66MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton66MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton66MouseReleased(evt);
            }
        });
        jButton66.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton66ActionPerformed(evt);
            }
        });
        jPanel55.add(jButton66);
        jButton66.setBounds(1280, 20, 300, 190);

        jButton67.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton67.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton67.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton67MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton67MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton67MouseReleased(evt);
            }
        });
        jButton67.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton67ActionPerformed(evt);
            }
        });
        jPanel55.add(jButton67);
        jButton67.setBounds(1600, 20, 300, 190);

        recom_panel.add(jPanel55);
        jPanel55.setBounds(0, 0, 1910, 240);

        jPanel3.add(recom_panel);
        recom_panel.setBounds(0, 90, 1910, 240);

        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-love-30.png")); // NOI18N
        jLabel6.setText("jLabel6");
        jPanel3.add(jLabel6);
        jLabel6.setBounds(120, 460, 30, 30);

        jLabel5.setBackground(new java.awt.Color(255, 0, 102));
        jLabel5.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("ROMCOM");
        jLabel5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 1, true));
        jPanel3.add(jLabel5);
        jLabel5.setBounds(10, 460, 150, 40);

        jLabel4.setBackground(new java.awt.Color(102, 102, 102));
        jLabel4.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("  OUR RECOMMENDATIONS FOR YOU:");
        jLabel4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 1, true));
        jLabel4.setOpaque(true);
        jPanel3.add(jLabel4);
        jLabel4.setBounds(0, 40, 460, 30);

        rom_com_panel.setBackground(new java.awt.Color(0, 0, 0));
        rom_com_panel.setLayout(null);

        jPanel6.setBackground(new java.awt.Color(0, 0, 0));
        jPanel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel6MouseExited(evt);
            }
        });
        jPanel6.setLayout(null);

        jButton9.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\ee nagaraniki emaindi.png")); // NOI18N
        jButton9.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton9MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton9MouseReleased(evt);
            }
        });
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton9);
        jButton9.setBounds(0, 0, 330, 190);

        jButton7.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\evariki cheppadu.png")); // NOI18N
        jButton7.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton7MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton7MouseReleased(evt);
            }
        });
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton7);
        jButton7.setBounds(380, 0, 350, 190);

        sarkar.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\Webp.net-resizeimage (2).jpg")); // NOI18N
        sarkar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        sarkar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sarkar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sarkarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                sarkarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                sarkarMouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                sarkarMouseReleased(evt);
            }
        });
        sarkar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sarkarActionPerformed(evt);
            }
        });
        jPanel6.add(sarkar);
        sarkar.setBounds(770, 0, 340, 190);

        jButton10.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\miku.png")); // NOI18N
        jButton10.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton10MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton10MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton10MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton10MouseReleased(evt);
            }
        });
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton10);
        jButton10.setBounds(1150, 0, 340, 190);

        jButton11.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\padi.png")); // NOI18N
        jButton11.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton11MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton11MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton11MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton11MouseReleased(evt);
            }
        });
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton11);
        jButton11.setBounds(1530, 0, 340, 190);

        rom_com_panel.add(jPanel6);
        jPanel6.setBounds(0, 0, 1960, 230);

        jPanel7.setBackground(new java.awt.Color(0, 0, 0));
        jPanel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel7MouseExited(evt);
            }
        });
        jPanel7.setLayout(null);

        jButton12.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\Webp.net-resizeimage (3).jpg")); // NOI18N
        jButton12.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton12MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton12MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton12MouseReleased(evt);
            }
        });
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel7.add(jButton12);
        jButton12.setBounds(0, 0, 330, 190);

        rom_com_panel.add(jPanel7);
        jPanel7.setBounds(0, 0, 2100, 230);

        jPanel3.add(rom_com_panel);
        rom_com_panel.setBounds(0, 540, 2100, 230);

        jPanel54.setVisible(false);
        jPanel54.setBackground(new java.awt.Color(0, 0, 0));
        jPanel54.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel54MouseExited(evt);
            }
        });
        jPanel54.setLayout(null);

        recom_btn1.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16.png")); // NOI18N
        recom_btn1.setContentAreaFilled(false);
        recom_btn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        recom_btn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                recom_btn1MouseClicked(evt);
            }
        });
        recom_btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                recom_btn1ActionPerformed(evt);
            }
        });
        jPanel54.add(recom_btn1);
        recom_btn1.setBounds(970, 0, 20, 20);

        recom_btn2.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16 (1).png")); // NOI18N
        recom_btn2.setContentAreaFilled(false);
        recom_btn2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        recom_btn2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                recom_btn2MouseClicked(evt);
            }
        });
        recom_btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                recom_btn2ActionPerformed(evt);
            }
        });
        jPanel54.add(recom_btn2);
        recom_btn2.setBounds(1000, 0, 20, 20);

        jPanel3.add(jPanel54);
        jPanel54.setBounds(0, 330, 2100, 20);

        jPanel8.setBackground(new java.awt.Color(0, 0, 0));
        jPanel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel8MouseExited(evt);
            }
        });
        jPanel8.setLayout(null);

        rom_com_btn1.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16.png")); // NOI18N
        rom_com_btn1.setContentAreaFilled(false);
        rom_com_btn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        rom_com_btn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rom_com_btn1MouseClicked(evt);
            }
        });
        rom_com_btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rom_com_btn1ActionPerformed(evt);
            }
        });
        jPanel8.add(rom_com_btn1);
        rom_com_btn1.setBounds(970, 0, 20, 20);

        rom_com_btn2.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16 (1).png")); // NOI18N
        rom_com_btn2.setContentAreaFilled(false);
        rom_com_btn2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        rom_com_btn2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rom_com_btn2MouseClicked(evt);
            }
        });
        rom_com_btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rom_com_btn2ActionPerformed(evt);
            }
        });
        jPanel8.add(rom_com_btn2);
        rom_com_btn2.setBounds(1000, 0, 20, 20);

        jPanel3.add(jPanel8);
        jPanel8.setBounds(0, 770, 2100, 20);

        jLabel23.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-horror-30.png")); // NOI18N
        jPanel3.add(jLabel23);
        jLabel23.setBounds(120, 2270, 30, 30);

        jLabel20.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-drama-30.png")); // NOI18N
        jPanel3.add(jLabel20);
        jLabel20.setBounds(120, 1510, 30, 40);

        jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-fight-30.png")); // NOI18N
        jPanel3.add(jLabel9);
        jLabel9.setBounds(110, 810, 30, 30);

        jLabel22.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-sci-fi-30.png")); // NOI18N
        jPanel3.add(jLabel22);
        jLabel22.setBounds(100, 1914, 30, 30);

        jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-film-noir-30.png")); // NOI18N
        jPanel3.add(jLabel10);
        jLabel10.setBounds(130, 1140, 40, 40);

        jLabel8.setBackground(new java.awt.Color(51, 255, 51));
        jLabel8.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("  ACTION");
        jLabel8.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 1, true));
        jPanel3.add(jLabel8);
        jLabel8.setBounds(0, 810, 150, 40);

        jLabel11.setBackground(new java.awt.Color(204, 255, 204));
        jLabel11.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText(" HORROR");
        jLabel11.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 1, true));
        jPanel3.add(jLabel11);
        jLabel11.setBounds(0, 2270, 150, 40);

        jLabel17.setBackground(new java.awt.Color(255, 51, 51));
        jLabel17.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("THRILLER");
        jLabel17.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 1, true));
        jPanel3.add(jLabel17);
        jLabel17.setBounds(10, 1140, 150, 40);

        jLabel18.setBackground(new java.awt.Color(0, 102, 204));
        jLabel18.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("   DRAMA");
        jLabel18.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 1, true));
        jPanel3.add(jLabel18);
        jLabel18.setBounds(0, 1510, 150, 40);

        jLabel19.setBackground(new java.awt.Color(255, 102, 102));
        jLabel19.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("    SCIFI");
        jLabel19.setToolTipText("");
        jLabel19.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 1, true));
        jPanel3.add(jLabel19);
        jLabel19.setBounds(0, 1910, 150, 40);

        action_panel.setLayout(null);

        jPanel5.setBackground(new java.awt.Color(0, 0, 0));
        jPanel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel5MouseExited(evt);
            }
        });
        jPanel5.setLayout(null);

        jButton13.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\sarkar.png")); // NOI18N
        jButton13.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton13MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton13MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton13MouseReleased(evt);
            }
        });
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton13);
        jButton13.setBounds(0, 0, 340, 190);

        jButton8.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\Saaho.png")); // NOI18N
        jButton8.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton8MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton8MouseReleased(evt);
            }
        });
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton8);
        jButton8.setBounds(380, 0, 350, 190);

        sarkar1.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\kgf.png")); // NOI18N
        sarkar1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        sarkar1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sarkar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sarkar1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                sarkar1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                sarkar1MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                sarkar1MouseReleased(evt);
            }
        });
        sarkar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sarkar1ActionPerformed(evt);
            }
        });
        jPanel5.add(sarkar1);
        sarkar1.setBounds(770, 0, 340, 190);

        jButton14.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\ala.png")); // NOI18N
        jButton14.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton14.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton14MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton14MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton14MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton14MouseReleased(evt);
            }
        });
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton14);
        jButton14.setBounds(1150, 0, 340, 190);

        jButton15.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\chanakya.png")); // NOI18N
        jButton15.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton15.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton15MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton15MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton15MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton15MouseReleased(evt);
            }
        });
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton15);
        jButton15.setBounds(1530, 0, 340, 190);

        action_panel.add(jPanel5);
        jPanel5.setBounds(0, 0, 1910, 230);

        jPanel21.setBackground(new java.awt.Color(0, 0, 0));
        jPanel21.setLayout(null);

        jButton16.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\cdf3dd8e2b94c44318c9b82e069a82f5f611958d1c57a04a8136e10f3c5d3b7b._UR1920,1080_RI_UX400_UY225_.jpg")); // NOI18N
        jButton16.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton16.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton16MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton16MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton16MouseReleased(evt);
            }
        });
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });
        jPanel21.add(jButton16);
        jButton16.setBounds(0, 0, 340, 190);

        jButton17.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\6e0936bc3f824bfc9c51a5e287b604b2d8502acfa0c48ef253496f47e733c35c._UR1920,1080_RI_UX400_UY225_.jpg")); // NOI18N
        jButton17.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton17.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton17MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton17MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton17MouseReleased(evt);
            }
        });
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });
        jPanel21.add(jButton17);
        jButton17.setBounds(380, 0, 340, 190);

        sarkar2.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\Webp.net-resizeimage (4).jpg")); // NOI18N
        sarkar2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        sarkar2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sarkar2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sarkar2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                sarkar2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                sarkar2MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                sarkar2MouseReleased(evt);
            }
        });
        sarkar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sarkar2ActionPerformed(evt);
            }
        });
        jPanel21.add(sarkar2);
        sarkar2.setBounds(770, 0, 340, 190);

        jButton18.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\1170x658withlogo_515619385.jpg")); // NOI18N
        jButton18.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton18.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton18MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton18MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton18MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton18MouseReleased(evt);
            }
        });
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });
        jPanel21.add(jButton18);
        jButton18.setBounds(1150, 0, 340, 190);

        action_panel.add(jPanel21);
        jPanel21.setBounds(0, 0, 1960, 230);

        jPanel3.add(action_panel);
        action_panel.setBounds(0, 880, 1960, 230);

        jPanel26.setBackground(new java.awt.Color(0, 0, 0));
        jPanel26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel26MouseExited(evt);
            }
        });
        jPanel26.setLayout(null);

        action_btn1.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16.png")); // NOI18N
        action_btn1.setContentAreaFilled(false);
        action_btn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        action_btn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                action_btn1MouseClicked(evt);
            }
        });
        action_btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                action_btn1ActionPerformed(evt);
            }
        });
        jPanel26.add(action_btn1);
        action_btn1.setBounds(990, 0, 20, 20);

        action_btn2.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16 (1).png")); // NOI18N
        action_btn2.setContentAreaFilled(false);
        action_btn2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        action_btn2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                action_btn2MouseClicked(evt);
            }
        });
        action_btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                action_btn2ActionPerformed(evt);
            }
        });
        jPanel26.add(action_btn2);
        action_btn2.setBounds(1020, 0, 20, 20);

        jPanel3.add(jPanel26);
        jPanel26.setBounds(0, 1110, 1910, 20);

        thriller_panel.setBackground(new java.awt.Color(0, 255, 51));
        thriller_panel.setLayout(null);

        jPanel27.setBackground(new java.awt.Color(0, 0, 0));
        jPanel27.setLayout(null);

        jButton19.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\56adb75856eef71450a343d34c1a8ab039243a3c1cfa911932166e40d72cf44c._UR1920,1080_RI_UX400_UY225_.jpg")); // NOI18N
        jButton19.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton19.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton19MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton19MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton19MouseReleased(evt);
            }
        });
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });
        jPanel27.add(jButton19);
        jButton19.setBounds(0, 0, 340, 190);

        jButton20.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\285abef46966e2e5eb8e36d32176e2a6b5de8ced11e6b714d8f2084498871bc9._UR1920,1080_RI_UX400_UY225_.jpg")); // NOI18N
        jButton20.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton20.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton20MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton20MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton20MouseReleased(evt);
            }
        });
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });
        jPanel27.add(jButton20);
        jButton20.setBounds(380, 0, 340, 190);

        sarkar3.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\f977f9fd0f531e027eb1e1901c3eaee000f63e2d83055d6ddda80ea1d69c38f0._UR1920,1080_RI_UX400_UY225_.jpg")); // NOI18N
        sarkar3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        sarkar3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sarkar3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sarkar3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                sarkar3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                sarkar3MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                sarkar3MouseReleased(evt);
            }
        });
        sarkar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sarkar3ActionPerformed(evt);
            }
        });
        jPanel27.add(sarkar3);
        sarkar3.setBounds(760, 0, 340, 190);

        jButton21.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\Webp.net-resizeimage.png")); // NOI18N
        jButton21.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton21.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton21MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton21MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton21MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton21MouseReleased(evt);
            }
        });
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });
        jPanel27.add(jButton21);
        jButton21.setBounds(1140, 0, 340, 190);

        jButton22.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\Webp.net-resizeimage (5).jpg")); // NOI18N
        jButton22.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton22.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton22MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton22MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton22MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton22MouseReleased(evt);
            }
        });
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });
        jPanel27.add(jButton22);
        jButton22.setBounds(1520, 0, 340, 190);

        thriller_panel.add(jPanel27);
        jPanel27.setBounds(0, 0, 1910, 230);

        jPanel33.setBackground(new java.awt.Color(0, 0, 0));
        jPanel33.setLayout(null);

        jButton23.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\predestination.png")); // NOI18N
        jButton23.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton23.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton23MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton23MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton23MouseReleased(evt);
            }
        });
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });
        jPanel33.add(jButton23);
        jButton23.setBounds(0, 0, 340, 190);

        jButton24.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\Webp.net-resizeimage (6).jpg")); // NOI18N
        jButton24.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton24.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton24MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton24MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton24MouseReleased(evt);
            }
        });
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });
        jPanel33.add(jButton24);
        jButton24.setBounds(380, 0, 340, 190);

        sarkar4.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\seven.png")); // NOI18N
        sarkar4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        sarkar4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sarkar4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sarkar4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                sarkar4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                sarkar4MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                sarkar4MouseReleased(evt);
            }
        });
        sarkar4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sarkar4ActionPerformed(evt);
            }
        });
        jPanel33.add(sarkar4);
        sarkar4.setBounds(760, 0, 340, 190);

        thriller_panel.add(jPanel33);
        jPanel33.setBounds(0, 0, 1910, 230);

        jPanel3.add(thriller_panel);
        thriller_panel.setBounds(0, 1230, 1910, 230);

        jPanel39.setBackground(new java.awt.Color(0, 0, 0));
        jPanel39.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel39MouseExited(evt);
            }
        });
        jPanel39.setLayout(null);

        thriller_btn1.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16.png")); // NOI18N
        thriller_btn1.setContentAreaFilled(false);
        thriller_btn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        thriller_btn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                thriller_btn1MouseClicked(evt);
            }
        });
        thriller_btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thriller_btn1ActionPerformed(evt);
            }
        });
        jPanel39.add(thriller_btn1);
        thriller_btn1.setBounds(990, 0, 20, 20);

        thriller_btn2.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16 (1).png")); // NOI18N
        thriller_btn2.setContentAreaFilled(false);
        thriller_btn2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        thriller_btn2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                thriller_btn2MouseClicked(evt);
            }
        });
        thriller_btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thriller_btn2ActionPerformed(evt);
            }
        });
        jPanel39.add(thriller_btn2);
        thriller_btn2.setBounds(1020, 0, 20, 20);

        jPanel3.add(jPanel39);
        jPanel39.setBounds(0, 1460, 1910, 20);

        jButton61.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton61.setForeground(new java.awt.Color(255, 255, 255));
        jButton61.setText("HORROR");
        jButton61.setActionCommand("");
        jButton61.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 1, true));
        jButton61.setContentAreaFilled(false);
        jButton61.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton61.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton61ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton61);
        jButton61.setBounds(1290, 380, 100, 27);

        jButton34.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton34.setForeground(new java.awt.Color(255, 255, 255));
        jButton34.setText("THRILLER");
        jButton34.setActionCommand("");
        jButton34.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 1, true));
        jButton34.setContentAreaFilled(false);
        jButton34.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton34ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton34);
        jButton34.setBounds(870, 380, 120, 27);

        jButton33.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton33.setForeground(new java.awt.Color(255, 255, 255));
        jButton33.setText("DRAMA");
        jButton33.setActionCommand("");
        jButton33.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 1, true));
        jButton33.setContentAreaFilled(false);
        jButton33.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton33ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton33);
        jButton33.setBounds(1170, 380, 100, 27);

        jButton32.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton32.setForeground(new java.awt.Color(255, 255, 255));
        jButton32.setText("SCI FI");
        jButton32.setActionCommand("");
        jButton32.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 1, true));
        jButton32.setContentAreaFilled(false);
        jButton32.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton32ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton32);
        jButton32.setBounds(1010, 380, 140, 27);

        jButton31.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton31.setForeground(new java.awt.Color(255, 255, 255));
        jButton31.setText("ACTION");
        jButton31.setActionCommand("");
        jButton31.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 1, true));
        jButton31.setContentAreaFilled(false);
        jButton31.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton31ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton31);
        jButton31.setBounds(750, 380, 100, 27);

        jButton25.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton25.setForeground(new java.awt.Color(255, 255, 255));
        jButton25.setText("ROMCOM");
        jButton25.setActionCommand("");
        jButton25.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 1, true));
        jButton25.setContentAreaFilled(false);
        jButton25.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton25MouseClicked(evt);
            }
        });
        jPanel3.add(jButton25);
        jButton25.setBounds(620, 380, 110, 27);

        drama_panel.setLayout(null);

        jPanel47.setBackground(new java.awt.Color(0, 0, 0));
        jPanel47.setLayout(null);

        jButton91.setForeground(new java.awt.Color(255, 255, 255));
        jButton91.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\raazi.png")); // NOI18N
        jButton91.setText("raazi");
        jButton91.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton91.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton91.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton91ActionPerformed(evt);
            }
        });
        jPanel47.add(jButton91);
        jButton91.setBounds(0, 0, 340, 190);

        jButton92.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\madha.png")); // NOI18N
        jButton92.setText("madha");
        jButton92.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton92.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton92.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton92ActionPerformed(evt);
            }
        });
        jPanel47.add(jButton92);
        jButton92.setBounds(380, 0, 340, 190);

        jButton93.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\100.png")); // NOI18N
        jButton93.setText("100");
        jButton93.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton93.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton93.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton93ActionPerformed(evt);
            }
        });
        jPanel47.add(jButton93);
        jButton93.setBounds(760, 0, 340, 190);

        jButton94.setFont(new java.awt.Font("Tahoma", 0, 3)); // NOI18N
        jButton94.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\palasa1978.png")); // NOI18N
        jButton94.setText("palasa1978");
        jButton94.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton94.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton94.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton94ActionPerformed(evt);
            }
        });
        jPanel47.add(jButton94);
        jButton94.setBounds(1140, 0, 340, 190);

        jButton95.setFont(new java.awt.Font("Tahoma", 0, 3)); // NOI18N
        jButton95.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\trance.png")); // NOI18N
        jButton95.setText("trance");
        jButton95.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton95.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton95.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton95ActionPerformed(evt);
            }
        });
        jPanel47.add(jButton95);
        jButton95.setBounds(1520, 0, 340, 190);

        drama_panel.add(jPanel47);
        jPanel47.setBounds(0, 0, 1910, 230);

        jPanel44.setVisible(false);
        jPanel44.setBackground(new java.awt.Color(0, 0, 0));
        jPanel44.setLayout(null);

        jButton97.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\guna369.png")); // NOI18N
        jButton97.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton97.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton97.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton97ActionPerformed(evt);
            }
        });
        jPanel44.add(jButton97);
        jButton97.setBounds(0, 0, 340, 190);

        drama_panel.add(jPanel44);
        jPanel44.setBounds(0, 0, 1910, 230);

        jPanel3.add(drama_panel);
        drama_panel.setBounds(0, 1590, 1910, 230);

        jPanel48.setBackground(new java.awt.Color(0, 0, 0));
        jPanel48.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel48MouseExited(evt);
            }
        });
        jPanel48.setLayout(null);

        scifi_btn1.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16.png")); // NOI18N
        scifi_btn1.setContentAreaFilled(false);
        scifi_btn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        scifi_btn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                scifi_btn1MouseClicked(evt);
            }
        });
        scifi_btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scifi_btn1ActionPerformed(evt);
            }
        });
        jPanel48.add(scifi_btn1);
        scifi_btn1.setBounds(990, 0, 20, 20);

        scifi_btn2.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16 (1).png")); // NOI18N
        scifi_btn2.setContentAreaFilled(false);
        scifi_btn2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        scifi_btn2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                scifi_btn2MouseClicked(evt);
            }
        });
        scifi_btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scifi_btn2ActionPerformed(evt);
            }
        });
        jPanel48.add(scifi_btn2);
        scifi_btn2.setBounds(1020, 0, 20, 20);

        jPanel3.add(jPanel48);
        jPanel48.setBounds(0, 2210, 1910, 20);

        jPanel42.setBackground(new java.awt.Color(0, 0, 0));
        jPanel42.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel42MouseExited(evt);
            }
        });
        jPanel42.setLayout(null);

        drama_btn1.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16.png")); // NOI18N
        drama_btn1.setContentAreaFilled(false);
        drama_btn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        drama_btn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                drama_btn1MouseClicked(evt);
            }
        });
        drama_btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drama_btn1ActionPerformed(evt);
            }
        });
        jPanel42.add(drama_btn1);
        drama_btn1.setBounds(990, 0, 20, 20);

        drama_btn2.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16 (1).png")); // NOI18N
        drama_btn2.setContentAreaFilled(false);
        drama_btn2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        drama_btn2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                drama_btn2MouseClicked(evt);
            }
        });
        drama_btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drama_btn2ActionPerformed(evt);
            }
        });
        jPanel42.add(drama_btn2);
        drama_btn2.setBounds(1020, 0, 20, 20);

        jPanel3.add(jPanel42);
        jPanel42.setBounds(0, 1820, 1910, 20);

        scifi_panel.setLayout(null);

        jPanel46.setBackground(new java.awt.Color(0, 0, 0));
        jPanel46.setLayout(null);

        jButton79.setFont(new java.awt.Font("Tahoma", 0, 3)); // NOI18N
        jButton79.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\anthariksham.png")); // NOI18N
        jButton79.setText("anthariksham");
        jButton79.setActionCommand("");
        jButton79.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton79.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton79.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton79ActionPerformed(evt);
            }
        });
        jPanel46.add(jButton79);
        jButton79.setBounds(0, 0, 340, 190);

        jButton80.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\apollo18.png")); // NOI18N
        jButton80.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton80.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton80.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton80ActionPerformed(evt);
            }
        });
        jPanel46.add(jButton80);
        jButton80.setBounds(380, 0, 340, 190);

        jButton81.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\arrival.png")); // NOI18N
        jButton81.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton81.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton81.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton81ActionPerformed(evt);
            }
        });
        jPanel46.add(jButton81);
        jButton81.setBounds(760, 0, 340, 190);

        jButton82.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\inception.png")); // NOI18N
        jButton82.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton82.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton82.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton82ActionPerformed(evt);
            }
        });
        jPanel46.add(jButton82);
        jButton82.setBounds(1140, 0, 340, 190);

        jButton83.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\interstellar.png")); // NOI18N
        jButton83.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton83.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton83.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton83ActionPerformed(evt);
            }
        });
        jPanel46.add(jButton83);
        jButton83.setBounds(1520, 0, 340, 190);

        scifi_panel.add(jPanel46);
        jPanel46.setBounds(0, 0, 1910, 230);

        jPanel43.setVisible(false);
        jPanel43.setBackground(new java.awt.Color(0, 0, 0));
        jPanel43.setLayout(null);

        jButton85.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\robo2.0.png")); // NOI18N
        jButton85.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton85.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton85.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton85ActionPerformed(evt);
            }
        });
        jPanel43.add(jButton85);
        jButton85.setBounds(0, 0, 340, 190);

        jButton86.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\virus.png")); // NOI18N
        jButton86.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton86.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton86.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton86ActionPerformed(evt);
            }
        });
        jPanel43.add(jButton86);
        jButton86.setBounds(380, 0, 340, 190);

        scifi_panel.add(jPanel43);
        jPanel43.setBounds(0, 0, 1910, 230);

        jPanel3.add(scifi_panel);
        scifi_panel.setBounds(0, 1980, 1910, 230);

        horror_panel.setLayout(null);

        jPanel45.setBackground(new java.awt.Color(0, 0, 0));
        jPanel45.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel45MouseExited(evt);
            }
        });
        jPanel45.setLayout(null);

        jButton73.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\eerie.png")); // NOI18N
        jButton73.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton73.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton73.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton73ActionPerformed(evt);
            }
        });
        jPanel45.add(jButton73);
        jButton73.setBounds(0, 0, 340, 190);

        jButton74.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\sinister.png")); // NOI18N
        jButton74.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton74.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton74.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton74ActionPerformed(evt);
            }
        });
        jPanel45.add(jButton74);
        jButton74.setBounds(380, 0, 340, 190);

        jButton75.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the conjuring.png")); // NOI18N
        jButton75.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton75.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton75.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton75ActionPerformed(evt);
            }
        });
        jPanel45.add(jButton75);
        jButton75.setBounds(760, 0, 340, 190);

        jButton76.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\gameover.png")); // NOI18N
        jButton76.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton76.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton76.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton76ActionPerformed(evt);
            }
        });
        jPanel45.add(jButton76);
        jButton76.setBounds(1140, 0, 340, 190);

        jButton77.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\it.png")); // NOI18N
        jButton77.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton77.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton77.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton77ActionPerformed(evt);
            }
        });
        jPanel45.add(jButton77);
        jButton77.setBounds(1520, 0, 340, 190);

        horror_panel.add(jPanel45);
        jPanel45.setBounds(0, 0, 1910, 230);

        jPanel3.add(horror_panel);
        horror_panel.setBounds(0, 2340, 1910, 230);

        jPanel40.add(jPanel3);
        jPanel3.setBounds(0, 0, 1930, 3120);

        jPanel13.setVisible(false);
        jPanel13.setBackground(new java.awt.Color(0, 0, 0));
        jPanel13.setLayout(null);

        jPanel89.setOpaque(false);
        jPanel89.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel89MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel89MouseExited(evt);
            }
        });
        jPanel89.setLayout(null);
        jPanel13.add(jPanel89);
        jPanel89.setBounds(0, 920, 900, 220);

        jPanel53.setBackground(new java.awt.Color(0, 0, 0));
        jPanel53.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel53.setOpaque(false);
        jPanel53.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel53MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel53MouseExited(evt);
            }
        });
        jPanel53.setLayout(null);

        jLabel71.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the great heist.png")); // NOI18N
        jLabel71.setText("the great heist");
        jLabel71.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel71MouseEntered(evt);
            }
        });
        jPanel53.add(jLabel71);
        jLabel71.setBounds(10, 10, 340, 190);

        jLabel72.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel72.setForeground(new java.awt.Color(255, 255, 255));
        jLabel72.setText("<html>A child bride grows up to be an enigmatic woman <br>presiding over her household, harboring a <br>painful past as supernatural murders of men plague her village.</html>");
        jPanel53.add(jLabel72);
        jLabel72.setBounds(380, 10, 440, 110);

        jLabel73.setFont(new java.awt.Font("Gadugi", 0, 19)); // NOI18N
        jLabel73.setForeground(new java.awt.Color(255, 255, 255));
        jLabel73.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Mystery  <font style=\"color:red;size:20px\">&#9679;</font>Drama  <font style=\"color:red;size:20px\">&#9679;</font>Thriller  </p> </html> ");
        jPanel53.add(jLabel73);
        jLabel73.setBounds(380, 180, 230, 30);

        jPanel13.add(jPanel53);
        jPanel53.setBounds(0, 920, 900, 220);

        jPanel88.setOpaque(false);
        jPanel88.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel88MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel88MouseExited(evt);
            }
        });
        jPanel88.setLayout(null);
        jPanel13.add(jPanel88);
        jPanel88.setBounds(950, 920, 900, 220);

        jPanel52.setBackground(new java.awt.Color(0, 0, 0));
        jPanel52.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel52.setOpaque(false);
        jPanel52.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel52MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel52MouseExited(evt);
            }
        });
        jPanel52.setLayout(null);

        jLabel68.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\cursed.png")); // NOI18N
        jLabel68.setText("cursed");
        jLabel68.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel68MouseEntered(evt);
            }
        });
        jPanel52.add(jLabel68);
        jLabel68.setBounds(10, 10, 340, 190);

        jLabel69.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel69.setForeground(new java.awt.Color(255, 255, 255));
        jLabel69.setText("<html>A child bride grows up to be an enigmatic woman <br>presiding over her household, harboring a <br>painful past as supernatural murders of men plague her village.</html>");
        jPanel52.add(jLabel69);
        jLabel69.setBounds(380, 10, 440, 81);

        jLabel70.setFont(new java.awt.Font("Gadugi", 0, 19)); // NOI18N
        jLabel70.setForeground(new java.awt.Color(255, 255, 255));
        jLabel70.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Super Hero  <font style=\"color:red;size:20px\">&#9679;</font>War  <font style=\"color:red;size:20px\">&#9679;</font>Thriller  </p> </html> ");
        jPanel52.add(jLabel70);
        jLabel70.setBounds(380, 180, 240, 30);

        jPanel13.add(jPanel52);
        jPanel52.setBounds(950, 920, 900, 220);

        jPanel87.setOpaque(false);
        jPanel87.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel87MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel87MouseExited(evt);
            }
        });
        jPanel87.setLayout(null);
        jPanel13.add(jPanel87);
        jPanel87.setBounds(950, 620, 900, 220);

        jPanel51.setBackground(new java.awt.Color(0, 0, 0));
        jPanel51.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel51.setOpaque(false);
        jPanel51.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel51MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel51MouseExited(evt);
            }
        });
        jPanel51.setLayout(null);

        jLabel65.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\signs.png")); // NOI18N
        jLabel65.setText("signs");
        jLabel65.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel65MouseEntered(evt);
            }
        });
        jPanel51.add(jLabel65);
        jLabel65.setBounds(10, 10, 340, 190);

        jLabel66.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel66.setForeground(new java.awt.Color(255, 255, 255));
        jLabel66.setText("<html>A child bride grows up to be an enigmatic woman <br>presiding over her household, harboring a <br>painful past as supernatural murders of men plague her village.</html>");
        jPanel51.add(jLabel66);
        jLabel66.setBounds(380, 10, 440, 110);

        jLabel67.setFont(new java.awt.Font("Gadugi", 0, 19)); // NOI18N
        jLabel67.setForeground(new java.awt.Color(255, 255, 255));
        jLabel67.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Suspense  <font style=\"color:red;size:20px\">&#9679;</font>Thriller  <font style=\"color:red;size:20px\">&#9679;</font>Mystery  </p> </html> ");
        jPanel51.add(jLabel67);
        jLabel67.setBounds(380, 180, 250, 30);

        jPanel13.add(jPanel51);
        jPanel51.setBounds(950, 620, 900, 220);

        jPanel86.setOpaque(false);
        jPanel86.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel86MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel86MouseExited(evt);
            }
        });
        jPanel86.setLayout(null);
        jPanel13.add(jPanel86);
        jPanel86.setBounds(0, 620, 900, 220);

        jPanel50.setBackground(new java.awt.Color(0, 0, 0));
        jPanel50.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel50.setOpaque(false);
        jPanel50.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel50MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel50MouseExited(evt);
            }
        });
        jPanel50.setLayout(null);

        //jLabel62.setEnabled(false);
        jLabel62.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\project power.png")); // NOI18N
        jLabel62.setText("project power");
        jLabel62.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel62MouseEntered(evt);
            }
        });
        jPanel50.add(jLabel62);
        jLabel62.setBounds(10, 10, 340, 190);

        //jLabel63.setEnabled(false);
        jLabel63.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel63.setForeground(new java.awt.Color(255, 255, 255));
        jLabel63.setText("<html>A child bride grows up to be an enigmatic woman <br>presiding over her household, harboring a <br>painful past as supernatural murders of men plague her village.</html>");
        jPanel50.add(jLabel63);
        jLabel63.setBounds(380, 10, 440, 100);

        jLabel64.setFont(new java.awt.Font("Gadugi", 0, 19)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(255, 255, 255));
        jLabel64.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Suspense  <font style=\"color:red;size:20px\">&#9679;</font>Thriller  <font style=\"color:red;size:20px\">&#9679;</font>Mystery  </p> </html> ");
        jPanel50.add(jLabel64);
        jLabel64.setBounds(380, 170, 250, 30);

        jPanel13.add(jPanel50);
        jPanel50.setBounds(0, 620, 900, 220);

        jPanel85.setOpaque(false);
        jPanel85.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel85MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel85MouseExited(evt);
            }
        });
        jPanel85.setLayout(null);
        jPanel13.add(jPanel85);
        jPanel85.setBounds(960, 330, 900, 220);

        jPanel49.setBackground(new java.awt.Color(0, 0, 0));
        jPanel49.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel49.setOpaque(false);
        jPanel49.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel49MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel49MouseExited(evt);
            }
        });
        jPanel49.setLayout(null);

        jLabel59.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\stranger.png")); // NOI18N
        jLabel59.setText("stranger");
        jLabel59.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel59MouseEntered(evt);
            }
        });
        jPanel49.add(jLabel59);
        jLabel59.setBounds(10, 10, 340, 190);

        jLabel60.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(255, 255, 255));
        jLabel60.setText("<html>With the help of a gutsy female detective, a <br>prosecutor who has lost the ability to feel<br> empathy tackles a murder case amid political corruption.</html> ");
        jPanel49.add(jLabel60);
        jLabel60.setBounds(380, 10, 400, 110);

        jLabel61.setFont(new java.awt.Font("Gadugi", 0, 19)); // NOI18N
        jLabel61.setForeground(new java.awt.Color(255, 255, 255));
        jLabel61.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Mystery  <font style=\"color:red;size:20px\">&#9679;</font>scifi  <font style=\"color:red;size:20px\">&#9679;</font>Thriller  </p> </html> ");
        jPanel49.add(jLabel61);
        jLabel61.setBounds(380, 170, 210, 30);

        jPanel13.add(jPanel49);
        jPanel49.setBounds(960, 330, 900, 220);

        jPanel75.setOpaque(false);
        jPanel75.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel75MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel75MouseExited(evt);
            }
        });
        jPanel75.setLayout(null);
        jPanel13.add(jPanel75);
        jPanel75.setBounds(0, 330, 900, 220);

        jPanel36.setBackground(new java.awt.Color(0, 0, 0));
        jPanel36.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel36.setOpaque(false);
        jPanel36.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel36MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel36MouseExited(evt);
            }
        });
        jPanel36.setLayout(null);

        jLabel56.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\skyscraper.png")); // NOI18N
        jLabel56.setText("skyscraper");
        jLabel56.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel56.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel56MouseEntered(evt);
            }
        });
        jPanel36.add(jLabel56);
        jLabel56.setBounds(10, 10, 340, 190);

        jLabel57.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(255, 255, 255));
        jLabel57.setText("<html>When terrorists attack the tallest building in the <br>world, a security consultant will do anything <br>to save his family from the carnage.</html> ");
        jPanel36.add(jLabel57);
        jLabel57.setBounds(380, 10, 420, 80);

        jLabel58.setFont(new java.awt.Font("Gadugi", 0, 17)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(255, 255, 255));
        jLabel58.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Suspense  <font style=\"color:red;size:20px\">&#9679;</font>Action  <font style=\"color:red;size:20px\">&#9679;</font>Thriller  </p> </html> ");
        jPanel36.add(jLabel58);
        jLabel58.setBounds(370, 170, 220, 30);

        jPanel13.add(jPanel36);
        jPanel36.setBounds(0, 330, 900, 220);

        jPanel84.setOpaque(false);
        jPanel84.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel84MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel84MouseExited(evt);
            }
        });
        jPanel84.setLayout(null);
        jPanel13.add(jPanel84);
        jPanel84.setBounds(950, 20, 900, 220);

        jPanel34.setBackground(new java.awt.Color(0, 0, 0));
        jPanel34.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel34.setOpaque(false);
        jPanel34.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel34MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel34MouseExited(evt);
            }
        });
        jPanel34.setLayout(null);

        jLabel53.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\3%.png")); // NOI18N
        jLabel53.setText("3%");
        jLabel53.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel53MouseEntered(evt);
            }
        });
        jPanel34.add(jLabel53);
        jLabel53.setBounds(10, 10, 340, 190);

        jLabel54.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel54.setForeground(new java.awt.Color(255, 255, 255));
        jLabel54.setText("<html>In a future where the elite inhabit an island <br>paradise far from the crowded slums, you get one <br>chance to join the 3% saved from squalor.</html> ");
        jPanel34.add(jLabel54);
        jLabel54.setBounds(380, 10, 440, 80);

        jLabel55.setFont(new java.awt.Font("Gadugi", 0, 19)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(255, 255, 255));
        jLabel55.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Korean  <font style=\"color:red;size:20px\">&#9679;</font>War  <font style=\"color:red;size:20px\">&#9679;</font>Drama  </p> </html> ");
        jPanel34.add(jLabel55);
        jLabel55.setBounds(380, 170, 200, 30);

        jPanel13.add(jPanel34);
        jPanel34.setBounds(950, 20, 900, 220);

        jPanel90.setOpaque(false);
        jPanel90.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel90MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel90MouseExited(evt);
            }
        });
        jPanel90.setLayout(null);
        jPanel13.add(jPanel90);
        jPanel90.setBounds(0, 20, 900, 220);

        jPanel31.setBackground(new java.awt.Color(0, 0, 0));
        jPanel31.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel31.setOpaque(false);
        jPanel31.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel31MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel31MouseExited(evt);
            }
        });
        jPanel31.setLayout(null);

        jLabel49.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\bulbbul.png")); // NOI18N
        jLabel49.setText("bulbbul");
        jLabel49.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel49MouseEntered(evt);
            }
        });
        jPanel31.add(jLabel49);
        jLabel49.setBounds(10, 10, 340, 190);

        jLabel50.setFont(new java.awt.Font("Gadugi", 0, 20)); // NOI18N
        jLabel50.setForeground(new java.awt.Color(255, 255, 255));
        jLabel50.setText("<html>A child bride grows up to be an enigmatic <br>woman presiding over her household, <br> harboring a painful past as supernatural <br>murders of men plague her village.</html>");
        jLabel50.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel50MouseEntered(evt);
            }
        });
        jPanel31.add(jLabel50);
        jLabel50.setBounds(380, 10, 370, 110);

        jLabel52.setFont(new java.awt.Font("Gadugi", 0, 19)); // NOI18N
        jLabel52.setForeground(new java.awt.Color(255, 255, 255));
        jLabel52.setText("<html> <p><font style=\"color:red;size:20px\">&#9679;</font>Suspense  <font style=\"color:red;size:20px\">&#9679;</font>Thriller  <font style=\"color:red;size:20px\">&#9679;</font>Mystery  </p> </html> ");
        jPanel31.add(jLabel52);
        jLabel52.setBounds(380, 174, 250, 26);

        jPanel13.add(jPanel31);
        jPanel31.setBounds(0, 20, 900, 220);

        //jPanel35.setVisible(false);
        jPanel35.setBackground(new java.awt.Color(0, 0, 0));
        jPanel35.setOpaque(false);
        jPanel35.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        sug1.setBackground(new java.awt.Color(0, 0, 0));
        sug1.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-play-30.png")); // NOI18N
        sug1.setContentAreaFilled(false);
        sug1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sug1ActionPerformed(evt);
            }
        });
        jPanel35.add(sug1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-1, 5, 40, -1));

        sug2.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-plus-30.png")); // NOI18N
        sug2.setContentAreaFilled(false);
        sug2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                sug2MouseEntered(evt);
            }
        });
        sug2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sug2ActionPerformed(evt);
            }
        });
        jPanel35.add(sug2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 40, -1));

        sug3.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-star-35.png")); // NOI18N
        sug3.setContentAreaFilled(false);
        jPanel35.add(sug3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 40, 40));

        jPanel13.add(jPanel35);
        jPanel35.setBounds(1690, 1220, 40, 190);

        jLabel51.setBackground(new java.awt.Color(51, 51, 51));
        jLabel51.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 0, new java.awt.Color(0, 204, 204)));
        jLabel51.setOpaque(true);
        jPanel13.add(jLabel51);
        jLabel51.setBounds(40, 1210, 0, 220);

        jPanel40.add(jPanel13);
        jPanel13.setBounds(0, 0, 1930, 3120);

        jPanel12.setVisible(false);
        jPanel12.setBackground(new java.awt.Color(0, 0, 0));
        jPanel12.setLayout(null);

        jPanel14.setBackground(new java.awt.Color(0, 0, 0));
        jPanel14.setAutoscrolls(true);
        jPanel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel14MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel14MouseExited(evt);
            }
        });
        jPanel14.setLayout(null);

        jButton224.setForeground(new java.awt.Color(255, 0, 0));
        jButton224.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\roma.png")); // NOI18N
        jButton224.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton224.setContentAreaFilled(false);
        jButton224.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton224.setOpaque(true);
        jButton224.setRolloverEnabled(false);
        jButton224.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton224MouseEntered(evt);
            }
        });
        jButton224.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton224ActionPerformed(evt);
            }
        });
        jPanel14.add(jButton224);
        jButton224.setBounds(60, 20, 340, 190);

        jButton227.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\umrika.png")); // NOI18N
        jButton227.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton227.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton227.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton227ActionPerformed(evt);
            }
        });
        jPanel14.add(jButton227);
        jButton227.setBounds(410, 20, 340, 190);

        jButton228.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the platform.png")); // NOI18N
        jButton228.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton228.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel14.add(jButton228);
        jButton228.setBounds(760, 20, 340, 190);

        jButton229.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\strong island.png")); // NOI18N
        jButton229.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton229.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel14.add(jButton229);
        jButton229.setBounds(1110, 20, 340, 190);

        jButton230.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\mudbound.png")); // NOI18N
        jButton230.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton230.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel14.add(jButton230);
        jButton230.setBounds(1460, 20, 340, 190);

        jButton225.setBackground(new java.awt.Color(0, 0, 0));
        jButton225.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-chevron-left-40.png")); // NOI18N
        jButton225.setContentAreaFilled(false);
        jButton225.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton225.setOpaque(true);
        jButton225.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton225ActionPerformed(evt);
            }
        });
        jPanel14.add(jButton225);
        jButton225.setBounds(10, 90, 30, 40);

        jButton226.setEnabled(false);
        jButton226.setBackground(new java.awt.Color(0, 0, 0));
        jButton226.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-chevron-left-40(1).png")); // NOI18N
        jButton226.setContentAreaFilled(false);
        jButton226.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton226.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton226ActionPerformed(evt);
            }
        });
        jPanel14.add(jButton226);
        jButton226.setBounds(1840, 100, 40, 40);

        jPanel12.add(jPanel14);
        jPanel14.setBounds(0, 630, 1910, 230);

        jPanel16.setBackground(new java.awt.Color(0, 0, 0));
        jPanel16.setOpaque(false);
        jPanel16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel16MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel16MouseExited(evt);
            }
        });
        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton231.setForeground(new java.awt.Color(255, 0, 0));
        jButton231.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the irishman.png")); // NOI18N
        jButton231.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton231.setContentAreaFilled(false);
        jButton231.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton231.setOpaque(true);
        jButton231.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton231MouseEntered(evt);
            }
        });
        jButton231.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton231ActionPerformed(evt);
            }
        });
        jPanel16.add(jButton231, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 340, 190));

        jButton232.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\icarus.png")); // NOI18N
        jButton232.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton232.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel16.add(jButton232, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 20, 340, 190));

        jButton233.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\raat akeli hai.png")); // NOI18N
        jButton233.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton233.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel16.add(jButton233, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 20, 340, 190));

        jButton234.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\operation finale.png")); // NOI18N
        jButton234.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton234.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel16.add(jButton234, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 20, 340, 190));

        jButton235.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the two popes.png")); // NOI18N
        jButton235.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton235.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel16.add(jButton235, new org.netbeans.lib.awtextra.AbsoluteConstraints(1460, 20, 340, 190));

        jPanel12.add(jPanel16);
        jPanel16.setBounds(0, 630, 1910, 230);

        jPanel19.setBackground(new java.awt.Color(0, 0, 0));
        jPanel19.setAutoscrolls(true);
        jPanel19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel19MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel19MouseExited(evt);
            }
        });
        jPanel19.setLayout(null);

        jButton248.setForeground(new java.awt.Color(255, 0, 0));
        jButton248.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\ala vaikunta puram lo1.png")); // NOI18N
        jButton248.setBorder(null);
        jButton248.setContentAreaFilled(false);
        jButton248.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton248.setOpaque(true);
        jButton248.setRolloverEnabled(false);
        jButton248.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton248MouseEntered(evt);
            }
        });
        jButton248.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton248ActionPerformed(evt);
            }
        });
        jPanel19.add(jButton248);
        jButton248.setBounds(60, 20, 340, 190);

        jButton249.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\dangal.png")); // NOI18N
        jButton249.setBorder(null);
        jButton249.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton249.setName("dangal"); // NOI18N
        jButton249.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton249MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton249MouseExited(evt);
            }
        });
        jButton249.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton249ActionPerformed(evt);
            }
        });
        jPanel19.add(jButton249);
        jButton249.setBounds(410, 20, 340, 190);

        jButton250.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\betaal.png")); // NOI18N
        jButton250.setToolTipText("");
        jButton250.setBorder(null);
        jButton250.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton250.setName("betaal"); // NOI18N
        jButton250.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton250MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton250MouseExited(evt);
            }
        });
        jPanel19.add(jButton250);
        jButton250.setBounds(760, 20, 340, 190);

        jButton251.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\tunnel.png")); // NOI18N
        jButton251.setBorder(null);
        jButton251.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel19.add(jButton251);
        jButton251.setBounds(1110, 20, 340, 190);

        jButton252.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\beeshma.png")); // NOI18N
        jButton252.setBorder(null);
        jButton252.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel19.add(jButton252);
        jButton252.setBounds(1460, 20, 340, 190);

        jButton253.setBackground(new java.awt.Color(0, 0, 0));
        jButton253.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-chevron-left-40.png")); // NOI18N
        jButton253.setContentAreaFilled(false);
        jButton253.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton253.setOpaque(true);
        jButton253.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton253ActionPerformed(evt);
            }
        });
        jPanel19.add(jButton253);
        jButton253.setBounds(10, 90, 30, 40);

        jButton254.setEnabled(false);
        jButton254.setBackground(new java.awt.Color(0, 0, 0));
        jButton254.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-chevron-left-40(1).png")); // NOI18N
        jButton254.setContentAreaFilled(false);
        jButton254.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton254.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton254ActionPerformed(evt);
            }
        });
        jPanel19.add(jButton254);
        jButton254.setBounds(1840, 100, 40, 40);

        jPanel12.add(jPanel19);
        jPanel19.setBounds(0, 100, 1910, 230);

        //jPanel20.setVisible(false);
        jPanel20.setBackground(new java.awt.Color(0, 0, 0));
        jPanel20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel20MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel20MouseExited(evt);
            }
        });
        jPanel20.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton255.setForeground(new java.awt.Color(255, 0, 0));
        jButton255.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\forensic.png")); // NOI18N
        jButton255.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton255.setContentAreaFilled(false);
        jButton255.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton255.setOpaque(true);
        jButton255.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton255MouseEntered(evt);
            }
        });
        jButton255.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton255ActionPerformed(evt);
            }
        });
        jPanel20.add(jButton255, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 340, 190));

        //jButton256.setEnabled(false);
        //jButton256.setVisible(false);
        jButton256.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\peaky blinders.png")); // NOI18N
        jButton256.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton256.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel20.add(jButton256, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 20, 340, 190));

        //jButton257.setEnabled(false);
        //jButton257.setVisible(false);
        jButton257.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\money heist_tendingnow.png")); // NOI18N
        jButton257.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton257.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel20.add(jButton257, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 20, 340, 190));

        jButton258.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\super deluxe.png")); // NOI18N
        jButton258.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton258.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel20.add(jButton258, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 20, 340, 190));

        jButton259.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\sarkar_trendingnow.png")); // NOI18N
        jButton259.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton259.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel20.add(jButton259, new org.netbeans.lib.awtextra.AbsoluteConstraints(1460, 20, 340, 190));

        jPanel12.add(jPanel20);
        jPanel20.setBounds(0, 100, 1910, 230);

        jPanel17.setBackground(new java.awt.Color(0, 0, 0));
        jPanel17.setAutoscrolls(true);
        jPanel17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel17MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel17MouseExited(evt);
            }
        });
        jPanel17.setLayout(null);

        jButton236.setForeground(new java.awt.Color(255, 0, 0));
        jButton236.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\detective pikachu.png")); // NOI18N
        jButton236.setBorder(null);
        jButton236.setContentAreaFilled(false);
        jButton236.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton236.setName("detective pikachu"); // NOI18N
        jButton236.setOpaque(true);
        jButton236.setRolloverEnabled(false);
        jButton236.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton236MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton236MouseExited(evt);
            }
        });
        jButton236.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton236ActionPerformed(evt);
            }
        });
        jPanel17.add(jButton236);
        jButton236.setBounds(60, 20, 340, 190);

        jButton237.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\real detective.png")); // NOI18N
        jButton237.setBorder(null);
        jButton237.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton237.setName("real detective"); // NOI18N
        jButton237.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton237MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton237MouseExited(evt);
            }
        });
        jButton237.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton237ActionPerformed(evt);
            }
        });
        jPanel17.add(jButton237);
        jButton237.setBounds(410, 20, 340, 190);

        jButton238.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\sherlock.png")); // NOI18N
        jButton238.setBorder(null);
        jButton238.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton238.setName("sherlock"); // NOI18N
        jButton238.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton238MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton238MouseExited(evt);
            }
        });
        jButton238.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton238ActionPerformed(evt);
            }
        });
        jPanel17.add(jButton238);
        jButton238.setBounds(760, 20, 340, 190);

        jButton239.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\mystic river.png")); // NOI18N
        jButton239.setBorder(null);
        jButton239.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton239.setName("mystic river"); // NOI18N
        jButton239.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton239MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton239MouseExited(evt);
            }
        });
        jPanel17.add(jButton239);
        jButton239.setBounds(1110, 20, 340, 190);

        jButton240.setBorder(null);
        jButton240.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton240.setName("nancy drew"); // NOI18N
        jButton240.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton240MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton240MouseExited(evt);
            }
        });
        jPanel17.add(jButton240);
        jButton240.setBounds(1460, 20, 340, 190);

        jButton241.setBackground(new java.awt.Color(0, 0, 0));
        jButton241.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-chevron-left-40.png")); // NOI18N
        jButton241.setContentAreaFilled(false);
        jButton241.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton241.setOpaque(true);
        jButton241.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton241ActionPerformed(evt);
            }
        });
        jPanel17.add(jButton241);
        jButton241.setBounds(10, 90, 30, 40);

        jButton242.setEnabled(false);
        jButton242.setBackground(new java.awt.Color(0, 0, 0));
        jButton242.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-chevron-left-40(1).png")); // NOI18N
        jButton242.setContentAreaFilled(false);
        jButton242.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton242.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton242ActionPerformed(evt);
            }
        });
        jPanel17.add(jButton242);
        jButton242.setBounds(1840, 100, 40, 40);

        jPanel12.add(jPanel17);
        jPanel17.setBounds(0, 370, 1910, 230);

        //jPanel18.setVisible(false);
        jPanel18.setBackground(new java.awt.Color(0, 0, 0));
        jPanel18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel18MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel18MouseExited(evt);
            }
        });
        jPanel18.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton243.setForeground(new java.awt.Color(255, 0, 0));
        jButton243.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the interview.png")); // NOI18N
        jButton243.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton243.setContentAreaFilled(false);
        jButton243.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton243.setName("the interview"); // NOI18N
        jButton243.setOpaque(true);
        jButton243.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton243MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton243MouseExited(evt);
            }
        });
        jButton243.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton243ActionPerformed(evt);
            }
        });
        jPanel18.add(jButton243, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 340, 190));

        jButton244.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\article 15.png")); // NOI18N
        jButton244.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton244.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton244.setName("article 15"); // NOI18N
        jButton244.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton244MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton244MouseExited(evt);
            }
        });
        jPanel18.add(jButton244, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 20, 340, 190));

        jButton245.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the indian detective.png")); // NOI18N
        jButton245.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton245.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton245.setName("the indian detective"); // NOI18N
        jButton245.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton245MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton245MouseExited(evt);
            }
        });
        jPanel18.add(jButton245, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 20, 340, 190));

        jButton246.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\murder mystery.png")); // NOI18N
        jButton246.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton246.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton246.setName("murder mystery"); // NOI18N
        jButton246.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton246MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton246MouseExited(evt);
            }
        });
        jPanel18.add(jButton246, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 20, 340, 190));

        jButton247.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\706.png")); // NOI18N
        jButton247.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton247.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton247.setName("706"); // NOI18N
        jButton247.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton247MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton247MouseExited(evt);
            }
        });
        jPanel18.add(jButton247, new org.netbeans.lib.awtextra.AbsoluteConstraints(1460, 20, 340, 190));

        jPanel12.add(jPanel18);
        jPanel18.setBounds(0, 370, 1910, 230);

        jPanel22.setBackground(new java.awt.Color(0, 0, 0));
        jPanel22.setAutoscrolls(true);
        jPanel22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel22MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel22MouseExited(evt);
            }
        });
        jPanel22.setLayout(null);

        jButton260.setForeground(new java.awt.Color(255, 0, 0));
        jButton260.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\little things.png")); // NOI18N
        jButton260.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton260.setContentAreaFilled(false);
        jButton260.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton260.setOpaque(true);
        jButton260.setRolloverEnabled(false);
        jButton260.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton260MouseEntered(evt);
            }
        });
        jButton260.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton260ActionPerformed(evt);
            }
        });
        jPanel22.add(jButton260);
        jButton260.setBounds(60, 20, 340, 190);

        jButton261.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\lust stories.png")); // NOI18N
        jButton261.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton261.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton261.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton261ActionPerformed(evt);
            }
        });
        jPanel22.add(jButton261);
        jButton261.setBounds(410, 20, 340, 190);

        jButton262.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\sacred games.png")); // NOI18N
        jButton262.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton262.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel22.add(jButton262);
        jButton262.setBounds(760, 20, 340, 190);

        jButton263.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\jamtara_topshows.png")); // NOI18N
        jButton263.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton263.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel22.add(jButton263);
        jButton263.setBounds(1110, 20, 340, 190);

        jButton264.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\bard of blood.png")); // NOI18N
        jButton264.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton264.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel22.add(jButton264);
        jButton264.setBounds(1460, 20, 340, 190);

        jButton265.setBackground(new java.awt.Color(0, 0, 0));
        jButton265.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-chevron-left-40.png")); // NOI18N
        jButton265.setContentAreaFilled(false);
        jButton265.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton265.setOpaque(true);
        jButton265.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton265ActionPerformed(evt);
            }
        });
        jPanel22.add(jButton265);
        jButton265.setBounds(10, 90, 30, 40);

        jButton266.setEnabled(false);
        jButton266.setBackground(new java.awt.Color(0, 0, 0));
        jButton266.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-chevron-left-40(1).png")); // NOI18N
        jButton266.setContentAreaFilled(false);
        jButton266.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton266.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton266ActionPerformed(evt);
            }
        });
        jPanel22.add(jButton266);
        jButton266.setBounds(1840, 100, 40, 40);

        jPanel12.add(jPanel22);
        jPanel22.setBounds(0, 910, 1910, 230);

        jPanel23.setBackground(new java.awt.Color(0, 0, 0));
        jPanel23.setOpaque(false);
        jPanel23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel23MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel23MouseExited(evt);
            }
        });
        jPanel23.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton267.setForeground(new java.awt.Color(255, 0, 0));
        jButton267.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\ghoul.png")); // NOI18N
        jButton267.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton267.setContentAreaFilled(false);
        jButton267.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton267.setOpaque(true);
        jButton267.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton267MouseEntered(evt);
            }
        });
        jButton267.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton267ActionPerformed(evt);
            }
        });
        jPanel23.add(jButton267, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 340, 190));

        jButton268.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the family man.png")); // NOI18N
        jButton268.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton268.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel23.add(jButton268, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 20, 340, 190));

        jButton269.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\delhi crime_topshows.png")); // NOI18N
        jButton269.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton269.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel23.add(jButton269, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 20, 340, 190));

        jButton270.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\she.png")); // NOI18N
        jButton270.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton270.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel23.add(jButton270, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 20, 340, 190));

        jButton271.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\leila.png")); // NOI18N
        jButton271.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton271.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel23.add(jButton271, new org.netbeans.lib.awtextra.AbsoluteConstraints(1460, 20, 340, 190));

        jPanel12.add(jPanel23);
        jPanel23.setBounds(0, 910, 1910, 230);

        jPanel24.setBackground(new java.awt.Color(0, 0, 0));
        jPanel24.setAutoscrolls(true);
        jPanel24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel24MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel24MouseExited(evt);
            }
        });
        jPanel24.setLayout(null);

        jButton272.setForeground(new java.awt.Color(255, 0, 0));
        jButton272.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\forrest gump.png")); // NOI18N
        jButton272.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton272.setContentAreaFilled(false);
        jButton272.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton272.setOpaque(true);
        jButton272.setRolloverEnabled(false);
        jButton272.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton272MouseEntered(evt);
            }
        });
        jButton272.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton272ActionPerformed(evt);
            }
        });
        jPanel24.add(jButton272);
        jButton272.setBounds(60, 20, 340, 190);

        jButton273.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\hugo.png")); // NOI18N
        jButton273.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton273.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton273.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton273ActionPerformed(evt);
            }
        });
        jPanel24.add(jButton273);
        jButton273.setBounds(410, 20, 340, 190);

        jButton274.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the revenant.png")); // NOI18N
        jButton274.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton274.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel24.add(jButton274);
        jButton274.setBounds(760, 20, 340, 190);

        jButton275.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\crash.png")); // NOI18N
        jButton275.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton275.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel24.add(jButton275);
        jButton275.setBounds(1110, 20, 340, 190);

        jButton276.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the untouchables.png")); // NOI18N
        jButton276.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton276.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel24.add(jButton276);
        jButton276.setBounds(1460, 20, 340, 190);

        jPanel12.add(jPanel24);
        jPanel24.setBounds(0, 1200, 1910, 230);

        jPanel25.setBackground(new java.awt.Color(0, 0, 0));
        jPanel25.setAutoscrolls(true);
        jPanel25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel25MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel25MouseExited(evt);
            }
        });
        jPanel25.setLayout(null);

        jButton277.setForeground(new java.awt.Color(255, 0, 0));
        jButton277.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\bulbbul.png")); // NOI18N
        jButton277.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton277.setContentAreaFilled(false);
        jButton277.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton277.setOpaque(true);
        jButton277.setRolloverEnabled(false);
        jButton277.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton277MouseEntered(evt);
            }
        });
        jButton277.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton277ActionPerformed(evt);
            }
        });
        jPanel25.add(jButton277);
        jButton277.setBounds(60, 20, 340, 190);

        jButton278.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\andhahun.png")); // NOI18N
        jButton278.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton278.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton278.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton278ActionPerformed(evt);
            }
        });
        jPanel25.add(jButton278);
        jButton278.setBounds(410, 20, 340, 190);

        jButton279.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\drive.png")); // NOI18N
        jButton279.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton279.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel25.add(jButton279);
        jButton279.setBounds(760, 20, 340, 190);

        jButton280.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\ee nagaraniki emaindi.png")); // NOI18N
        jButton280.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton280.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel25.add(jButton280);
        jButton280.setBounds(1110, 20, 340, 190);

        jButton281.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\kappela.png")); // NOI18N
        jButton281.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton281.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel25.add(jButton281);
        jButton281.setBounds(1460, 20, 340, 190);

        jButton282.setBackground(new java.awt.Color(0, 0, 0));
        jButton282.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-chevron-left-40.png")); // NOI18N
        jButton282.setContentAreaFilled(false);
        jButton282.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton282.setOpaque(true);
        jButton282.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton282ActionPerformed(evt);
            }
        });
        jPanel25.add(jButton282);
        jButton282.setBounds(10, 90, 30, 40);

        jButton283.setEnabled(false);
        jButton283.setBackground(new java.awt.Color(0, 0, 0));
        jButton283.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-chevron-left-40(1).png")); // NOI18N
        jButton283.setContentAreaFilled(false);
        jButton283.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton283.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton283ActionPerformed(evt);
            }
        });
        jPanel25.add(jButton283);
        jButton283.setBounds(1840, 100, 40, 40);

        jPanel12.add(jPanel25);
        jPanel25.setBounds(0, 1500, 1910, 230);

        jPanel28.setBackground(new java.awt.Color(0, 0, 0));
        jPanel28.setOpaque(false);
        jPanel28.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel28MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel28MouseExited(evt);
            }
        });
        jPanel28.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton284.setForeground(new java.awt.Color(255, 0, 0));
        jButton284.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\krishna and his leela.png")); // NOI18N
        jButton284.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton284.setContentAreaFilled(false);
        jButton284.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton284.setOpaque(true);
        jButton284.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton284MouseEntered(evt);
            }
        });
        jButton284.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton284ActionPerformed(evt);
            }
        });
        jPanel28.add(jButton284, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 340, 190));

        jButton285.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\uyare.png")); // NOI18N
        jButton285.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton285.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel28.add(jButton285, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 20, 340, 190));

        jButton286.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\kabir singh.png")); // NOI18N
        jButton286.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton286.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel28.add(jButton286, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 20, 340, 190));

        jButton287.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\saaho.png")); // NOI18N
        jButton287.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton287.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel28.add(jButton287, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 20, 340, 190));

        jButton288.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\gameover.png")); // NOI18N
        jButton288.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton288.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel28.add(jButton288, new org.netbeans.lib.awtextra.AbsoluteConstraints(1460, 20, 340, 190));

        jPanel12.add(jPanel28);
        jPanel28.setBounds(0, 1500, 1910, 230);

        jPanel29.setBackground(new java.awt.Color(0, 0, 0));
        jPanel29.setAutoscrolls(true);
        jPanel29.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel29MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel29MouseExited(evt);
            }
        });
        jPanel29.setLayout(null);

        jButton289.setForeground(new java.awt.Color(255, 0, 0));
        jButton289.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\annihilation.png")); // NOI18N
        jButton289.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton289.setContentAreaFilled(false);
        jButton289.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton289.setOpaque(true);
        jButton289.setRolloverEnabled(false);
        jButton289.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton289MouseEntered(evt);
            }
        });
        jButton289.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton289ActionPerformed(evt);
            }
        });
        jPanel29.add(jButton289);
        jButton289.setBounds(60, 20, 340, 190);

        jButton290.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\desperados.png")); // NOI18N
        jButton290.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton290.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton290.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton290ActionPerformed(evt);
            }
        });
        jPanel29.add(jButton290);
        jButton290.setBounds(410, 20, 340, 190);

        jButton291.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\i lost my body.png")); // NOI18N
        jButton291.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton291.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel29.add(jButton291);
        jButton291.setBounds(760, 20, 340, 190);

        jButton292.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\tramps.png")); // NOI18N
        jButton292.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton292.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel29.add(jButton292);
        jButton292.setBounds(1110, 20, 340, 190);

        jButton293.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\roma.png")); // NOI18N
        jButton293.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton293.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel29.add(jButton293);
        jButton293.setBounds(1460, 20, 340, 190);

        jButton294.setBackground(new java.awt.Color(0, 0, 0));
        jButton294.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-chevron-left-40.png")); // NOI18N
        jButton294.setContentAreaFilled(false);
        jButton294.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton294.setOpaque(true);
        jButton294.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton294ActionPerformed(evt);
            }
        });
        jPanel29.add(jButton294);
        jButton294.setBounds(10, 90, 30, 40);

        jButton295.setEnabled(false);
        jButton295.setBackground(new java.awt.Color(0, 0, 0));
        jButton295.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Downloads\\icons8-chevron-left-40(1).png")); // NOI18N
        jButton295.setContentAreaFilled(false);
        jButton295.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton295.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton295ActionPerformed(evt);
            }
        });
        jPanel29.add(jButton295);
        jButton295.setBounds(1820, 100, 40, 40);

        jPanel12.add(jPanel29);
        jPanel29.setBounds(0, 1790, 1910, 230);

        jPanel32.setBackground(new java.awt.Color(0, 0, 0));
        jPanel32.setOpaque(false);
        jPanel32.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel32MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel32MouseExited(evt);
            }
        });
        jPanel32.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton301.setForeground(new java.awt.Color(255, 0, 0));
        jButton301.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\on body and soul.png")); // NOI18N
        jButton301.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton301.setContentAreaFilled(false);
        jButton301.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton301.setOpaque(true);
        jButton301.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton301MouseEntered(evt);
            }
        });
        jButton301.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton301ActionPerformed(evt);
            }
        });
        jPanel32.add(jButton301, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 340, 190));

        jButton302.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\marriage story.png")); // NOI18N
        jButton302.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton302.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel32.add(jButton302, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 20, 340, 190));

        jButton303.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\upgrade.png")); // NOI18N
        jButton303.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton303.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel32.add(jButton303, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 20, 340, 190));

        jButton304.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\private life.png")); // NOI18N
        jButton304.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton304.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel32.add(jButton304, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 20, 340, 190));

        jButton305.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\okja.png")); // NOI18N
        jButton305.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton305.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel32.add(jButton305, new org.netbeans.lib.awtextra.AbsoluteConstraints(1460, 20, 340, 190));

        jPanel12.add(jPanel32);
        jPanel32.setBounds(0, 1790, 1910, 230);

        jLabel48.setFont(new java.awt.Font("Gadugi", 0, 24)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(255, 255, 255));
        jLabel48.setText("BEST OF ALL TIMES");
        jPanel12.add(jLabel48);
        jLabel48.setBounds(10, 1750, 220, 29);

        jLabel46.setFont(new java.awt.Font("Gadugi", 0, 24)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 255, 255));
        jLabel46.setText("BEST OF 2020");
        jPanel12.add(jLabel46);
        jLabel46.setBounds(10, 1450, 160, 29);

        jLabel45.setFont(new java.awt.Font("Gadugi", 0, 24)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(255, 255, 255));
        jLabel45.setText("OSCARS");
        jPanel12.add(jLabel45);
        jLabel45.setBounds(10, 1160, 100, 29);

        jLabel44.setFont(new java.awt.Font("Gadugi", 0, 24)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(255, 255, 255));
        jLabel44.setText("SHOWS @Made in India");
        jPanel12.add(jLabel44);
        jLabel44.setBounds(10, 870, 270, 29);

        jLabel43.setFont(new java.awt.Font("Gadugi", 0, 24)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("TRENDING NOW");
        jPanel12.add(jLabel43);
        jLabel43.setBounds(10, 70, 190, 29);

        jLabel41.setFont(new java.awt.Font("Gadugi", 0, 24)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("AWARD WINNING");
        jPanel12.add(jLabel41);
        jLabel41.setBounds(10, 600, 210, 29);

        jLabel42.setFont(new java.awt.Font("Gadugi", 0, 24)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("DETECTIVE");
        jPanel12.add(jLabel42);
        jLabel42.setBounds(10, 340, 140, 29);

        jLabel47.setFont(new java.awt.Font("Gadugi", 0, 24)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(255, 255, 255));
        jLabel47.setText("BEST OF 2020");
        jPanel12.add(jLabel47);
        jLabel47.setBounds(10, 1450, 160, 29);

        jPanel40.add(jPanel12);
        jPanel12.setBounds(0, 0, 1930, 3120);

        jPanel58.setVisible(false);
        jPanel58.setBackground(new java.awt.Color(0, 0, 0));
        jPanel58.setLayout(null);

        jLabel25.setBackground(new java.awt.Color(0, 102, 204));
        jLabel25.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-drama-30.png")); // NOI18N
        jLabel25.setText(" DRAMA");
        jLabel25.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 1, true));
        jPanel58.add(jLabel25);
        jLabel25.setBounds(0, 810, 150, 40);

        jPanel57.setVisible(false);
        jPanel57.setBackground(new java.awt.Color(0, 0, 0));
        jPanel57.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 1, true));
        jPanel57.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton108.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals_2\\icons8-down-arrow-35.png")); // NOI18N
        jButton108.setContentAreaFilled(false);
        jButton108.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton108.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton108ActionPerformed(evt);
            }
        });
        jPanel57.add(jButton108, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 150, 30, 30));

        jButton127.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-plus-30.png")); // NOI18N
        jButton127.setContentAreaFilled(false);
        jButton127.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton127.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton127ActionPerformed(evt);
            }
        });
        jPanel57.add(jButton127, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 100, 30, 30));

        jButton128.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-star-35.png")); // NOI18N
        jButton128.setContentAreaFilled(false);
        jButton128.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton128.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton128ActionPerformed(evt);
            }
        });
        jPanel57.add(jButton128, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 40, 30, 40));

        jPanel58.add(jPanel57);
        jPanel57.setBounds(360, 2770, 40, 190);

        jPanel59.setVisible(false);
        jPanel59.setBackground(new java.awt.Color(0, 0, 0));
        jPanel59.setLayout(null);

        jButton109.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton109.setForeground(new java.awt.Color(255, 255, 255));
        jButton109.setText("SEASON 1");
        jButton109.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton109.setContentAreaFilled(false);
        jButton109.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton109.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton109ActionPerformed(evt);
            }
        });
        jPanel59.add(jButton109);
        jButton109.setBounds(10, 10, 100, 30);

        jButton110.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton110.setForeground(new java.awt.Color(255, 255, 255));
        jButton110.setText("SEASON 2");
        jButton110.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton110.setContentAreaFilled(false);
        jButton110.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton110.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton110ActionPerformed(evt);
            }
        });
        jPanel59.add(jButton110);
        jButton110.setBounds(140, 10, 100, 30);

        jButton111.setBackground(new java.awt.Color(0, 0, 0));
        jButton111.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton111.setForeground(new java.awt.Color(255, 255, 255));
        jButton111.setText("SEASON 3");
        jButton111.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton111.setContentAreaFilled(false);
        jButton111.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton111.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton111ActionPerformed(evt);
            }
        });
        jPanel59.add(jButton111);
        jButton111.setBounds(260, 10, 100, 30);

        jButton112.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton112.setForeground(new java.awt.Color(255, 255, 255));
        jButton112.setText("SEASON 4");
        jButton112.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton112.setContentAreaFilled(false);
        jButton112.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton112.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton112ActionPerformed(evt);
            }
        });
        jPanel59.add(jButton112);
        jButton112.setBounds(10, 50, 100, 30);

        jButton113.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton113.setForeground(new java.awt.Color(255, 255, 255));
        jButton113.setText("SEASON 5");
        jButton113.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton113.setContentAreaFilled(false);
        jButton113.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton113.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton113ActionPerformed(evt);
            }
        });
        jPanel59.add(jButton113);
        jButton113.setBounds(140, 50, 100, 30);

        jButton114.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton114.setForeground(new java.awt.Color(255, 255, 255));
        jButton114.setText("SEASON 6");
        jButton114.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton114.setContentAreaFilled(false);
        jButton114.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton114.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton114ActionPerformed(evt);
            }
        });
        jPanel59.add(jButton114);
        jButton114.setBounds(260, 50, 100, 30);

        jButton115.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton115.setForeground(new java.awt.Color(255, 255, 255));
        jButton115.setText("SEASON 7");
        jButton115.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton115.setContentAreaFilled(false);
        jButton115.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton115.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton115ActionPerformed(evt);
            }
        });
        jPanel59.add(jButton115);
        jButton115.setBounds(10, 90, 100, 30);

        jButton116.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton116.setForeground(new java.awt.Color(255, 255, 255));
        jButton116.setText("SEASON 8");
        jButton116.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton116.setContentAreaFilled(false);
        jButton116.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton116.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton116ActionPerformed(evt);
            }
        });
        jPanel59.add(jButton116);
        jButton116.setBounds(140, 90, 100, 30);

        jButton117.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton117.setForeground(new java.awt.Color(255, 255, 255));
        jButton117.setText("SEASON 9");
        jButton117.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton117.setContentAreaFilled(false);
        jButton117.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton117.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton117ActionPerformed(evt);
            }
        });
        jPanel59.add(jButton117);
        jButton117.setBounds(260, 90, 100, 30);

        jPanel58.add(jPanel59);
        jPanel59.setBounds(450, 2770, 370, 130);

        jPanel74.setVisible(false);
        jPanel74.setBackground(new java.awt.Color(0, 0, 0));
        jPanel74.setLayout(null);

        jButton163.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton163.setForeground(new java.awt.Color(255, 255, 255));
        jButton163.setText("EPISODE 10");
        jButton163.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton163.setContentAreaFilled(false);
        jButton163.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton163.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton163ActionPerformed(evt);
            }
        });
        jPanel74.add(jButton163);
        jButton163.setBounds(10, 10, 100, 25);

        jButton164.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton164.setForeground(new java.awt.Color(255, 255, 255));
        jButton164.setText("EPISODE 11");
        jButton164.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton164.setContentAreaFilled(false);
        jButton164.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton164.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton164ActionPerformed(evt);
            }
        });
        jPanel74.add(jButton164);
        jButton164.setBounds(140, 10, 100, 25);

        jButton165.setBackground(new java.awt.Color(0, 0, 0));
        jButton165.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton165.setForeground(new java.awt.Color(255, 255, 255));
        jButton165.setText("EPISODE 12");
        jButton165.setToolTipText("");
        jButton165.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton165.setContentAreaFilled(false);
        jButton165.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton165.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton165ActionPerformed(evt);
            }
        });
        jPanel74.add(jButton165);
        jButton165.setBounds(260, 10, 100, 25);

        jButton166.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton166.setForeground(new java.awt.Color(255, 255, 255));
        jButton166.setText("EPISODE 13");
        jButton166.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton166.setContentAreaFilled(false);
        jButton166.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton166.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton166ActionPerformed(evt);
            }
        });
        jPanel74.add(jButton166);
        jButton166.setBounds(10, 43, 100, 25);

        jButton167.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton167.setForeground(new java.awt.Color(255, 255, 255));
        jButton167.setText("EPISODE 14");
        jButton167.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton167.setContentAreaFilled(false);
        jButton167.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton167.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton167ActionPerformed(evt);
            }
        });
        jPanel74.add(jButton167);
        jButton167.setBounds(140, 43, 100, 25);

        jButton168.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton168.setForeground(new java.awt.Color(255, 255, 255));
        jButton168.setText("EPISODE 15");
        jButton168.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton168.setContentAreaFilled(false);
        jButton168.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton168.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton168ActionPerformed(evt);
            }
        });
        jPanel74.add(jButton168);
        jButton168.setBounds(260, 43, 100, 25);

        jButton169.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton169.setForeground(new java.awt.Color(255, 255, 255));
        jButton169.setText("EPISODE 16");
        jButton169.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton169.setContentAreaFilled(false);
        jButton169.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton169.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton169ActionPerformed(evt);
            }
        });
        jPanel74.add(jButton169);
        jButton169.setBounds(10, 77, 100, 25);

        jButton170.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton170.setForeground(new java.awt.Color(255, 255, 255));
        jButton170.setText("EPISODE 17");
        jButton170.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton170.setContentAreaFilled(false);
        jButton170.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton170.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton170ActionPerformed(evt);
            }
        });
        jPanel74.add(jButton170);
        jButton170.setBounds(140, 77, 100, 25);

        jButton171.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton171.setForeground(new java.awt.Color(255, 255, 255));
        jButton171.setText("EPISODE 18");
        jButton171.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton171.setContentAreaFilled(false);
        jButton171.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton171.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton171ActionPerformed(evt);
            }
        });
        jPanel74.add(jButton171);
        jButton171.setBounds(260, 77, 100, 25);

        ep_btn4.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16.png")); // NOI18N
        ep_btn4.setContentAreaFilled(false);
        ep_btn4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ep_btn4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ep_btn4MouseClicked(evt);
            }
        });
        ep_btn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ep_btn4ActionPerformed(evt);
            }
        });
        jPanel74.add(ep_btn4);
        ep_btn4.setBounds(200, 107, 20, 20);

        ep_btn3.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16 (1).png")); // NOI18N
        ep_btn3.setContentAreaFilled(false);
        ep_btn3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ep_btn3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ep_btn3MouseClicked(evt);
            }
        });
        ep_btn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ep_btn3ActionPerformed(evt);
            }
        });
        jPanel74.add(ep_btn3);
        ep_btn3.setBounds(170, 107, 20, 20);

        jPanel58.add(jPanel74);
        jPanel74.setBounds(870, 2620, 370, 130);

        jPanel60.setVisible(false);
        jPanel60.setBackground(new java.awt.Color(0, 0, 0));
        jPanel60.setLayout(null);

        jButton118.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton118.setForeground(new java.awt.Color(255, 255, 255));
        jButton118.setText("EPISODE 1");
        jButton118.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton118.setContentAreaFilled(false);
        jButton118.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton118.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton118ActionPerformed(evt);
            }
        });
        jPanel60.add(jButton118);
        jButton118.setBounds(10, 10, 100, 25);

        jButton119.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton119.setForeground(new java.awt.Color(255, 255, 255));
        jButton119.setText("EPISODE 2");
        jButton119.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton119.setContentAreaFilled(false);
        jButton119.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton119.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton119ActionPerformed(evt);
            }
        });
        jPanel60.add(jButton119);
        jButton119.setBounds(140, 10, 100, 25);

        jButton120.setBackground(new java.awt.Color(0, 0, 0));
        jButton120.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton120.setForeground(new java.awt.Color(255, 255, 255));
        jButton120.setText("EPISODE 3");
        jButton120.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton120.setContentAreaFilled(false);
        jButton120.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton120.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton120ActionPerformed(evt);
            }
        });
        jPanel60.add(jButton120);
        jButton120.setBounds(260, 10, 100, 25);

        jButton121.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton121.setForeground(new java.awt.Color(255, 255, 255));
        jButton121.setText("EPISODE 4");
        jButton121.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton121.setContentAreaFilled(false);
        jButton121.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton121.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton121ActionPerformed(evt);
            }
        });
        jPanel60.add(jButton121);
        jButton121.setBounds(10, 43, 100, 25);

        jButton122.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton122.setForeground(new java.awt.Color(255, 255, 255));
        jButton122.setText("EPISODE 5");
        jButton122.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton122.setContentAreaFilled(false);
        jButton122.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton122.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton122ActionPerformed(evt);
            }
        });
        jPanel60.add(jButton122);
        jButton122.setBounds(140, 43, 100, 25);

        jButton123.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton123.setForeground(new java.awt.Color(255, 255, 255));
        jButton123.setText("EPISODE 6");
        jButton123.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton123.setContentAreaFilled(false);
        jButton123.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton123.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton123ActionPerformed(evt);
            }
        });
        jPanel60.add(jButton123);
        jButton123.setBounds(260, 43, 100, 25);

        jButton124.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton124.setForeground(new java.awt.Color(255, 255, 255));
        jButton124.setText("EPISODE 7");
        jButton124.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton124.setContentAreaFilled(false);
        jButton124.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton124.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton124ActionPerformed(evt);
            }
        });
        jPanel60.add(jButton124);
        jButton124.setBounds(10, 77, 100, 25);

        jButton125.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton125.setForeground(new java.awt.Color(255, 255, 255));
        jButton125.setText("EPISODE 8");
        jButton125.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton125.setContentAreaFilled(false);
        jButton125.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton125.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton125ActionPerformed(evt);
            }
        });
        jPanel60.add(jButton125);
        jButton125.setBounds(140, 77, 100, 25);

        jButton126.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton126.setForeground(new java.awt.Color(255, 255, 255));
        jButton126.setText("EPISODE 9");
        jButton126.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton126.setContentAreaFilled(false);
        jButton126.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton126.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton126ActionPerformed(evt);
            }
        });
        jPanel60.add(jButton126);
        jButton126.setBounds(260, 77, 100, 25);

        ep_btn2.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16 (1).png")); // NOI18N
        ep_btn2.setContentAreaFilled(false);
        ep_btn2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ep_btn2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ep_btn2MouseClicked(evt);
            }
        });
        ep_btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ep_btn2ActionPerformed(evt);
            }
        });
        jPanel60.add(ep_btn2);
        ep_btn2.setBounds(200, 107, 20, 20);

        ep_btn1.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16.png")); // NOI18N
        ep_btn1.setContentAreaFilled(false);
        ep_btn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ep_btn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ep_btn1MouseClicked(evt);
            }
        });
        ep_btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ep_btn1ActionPerformed(evt);
            }
        });
        jPanel60.add(ep_btn1);
        ep_btn1.setBounds(170, 107, 20, 20);

        jPanel58.add(jPanel60);
        jPanel60.setBounds(870, 2770, 370, 130);

        jLabel21.setBackground(new java.awt.Color(255, 51, 51));
        jLabel21.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-film-noir-30.png")); // NOI18N
        jLabel21.setText("THRILLER");
        jLabel21.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 1, true));
        jPanel58.add(jLabel21);
        jLabel21.setBounds(0, 2070, 160, 40);

        thriller_show.setLayout(null);

        jPanel62.setBackground(new java.awt.Color(0, 0, 0));
        jPanel62.setLayout(null);

        jButton132.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\sacred games.png")); // NOI18N
        jButton132.setText("sacred games");
        jButton132.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton132.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton132.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton132ActionPerformed(evt);
            }
        });
        jPanel62.add(jButton132);
        jButton132.setBounds(1520, 0, 330, 190);

        jButton131.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\13 reasons why.png")); // NOI18N
        jButton131.setText("13 reasons why");
        jButton131.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton131.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton131.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton131ActionPerformed(evt);
            }
        });
        jPanel62.add(jButton131);
        jButton131.setBounds(1140, 0, 330, 190);

        jButton130.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\bard of blood.png")); // NOI18N
        jButton130.setText("bard of blood");
        jButton130.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton130.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton130.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton130ActionPerformed(evt);
            }
        });
        jPanel62.add(jButton130);
        jButton130.setBounds(760, 0, 330, 190);

        jButton129.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the 100.png")); // NOI18N
        jButton129.setText("the 100");
        jButton129.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton129.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton129.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton129ActionPerformed(evt);
            }
        });
        jPanel62.add(jButton129);
        jButton129.setBounds(380, 0, 330, 190);

        jButton107.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        jButton107.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\money heist.png")); // NOI18N
        jButton107.setText("money heist");
        jButton107.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton107.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton107.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton107ActionPerformed(evt);
            }
        });
        jPanel62.add(jButton107);
        jButton107.setBounds(0, 0, 330, 190);

        thriller_show.add(jPanel62);
        jPanel62.setBounds(0, 0, 1910, 230);

        jPanel63.setLayout(null);
        thriller_show.add(jPanel63);
        jPanel63.setBounds(0, 0, 1910, 230);

        jPanel58.add(thriller_show);
        thriller_show.setBounds(0, 2140, 1910, 230);

        drama_show.setLayout(null);

        jPanel64.setBackground(new java.awt.Color(0, 0, 0));
        jPanel64.setLayout(null);

        jButton133.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\mirzapur.png")); // NOI18N
        jButton133.setText("mirzapur");
        jButton133.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton133.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton133.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton133ActionPerformed(evt);
            }
        });
        jPanel64.add(jButton133);
        jButton133.setBounds(0, 0, 330, 190);

        jButton134.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\black spot.png")); // NOI18N
        jButton134.setText("black spot");
        jButton134.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton134.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton134.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton134ActionPerformed(evt);
            }
        });
        jPanel64.add(jButton134);
        jButton134.setBounds(380, 0, 330, 190);

        jButton135.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the family man.png")); // NOI18N
        jButton135.setText("the family man");
        jButton135.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton135.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton135.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton135ActionPerformed(evt);
            }
        });
        jPanel64.add(jButton135);
        jButton135.setBounds(760, 0, 330, 190);

        jButton136.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the test.png")); // NOI18N
        jButton136.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton136.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton136.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton136ActionPerformed(evt);
            }
        });
        jPanel64.add(jButton136);
        jButton136.setBounds(1140, 0, 330, 190);

        jButton137.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\kingdom.png")); // NOI18N
        jButton137.setText("kingdom");
        jButton137.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton137.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton137.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton137ActionPerformed(evt);
            }
        });
        jPanel64.add(jButton137);
        jButton137.setBounds(1520, 0, 330, 190);

        drama_show.add(jPanel64);
        jPanel64.setBounds(0, 0, 1910, 230);

        jPanel65.setLayout(null);
        drama_show.add(jPanel65);
        jPanel65.setBounds(0, 0, 1910, 230);

        jPanel58.add(drama_show);
        drama_show.setBounds(0, 865, 1910, 230);

        crime_show.setLayout(null);

        jPanel67.setBackground(new java.awt.Color(0, 0, 0));
        jPanel67.setLayout(null);

        jButton143.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\shooter.png")); // NOI18N
        jButton143.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton143.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton143.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton143ActionPerformed(evt);
            }
        });
        jPanel67.add(jButton143);
        jButton143.setBounds(0, 0, 330, 190);

        jButton144.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\breaking bad.png")); // NOI18N
        jButton144.setText("breaking bad");
        jButton144.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton144.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton144.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton144ActionPerformed(evt);
            }
        });
        jPanel67.add(jButton144);
        jButton144.setBounds(380, 0, 330, 190);

        jButton145.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\jamtara.png")); // NOI18N
        jButton145.setText("jamtara");
        jButton145.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton145.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton145.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton145ActionPerformed(evt);
            }
        });
        jPanel67.add(jButton145);
        jButton145.setBounds(760, 0, 330, 190);

        jButton146.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\ozark.png")); // NOI18N
        jButton146.setText("ozark");
        jButton146.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton146.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton146.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton146ActionPerformed(evt);
            }
        });
        jPanel67.add(jButton146);
        jButton146.setBounds(1140, 0, 330, 190);

        jButton147.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\delhi crime.png")); // NOI18N
        jButton147.setText("delhi crime");
        jButton147.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton147.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton147.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton147ActionPerformed(evt);
            }
        });
        jPanel67.add(jButton147);
        jButton147.setBounds(1520, 0, 330, 190);

        crime_show.add(jPanel67);
        jPanel67.setBounds(0, 0, 1910, 230);

        jPanel68.setLayout(null);
        crime_show.add(jPanel68);
        jPanel68.setBounds(0, 0, 1910, 230);

        jPanel58.add(crime_show);
        crime_show.setBounds(0, 1505, 1910, 230);

        top10_show.setLayout(null);

        jPanel71.setBackground(new java.awt.Color(0, 0, 0));
        jPanel71.setLayout(null);

        jButton153.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton153.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton153.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton153ActionPerformed(evt);
            }
        });
        jPanel71.add(jButton153);
        jButton153.setBounds(0, 0, 330, 190);

        jButton154.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton154.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton154.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton154ActionPerformed(evt);
            }
        });
        jPanel71.add(jButton154);
        jButton154.setBounds(380, 0, 330, 190);

        jButton155.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton155.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton155.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton155ActionPerformed(evt);
            }
        });
        jPanel71.add(jButton155);
        jButton155.setBounds(760, 0, 330, 190);

        jButton156.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton156.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton156.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton156ActionPerformed(evt);
            }
        });
        jPanel71.add(jButton156);
        jButton156.setBounds(1140, 0, 330, 190);

        jButton157.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton157.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton157.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton157ActionPerformed(evt);
            }
        });
        jPanel71.add(jButton157);
        jButton157.setBounds(1520, 0, 330, 190);

        top10_show.add(jPanel71);
        jPanel71.setBounds(0, 0, 1910, 230);

        jPanel72.setBackground(new java.awt.Color(0, 0, 0));
        jPanel72.setLayout(null);

        jButton158.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton158.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton158.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton158ActionPerformed(evt);
            }
        });
        jPanel72.add(jButton158);
        jButton158.setBounds(0, 0, 330, 190);

        jButton159.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton159.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton159.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton159ActionPerformed(evt);
            }
        });
        jPanel72.add(jButton159);
        jButton159.setBounds(380, 0, 330, 190);

        jButton160.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton160.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton160.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton160ActionPerformed(evt);
            }
        });
        jPanel72.add(jButton160);
        jButton160.setBounds(760, 0, 330, 190);

        jButton161.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton161.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton161.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton161ActionPerformed(evt);
            }
        });
        jPanel72.add(jButton161);
        jButton161.setBounds(1140, 0, 330, 190);

        jButton162.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton162.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton162.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton162ActionPerformed(evt);
            }
        });
        jPanel72.add(jButton162);
        jButton162.setBounds(1520, 0, 330, 190);

        top10_show.add(jPanel72);
        jPanel72.setBounds(0, 0, 1910, 230);

        jPanel58.add(top10_show);
        top10_show.setBounds(0, 470, 1910, 230);

        comedy_show.setLayout(null);

        jPanel69.setBackground(new java.awt.Color(0, 0, 0));
        jPanel69.setLayout(null);

        jButton148.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        jButton148.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\panchayat.png")); // NOI18N
        jButton148.setText("panchayat");
        jButton148.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton148.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton148.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton148ActionPerformed(evt);
            }
        });
        jPanel69.add(jButton148);
        jButton148.setBounds(0, 0, 330, 190);

        jButton149.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\friends.png")); // NOI18N
        jButton149.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton149.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton149.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton149ActionPerformed(evt);
            }
        });
        jPanel69.add(jButton149);
        jButton149.setBounds(380, 0, 330, 190);

        jButton150.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\young sheldon.png")); // NOI18N
        jButton150.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton150.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton150.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton150ActionPerformed(evt);
            }
        });
        jPanel69.add(jButton150);
        jButton150.setBounds(760, 0, 330, 190);

        jButton151.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        jButton151.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the boys.png")); // NOI18N
        jButton151.setText("the boys");
        jButton151.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton151.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton151.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton151ActionPerformed(evt);
            }
        });
        jPanel69.add(jButton151);
        jButton151.setBounds(1140, 0, 330, 190);

        jButton152.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\the office.png")); // NOI18N
        jButton152.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton152.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton152.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton152ActionPerformed(evt);
            }
        });
        jPanel69.add(jButton152);
        jButton152.setBounds(1520, 0, 330, 190);

        comedy_show.add(jPanel69);
        jPanel69.setBounds(0, 0, 1910, 230);

        jPanel70.setLayout(null);
        comedy_show.add(jPanel70);
        jPanel70.setBounds(0, 0, 1910, 230);

        jPanel58.add(comedy_show);
        comedy_show.setBounds(0, 1825, 1910, 230);

        scifi_show.setLayout(null);

        jPanel66.setBackground(new java.awt.Color(0, 0, 0));
        jPanel66.setLayout(null);

        jButton138.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\dark.png")); // NOI18N
        jButton138.setText("dark");
        jButton138.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton138.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton138.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton138ActionPerformed(evt);
            }
        });
        jPanel66.add(jButton138);
        jButton138.setBounds(0, 0, 330, 190);

        jButton139.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\travelers.png")); // NOI18N
        jButton139.setText("travelers");
        jButton139.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton139.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton139.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton139ActionPerformed(evt);
            }
        });
        jPanel66.add(jButton139);
        jButton139.setBounds(380, 0, 330, 190);

        jButton140.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\zoo.png")); // NOI18N
        jButton140.setText("zoo");
        jButton140.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton140.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton140.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton140ActionPerformed(evt);
            }
        });
        jPanel66.add(jButton140);
        jButton140.setBounds(760, 0, 330, 190);

        jButton141.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\stranger things.png")); // NOI18N
        jButton141.setText("stranger things");
        jButton141.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton141.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton141.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton141ActionPerformed(evt);
            }
        });
        jPanel66.add(jButton141);
        jButton141.setBounds(1140, 0, 330, 190);

        jButton142.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        jButton142.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals\\jinn.png")); // NOI18N
        jButton142.setText("jinn");
        jButton142.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton142.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton142.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton142ActionPerformed(evt);
            }
        });
        jPanel66.add(jButton142);
        jButton142.setBounds(1520, 0, 330, 190);

        scifi_show.add(jPanel66);
        jPanel66.setBounds(0, 0, 1910, 230);

        jPanel61.setLayout(null);
        scifi_show.add(jPanel61);
        jPanel61.setBounds(0, 0, 1910, 230);

        jPanel58.add(scifi_show);
        scifi_show.setBounds(0, 1185, 1910, 230);

        jLabel7.setBackground(new java.awt.Color(0, 153, 153));
        jLabel7.setFont(new java.awt.Font("Arial", 1, 30)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("   TOP 10");
        jLabel7.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 0, 51), 2, true));
        jLabel7.setOpaque(true);
        jPanel58.add(jLabel7);
        jLabel7.setBounds(0, 420, 150, 40);

        jLabel27.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-sci-fi-30.png")); // NOI18N
        jLabel27.setText("  SCIFI");
        jLabel27.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 1, true));
        jPanel58.add(jLabel27);
        jLabel27.setBounds(0, 1110, 150, 40);

        jLabel28.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-horror-30.png")); // NOI18N
        jLabel28.setText("  CRIME");
        jLabel28.setToolTipText("");
        jLabel28.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 1, true));
        jPanel58.add(jLabel28);
        jLabel28.setBounds(0, 1430, 150, 40);

        jLabel29.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-comedy-30.png")); // NOI18N
        jLabel29.setText(" COMEDY");
        jLabel29.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jPanel58.add(jLabel29);
        jLabel29.setBounds(0, 1750, 150, 40);

        jPanel78.setVisible(false);
        jPanel78.setBackground(new java.awt.Color(0, 0, 0));
        jPanel78.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel78MouseExited(evt);
            }
        });
        jPanel78.setLayout(null);

        recomshow_btn1.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16.png")); // NOI18N
        recomshow_btn1.setContentAreaFilled(false);
        recomshow_btn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        recomshow_btn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                recomshow_btn1MouseClicked(evt);
            }
        });
        recomshow_btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                recomshow_btn1ActionPerformed(evt);
            }
        });
        jPanel78.add(recomshow_btn1);
        recomshow_btn1.setBounds(970, 0, 20, 20);

        recomshow_btn2.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16 (1).png")); // NOI18N
        recomshow_btn2.setContentAreaFilled(false);
        recomshow_btn2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        recomshow_btn2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                recomshow_btn2MouseClicked(evt);
            }
        });
        recomshow_btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                recomshow_btn2ActionPerformed(evt);
            }
        });
        jPanel78.add(recomshow_btn2);
        recomshow_btn2.setBounds(1000, 0, 20, 20);

        jPanel58.add(jPanel78);
        jPanel78.setBounds(0, 340, 2090, 20);

        jPanel73.setBackground(new java.awt.Color(0, 0, 0));
        jPanel73.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel73MouseExited(evt);
            }
        });
        jPanel73.setLayout(null);

        top10_btn1.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16.png")); // NOI18N
        top10_btn1.setContentAreaFilled(false);
        top10_btn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        top10_btn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                top10_btn1MouseClicked(evt);
            }
        });
        top10_btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                top10_btn1ActionPerformed(evt);
            }
        });
        jPanel73.add(top10_btn1);
        top10_btn1.setBounds(970, 0, 20, 20);

        top10_btn2.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16 (1).png")); // NOI18N
        top10_btn2.setContentAreaFilled(false);
        top10_btn2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        top10_btn2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                top10_btn2MouseClicked(evt);
            }
        });
        top10_btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                top10_btn2ActionPerformed(evt);
            }
        });
        jPanel73.add(top10_btn2);
        top10_btn2.setBounds(1000, 0, 20, 20);

        jPanel58.add(jPanel73);
        jPanel73.setBounds(10, 700, 2100, 20);

        jButton172.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton172.setForeground(new java.awt.Color(255, 255, 255));
        jButton172.setText("COMEDY");
        jButton172.setActionCommand("");
        jButton172.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 1, true));
        jButton172.setContentAreaFilled(false);
        jButton172.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton172.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton172MouseClicked(evt);
            }
        });
        jPanel58.add(jButton172);
        jButton172.setBounds(580, 750, 110, 27);

        jButton173.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton173.setForeground(new java.awt.Color(255, 255, 255));
        jButton173.setText("ACTION");
        jButton173.setActionCommand("");
        jButton173.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 1, true));
        jButton173.setContentAreaFilled(false);
        jButton173.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton173.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton173ActionPerformed(evt);
            }
        });
        jPanel58.add(jButton173);
        jButton173.setBounds(710, 750, 100, 27);

        jButton174.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton174.setForeground(new java.awt.Color(255, 255, 255));
        jButton174.setText("THRILLER");
        jButton174.setActionCommand("");
        jButton174.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 1, true));
        jButton174.setContentAreaFilled(false);
        jButton174.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton174.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton174ActionPerformed(evt);
            }
        });
        jPanel58.add(jButton174);
        jButton174.setBounds(830, 750, 120, 27);

        jButton175.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton175.setForeground(new java.awt.Color(255, 255, 255));
        jButton175.setText("SCI FI");
        jButton175.setActionCommand("");
        jButton175.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 1, true));
        jButton175.setContentAreaFilled(false);
        jButton175.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton175.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton175ActionPerformed(evt);
            }
        });
        jPanel58.add(jButton175);
        jButton175.setBounds(970, 750, 100, 27);

        jButton176.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton176.setForeground(new java.awt.Color(255, 255, 255));
        jButton176.setText("DRAMA");
        jButton176.setActionCommand("");
        jButton176.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 1, true));
        jButton176.setContentAreaFilled(false);
        jButton176.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton176.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton176ActionPerformed(evt);
            }
        });
        jPanel58.add(jButton176);
        jButton176.setBounds(1090, 750, 100, 27);

        jButton177.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton177.setForeground(new java.awt.Color(255, 255, 255));
        jButton177.setText("CRIME");
        jButton177.setActionCommand("");
        jButton177.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 1, true));
        jButton177.setContentAreaFilled(false);
        jButton177.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton177.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton177ActionPerformed(evt);
            }
        });
        jPanel58.add(jButton177);
        jButton177.setBounds(1210, 750, 100, 27);

        recom_show.setLayout(null);

        jPanel77.setVisible(false);
        jPanel77.setBackground(new java.awt.Color(0, 0, 0));
        jPanel77.setLayout(null);

        jButton183.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton183.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel77.add(jButton183);
        jButton183.setBounds(0, 0, 330, 190);

        jButton184.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton184.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel77.add(jButton184);
        jButton184.setBounds(380, 0, 330, 190);

        jButton185.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton185.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel77.add(jButton185);
        jButton185.setBounds(760, 0, 330, 190);

        jButton186.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton186.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel77.add(jButton186);
        jButton186.setBounds(1140, 0, 330, 190);

        jButton187.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton187.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel77.add(jButton187);
        jButton187.setBounds(1520, 0, 330, 190);

        recom_show.add(jPanel77);
        jPanel77.setBounds(0, 0, 1910, 230);

        jPanel76.setBackground(new java.awt.Color(0, 0, 0));
        jPanel76.setLayout(null);

        jButton178.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton178.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel76.add(jButton178);
        jButton178.setBounds(0, 0, 330, 190);

        jButton179.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton179.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel76.add(jButton179);
        jButton179.setBounds(380, 0, 330, 190);

        jButton180.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton180.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel76.add(jButton180);
        jButton180.setBounds(760, 0, 330, 190);

        jButton181.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton181.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel76.add(jButton181);
        jButton181.setBounds(1140, 0, 330, 190);

        jButton182.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton182.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel76.add(jButton182);
        jButton182.setBounds(1520, 0, 330, 190);

        recom_show.add(jPanel76);
        jPanel76.setBounds(0, 0, 1910, 230);

        jPanel58.add(recom_show);
        recom_show.setBounds(0, 110, 1910, 230);

        jLabel14.setBackground(new java.awt.Color(153, 153, 153));
        jLabel14.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("OUR RECOMMENDATIONS FOR YOU");
        jLabel14.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 2, true));
        jLabel14.setOpaque(true);
        jPanel58.add(jLabel14);
        jLabel14.setBounds(0, 50, 440, 40);

        jPanel40.add(jPanel58);
        jPanel58.setBounds(0, 0, 1930, 3100);

        jPanel56.setVisible(false);
        jPanel56.setBackground(new java.awt.Color(0, 0, 0));
        jPanel56.setLayout(null);

        jButton68.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton68.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton68.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton68ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton68);
        jButton68.setBounds(0, 70, 330, 190);

        jButton69.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton69.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton69.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton69ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton69);
        jButton69.setBounds(390, 70, 330, 190);

        jButton70.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton70.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton70.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton70ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton70);
        jButton70.setBounds(770, 70, 330, 190);

        jButton71.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton71.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton71.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton71ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton71);
        jButton71.setBounds(1150, 70, 330, 190);

        jButton72.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton72.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton72.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton72ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton72);
        jButton72.setBounds(1540, 70, 330, 190);

        jButton78.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton78.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton78.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton78ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton78);
        jButton78.setBounds(0, 330, 330, 190);

        jButton84.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton84.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton84.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton84ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton84);
        jButton84.setBounds(390, 330, 330, 190);

        jButton87.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton87.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton87.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton87ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton87);
        jButton87.setBounds(770, 330, 330, 190);

        jButton88.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton88.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton88.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton88ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton88);
        jButton88.setBounds(1150, 330, 330, 190);

        jButton89.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton89.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton89.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton89ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton89);
        jButton89.setBounds(1540, 330, 330, 190);

        jButton90.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton90.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton90.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton90ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton90);
        jButton90.setBounds(0, 590, 330, 190);

        jButton96.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton96.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton96.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton96ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton96);
        jButton96.setBounds(390, 590, 330, 190);

        jButton98.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton98.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton98.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton98ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton98);
        jButton98.setBounds(770, 590, 330, 190);

        jButton99.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton99.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton99.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton99ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton99);
        jButton99.setBounds(1150, 590, 330, 190);

        jButton100.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton100.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton100.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton100ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton100);
        jButton100.setBounds(1540, 590, 330, 190);

        jButton101.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton101.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton101.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton101ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton101);
        jButton101.setBounds(0, 850, 330, 190);

        jButton102.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton102.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton102.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton102ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton102);
        jButton102.setBounds(390, 850, 330, 190);

        jButton103.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton103.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton103.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton103ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton103);
        jButton103.setBounds(770, 850, 330, 190);

        jButton104.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton104.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton104.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton104ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton104);
        jButton104.setBounds(1150, 850, 330, 190);

        jButton105.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton105.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton105.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton105ActionPerformed(evt);
            }
        });
        jPanel56.add(jButton105);
        jButton105.setBounds(1540, 850, 330, 190);

        jPanel79.setVisible(false);
        jPanel79.setBackground(new java.awt.Color(0, 0, 0));
        jPanel79.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 1, true));
        jPanel79.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton188.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\originals_2\\icons8-down-arrow-35.png")); // NOI18N
        jButton188.setContentAreaFilled(false);
        jButton188.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton188.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton188ActionPerformed(evt);
            }
        });
        jPanel79.add(jButton188, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 144, 30, 30));

        jPanel56.add(jPanel79);
        jPanel79.setBounds(300, 1730, 40, 190);

        jPanel80.setVisible(false);
        jPanel80.setBackground(new java.awt.Color(0, 0, 0));
        jPanel80.setLayout(null);

        jButton191.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton191.setForeground(new java.awt.Color(255, 255, 255));
        jButton191.setText("SEASON 1");
        jButton191.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton191.setContentAreaFilled(false);
        jButton191.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton191.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton191ActionPerformed(evt);
            }
        });
        jPanel80.add(jButton191);
        jButton191.setBounds(10, 10, 100, 30);

        jButton192.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton192.setForeground(new java.awt.Color(255, 255, 255));
        jButton192.setText("SEASON 2");
        jButton192.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton192.setContentAreaFilled(false);
        jButton192.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton192.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton192ActionPerformed(evt);
            }
        });
        jPanel80.add(jButton192);
        jButton192.setBounds(140, 10, 100, 30);

        jButton193.setBackground(new java.awt.Color(0, 0, 0));
        jButton193.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton193.setForeground(new java.awt.Color(255, 255, 255));
        jButton193.setText("SEASON 3");
        jButton193.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton193.setContentAreaFilled(false);
        jButton193.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton193.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton193ActionPerformed(evt);
            }
        });
        jPanel80.add(jButton193);
        jButton193.setBounds(260, 10, 100, 30);

        jButton194.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton194.setForeground(new java.awt.Color(255, 255, 255));
        jButton194.setText("SEASON 4");
        jButton194.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton194.setContentAreaFilled(false);
        jButton194.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton194.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton194ActionPerformed(evt);
            }
        });
        jPanel80.add(jButton194);
        jButton194.setBounds(10, 50, 100, 30);

        jButton195.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton195.setForeground(new java.awt.Color(255, 255, 255));
        jButton195.setText("SEASON 5");
        jButton195.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton195.setContentAreaFilled(false);
        jButton195.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton195.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton195ActionPerformed(evt);
            }
        });
        jPanel80.add(jButton195);
        jButton195.setBounds(140, 50, 100, 30);

        jButton196.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton196.setForeground(new java.awt.Color(255, 255, 255));
        jButton196.setText("SEASON 6");
        jButton196.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton196.setContentAreaFilled(false);
        jButton196.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton196.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton196ActionPerformed(evt);
            }
        });
        jPanel80.add(jButton196);
        jButton196.setBounds(260, 50, 100, 30);

        jButton197.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton197.setForeground(new java.awt.Color(255, 255, 255));
        jButton197.setText("SEASON 7");
        jButton197.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton197.setContentAreaFilled(false);
        jButton197.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton197.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton197ActionPerformed(evt);
            }
        });
        jPanel80.add(jButton197);
        jButton197.setBounds(10, 90, 100, 30);

        jButton198.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton198.setForeground(new java.awt.Color(255, 255, 255));
        jButton198.setText("SEASON 8");
        jButton198.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton198.setContentAreaFilled(false);
        jButton198.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton198.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton198ActionPerformed(evt);
            }
        });
        jPanel80.add(jButton198);
        jButton198.setBounds(140, 90, 100, 30);

        jButton199.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton199.setForeground(new java.awt.Color(255, 255, 255));
        jButton199.setText("SEASON 9");
        jButton199.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton199.setContentAreaFilled(false);
        jButton199.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton199.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton199ActionPerformed(evt);
            }
        });
        jPanel80.add(jButton199);
        jButton199.setBounds(260, 90, 100, 30);

        jPanel56.add(jPanel80);
        jPanel80.setBounds(370, 1770, 370, 130);

        jPanel81.setVisible(false);
        jPanel81.setBackground(new java.awt.Color(0, 0, 0));
        jPanel81.setLayout(null);

        jButton200.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton200.setForeground(new java.awt.Color(255, 255, 255));
        jButton200.setText("EPISODE 1");
        jButton200.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton200.setContentAreaFilled(false);
        jButton200.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton200.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton200ActionPerformed(evt);
            }
        });
        jPanel81.add(jButton200);
        jButton200.setBounds(10, 10, 100, 25);

        jButton201.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton201.setForeground(new java.awt.Color(255, 255, 255));
        jButton201.setText("EPISODE 2");
        jButton201.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton201.setContentAreaFilled(false);
        jButton201.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel81.add(jButton201);
        jButton201.setBounds(140, 10, 100, 25);

        jButton202.setBackground(new java.awt.Color(0, 0, 0));
        jButton202.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton202.setForeground(new java.awt.Color(255, 255, 255));
        jButton202.setText("EPISODE 3");
        jButton202.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton202.setContentAreaFilled(false);
        jButton202.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel81.add(jButton202);
        jButton202.setBounds(260, 10, 100, 25);

        jButton203.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton203.setForeground(new java.awt.Color(255, 255, 255));
        jButton203.setText("EPISODE 4");
        jButton203.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton203.setContentAreaFilled(false);
        jButton203.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel81.add(jButton203);
        jButton203.setBounds(10, 43, 100, 25);

        jButton204.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton204.setForeground(new java.awt.Color(255, 255, 255));
        jButton204.setText("EPISODE 5");
        jButton204.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton204.setContentAreaFilled(false);
        jButton204.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel81.add(jButton204);
        jButton204.setBounds(140, 43, 100, 25);

        jButton205.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton205.setForeground(new java.awt.Color(255, 255, 255));
        jButton205.setText("EPISODE 6");
        jButton205.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton205.setContentAreaFilled(false);
        jButton205.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel81.add(jButton205);
        jButton205.setBounds(260, 43, 100, 25);

        jButton206.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton206.setForeground(new java.awt.Color(255, 255, 255));
        jButton206.setText("EPISODE 7");
        jButton206.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton206.setContentAreaFilled(false);
        jButton206.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel81.add(jButton206);
        jButton206.setBounds(10, 77, 100, 25);

        jButton207.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton207.setForeground(new java.awt.Color(255, 255, 255));
        jButton207.setText("EPISODE 8");
        jButton207.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton207.setContentAreaFilled(false);
        jButton207.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel81.add(jButton207);
        jButton207.setBounds(140, 77, 100, 25);

        jButton208.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton208.setForeground(new java.awt.Color(255, 255, 255));
        jButton208.setText("EPISODE 9");
        jButton208.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton208.setContentAreaFilled(false);
        jButton208.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel81.add(jButton208);
        jButton208.setBounds(260, 77, 100, 25);

        ep_btn5.setVisible(false);
        ep_btn5.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16 (1).png")); // NOI18N
        ep_btn5.setContentAreaFilled(false);
        ep_btn5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ep_btn5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ep_btn5MouseClicked(evt);
            }
        });
        ep_btn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ep_btn5ActionPerformed(evt);
            }
        });
        jPanel81.add(ep_btn5);
        ep_btn5.setBounds(200, 107, 20, 20);

        ep_btn6.setVisible(false);
        ep_btn6.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16.png")); // NOI18N
        ep_btn6.setContentAreaFilled(false);
        ep_btn6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ep_btn6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ep_btn6MouseClicked(evt);
            }
        });
        ep_btn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ep_btn6ActionPerformed(evt);
            }
        });
        jPanel81.add(ep_btn6);
        ep_btn6.setBounds(170, 107, 20, 20);

        jPanel56.add(jPanel81);
        jPanel81.setBounds(750, 1780, 370, 130);

        jPanel82.setVisible(false);
        jPanel82.setBackground(new java.awt.Color(0, 0, 0));
        jPanel82.setLayout(null);

        jButton209.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton209.setForeground(new java.awt.Color(255, 255, 255));
        jButton209.setText("EPISODE 10");
        jButton209.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton209.setContentAreaFilled(false);
        jButton209.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel82.add(jButton209);
        jButton209.setBounds(10, 10, 100, 25);

        jButton210.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton210.setForeground(new java.awt.Color(255, 255, 255));
        jButton210.setText("EPISODE 11");
        jButton210.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton210.setContentAreaFilled(false);
        jButton210.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel82.add(jButton210);
        jButton210.setBounds(140, 10, 100, 25);

        jButton211.setBackground(new java.awt.Color(0, 0, 0));
        jButton211.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton211.setForeground(new java.awt.Color(255, 255, 255));
        jButton211.setText("EPISODE 12");
        jButton211.setToolTipText("");
        jButton211.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton211.setContentAreaFilled(false);
        jButton211.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel82.add(jButton211);
        jButton211.setBounds(260, 10, 100, 25);

        jButton212.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton212.setForeground(new java.awt.Color(255, 255, 255));
        jButton212.setText("EPISODE 13");
        jButton212.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton212.setContentAreaFilled(false);
        jButton212.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel82.add(jButton212);
        jButton212.setBounds(10, 43, 100, 25);

        jButton213.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton213.setForeground(new java.awt.Color(255, 255, 255));
        jButton213.setText("EPISODE 14");
        jButton213.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton213.setContentAreaFilled(false);
        jButton213.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel82.add(jButton213);
        jButton213.setBounds(140, 43, 100, 25);

        jButton214.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton214.setForeground(new java.awt.Color(255, 255, 255));
        jButton214.setText("EPISODE 15");
        jButton214.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton214.setContentAreaFilled(false);
        jButton214.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel82.add(jButton214);
        jButton214.setBounds(260, 43, 100, 25);

        jButton215.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton215.setForeground(new java.awt.Color(255, 255, 255));
        jButton215.setText("EPISODE 16");
        jButton215.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton215.setContentAreaFilled(false);
        jButton215.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel82.add(jButton215);
        jButton215.setBounds(10, 77, 100, 25);

        jButton216.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton216.setForeground(new java.awt.Color(255, 255, 255));
        jButton216.setText("EPISODE 17");
        jButton216.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton216.setContentAreaFilled(false);
        jButton216.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel82.add(jButton216);
        jButton216.setBounds(140, 77, 100, 25);

        jButton217.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton217.setForeground(new java.awt.Color(255, 255, 255));
        jButton217.setText("EPISODE 18");
        jButton217.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton217.setContentAreaFilled(false);
        jButton217.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel82.add(jButton217);
        jButton217.setBounds(260, 77, 100, 25);

        ep_btn7.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16.png")); // NOI18N
        ep_btn7.setContentAreaFilled(false);
        ep_btn7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ep_btn7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ep_btn7MouseClicked(evt);
            }
        });
        ep_btn7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ep_btn7ActionPerformed(evt);
            }
        });
        jPanel82.add(ep_btn7);
        ep_btn7.setBounds(200, 107, 20, 20);

        ep_btn8.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-filled-circle-16 (1).png")); // NOI18N
        ep_btn8.setContentAreaFilled(false);
        ep_btn8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ep_btn8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ep_btn8MouseClicked(evt);
            }
        });
        ep_btn8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ep_btn8ActionPerformed(evt);
            }
        });
        jPanel82.add(ep_btn8);
        ep_btn8.setBounds(170, 107, 20, 20);

        jPanel56.add(jPanel82);
        jPanel82.setBounds(1140, 1780, 370, 130);

        jPanel40.add(jPanel56);
        jPanel56.setBounds(0, 0, 1930, 3060);

        jPanel38.setVisible(false);
        jPanel38.setBackground(new java.awt.Color(0, 0, 0));
        jPanel38.setLayout(null);

        jButton30.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton30.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton30ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton30);
        jButton30.setBounds(0, 70, 330, 190);

        jButton35.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton35.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton35ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton35);
        jButton35.setBounds(390, 70, 330, 190);

        jButton36.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton36.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton36ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton36);
        jButton36.setBounds(770, 70, 330, 190);

        jButton38.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton38.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton38ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton38);
        jButton38.setBounds(1150, 70, 330, 190);

        jButton39.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton39.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton39ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton39);
        jButton39.setBounds(1540, 70, 330, 190);

        jButton41.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton41.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton41ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton41);
        jButton41.setBounds(0, 330, 330, 190);

        jButton42.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton42.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton42ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton42);
        jButton42.setBounds(390, 330, 330, 190);

        jButton43.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton43.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton43ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton43);
        jButton43.setBounds(770, 330, 330, 190);

        jButton44.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton44.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton44ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton44);
        jButton44.setBounds(1150, 330, 330, 190);

        jButton45.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton45.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton45ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton45);
        jButton45.setBounds(1540, 330, 330, 190);

        jButton46.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton46.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton46ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton46);
        jButton46.setBounds(0, 600, 330, 190);

        jButton47.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton47.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton47ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton47);
        jButton47.setBounds(390, 600, 330, 190);

        jButton48.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton48.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton48ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton48);
        jButton48.setBounds(770, 600, 330, 190);

        jButton49.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton49.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton49.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton49ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton49);
        jButton49.setBounds(1150, 600, 330, 190);

        jButton50.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton50.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton50ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton50);
        jButton50.setBounds(1540, 600, 330, 190);

        jButton51.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton51.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton51.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton51ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton51);
        jButton51.setBounds(0, 870, 330, 190);

        jButton52.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton52.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton52ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton52);
        jButton52.setBounds(390, 870, 330, 190);

        jButton53.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton53.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton53.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton53ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton53);
        jButton53.setBounds(770, 870, 330, 190);

        jButton54.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton54.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton54.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton54ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton54);
        jButton54.setBounds(1150, 870, 330, 190);

        jButton55.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jButton55.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton55.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton55ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton55);
        jButton55.setBounds(1540, 870, 330, 190);

        jPanel41.setBackground(new java.awt.Color(0, 0, 0));
        jPanel41.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        search_wt.setBackground(new java.awt.Color(0, 0, 0));
        search_wt.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-play-30.png")); // NOI18N
        search_wt.setContentAreaFilled(false);
        search_wt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_wtActionPerformed(evt);
            }
        });
        jPanel41.add(search_wt, new org.netbeans.lib.awtextra.AbsoluteConstraints(-1, 5, 40, -1));

        search_add_list.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-plus-30.png")); // NOI18N
        search_add_list.setContentAreaFilled(false);
        search_add_list.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                search_add_listMouseEntered(evt);
            }
        });
        jPanel41.add(search_add_list, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 40, -1));

        search_fav.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-star-35.png")); // NOI18N
        search_fav.setContentAreaFilled(false);
        jPanel41.add(search_fav, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 40, 40));

        jPanel38.add(jPanel41);
        jPanel41.setBounds(720, 70, 40, 190);

        jLabel15.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-sad-48.png")); // NOI18N
        jLabel15.setText("Sorry !! No data found.....PLEASE SEARCH BY MOVIE NAME,HERO,GENRE");
        jPanel38.add(jLabel15);
        jLabel15.setBounds(80, 110, 730, 50);

        jButton37.setIcon(new javax.swing.ImageIcon("C:\\Users\\dines\\Desktop\\se7en\\se7en images\\icons8-close-window-34.png")); // NOI18N
        jButton37.setContentAreaFilled(false);
        jButton37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton37ActionPerformed(evt);
            }
        });
        jPanel38.add(jButton37);
        jButton37.setBounds(930, 10, 30, 40);

        jPanel40.add(jPanel38);
        jPanel38.setBounds(0, 0, 1990, 3070);

        jPanel83.setVisible(false);
        jPanel83.setBackground(new java.awt.Color(0, 0, 0));
        jPanel83.setLayout(null);

        jButton223.setBorder(null);
        jButton223.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton223.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton223ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton223);
        jButton223.setBounds(0, 70, 330, 190);

        jButton296.setBorder(null);
        jButton296.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton296.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton296ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton296);
        jButton296.setBounds(390, 70, 330, 190);

        jButton297.setBorder(null);
        jButton297.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton297.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton297ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton297);
        jButton297.setBounds(770, 70, 330, 190);

        jButton298.setBorder(null);
        jButton298.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton298.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton298ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton298);
        jButton298.setBounds(1150, 70, 330, 190);

        jButton299.setBorder(null);
        jButton299.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton299.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton299ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton299);
        jButton299.setBounds(1540, 70, 330, 190);

        jButton300.setBorder(null);
        jButton300.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton300.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton300ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton300);
        jButton300.setBounds(0, 330, 330, 190);

        jButton306.setBorder(null);
        jButton306.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton306.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton306ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton306);
        jButton306.setBounds(390, 330, 330, 190);

        jButton307.setBorder(null);
        jButton307.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton307.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton307ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton307);
        jButton307.setBounds(770, 330, 330, 190);

        jButton308.setBorder(null);
        jButton308.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton308.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton308ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton308);
        jButton308.setBounds(1150, 330, 330, 190);

        jButton309.setBorder(null);
        jButton309.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton309.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton309ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton309);
        jButton309.setBounds(1540, 330, 330, 190);

        jButton310.setBorder(null);
        jButton310.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton310.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton310ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton310);
        jButton310.setBounds(0, 600, 330, 190);

        jButton311.setBorder(null);
        jButton311.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton311.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton311ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton311);
        jButton311.setBounds(390, 600, 330, 190);

        jButton312.setBorder(null);
        jButton312.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton312.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton312ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton312);
        jButton312.setBounds(770, 600, 330, 190);

        jButton313.setBorder(null);
        jButton313.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton313.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton313ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton313);
        jButton313.setBounds(1150, 600, 330, 190);

        jButton314.setBorder(null);
        jButton314.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton314.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton314ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton314);
        jButton314.setBounds(1540, 600, 330, 190);

        jButton315.setBorder(null);
        jButton315.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton315.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton315ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton315);
        jButton315.setBounds(0, 870, 330, 190);

        jButton316.setBorder(null);
        jButton316.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton316.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton316ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton316);
        jButton316.setBounds(390, 870, 330, 190);

        jButton317.setBorder(null);
        jButton317.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton317.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton317ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton317);
        jButton317.setBounds(770, 870, 330, 190);

        jButton318.setBorder(null);
        jButton318.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton318.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton318ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton318);
        jButton318.setBounds(1150, 870, 330, 190);

        jButton319.setBorder(null);
        jButton319.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton319.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton319ActionPerformed(evt);
            }
        });
        jPanel83.add(jButton319);
        jButton319.setBounds(1540, 870, 330, 190);

        jPanel40.add(jPanel83);
        jPanel83.setBounds(0, 0, 1990, 3070);

        jPanel1.add(jPanel40);
        jPanel40.setBounds(0, 280, 1930, 2750);

        jPanel11.setVisible(false);
        jPanel11.setBackground(new java.awt.Color(0, 0, 0));
        jPanel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jPanel11.setLayout(null);

        jLabel32.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(0, 204, 204));
        jLabel32.setText("Mail Us at team@seven.co.in");
        jPanel11.add(jLabel32);
        jLabel32.setBounds(80, 30, 320, 29);

        jLabel35.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("Phn: 040-34545341  #SPAIN");
        jPanel11.add(jLabel35);
        jLabel35.setBounds(80, 230, 350, 29);

        jLabel36.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("Phn: 040-34545347 #INDIA");
        jPanel11.add(jLabel36);
        jLabel36.setBounds(80, 80, 310, 29);

        jLabel37.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("Phn: 040-34545345 #USA");
        jPanel11.add(jLabel37);
        jLabel37.setBounds(80, 130, 300, 29);

        jLabel38.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("Phn: 040-34545340 #GERMANY");
        jPanel11.add(jLabel38);
        jLabel38.setBounds(80, 180, 360, 29);

        jButton221.setBackground(new java.awt.Color(0, 0, 0));
        jButton221.setFont(new java.awt.Font("Arial", 0, 22)); // NOI18N
        jButton221.setForeground(new java.awt.Color(255, 255, 255));
        jButton221.setText("CANCEL");
        jButton221.setContentAreaFilled(false);
        jButton221.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton221.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton221MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton221MouseExited(evt);
            }
        });
        jButton221.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton221ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton221);
        jButton221.setBounds(180, 280, 130, 35);

        jPanel1.add(jPanel11);
        jPanel11.setBounds(1260, 3030, 510, 330);

        jPanel15.add(jPanel1);

        jScrollPane2.setViewportView(jPanel15);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(0, 0, 1930, 3390);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchActionPerformed
    public void movie_search()
    {
         jLabel15.setVisible(false);
         jPanel41.setVisible(false);
        jPanel38.setVisible(true);
        jButton37.setVisible(true);
        jPanel9.setBounds(1680, 80, 230, 310);
            jPanel9.setVisible(false);//menu
        jPanel40.removeAll();
        jPanel40.repaint();
        jPanel40.revalidate();
        jPanel40.add(jPanel38);
        jPanel40.repaint();
        jPanel40.revalidate();
        
        JButton [] btn=new JButton[1000];
        btn[0]=jButton30;
        btn[1]=jButton35;
        btn[2]=jButton36;
        btn[3]=jButton38;
        btn[4]=jButton39;
        btn[5]=jButton41;
        btn[6]=jButton42;
        btn[7]=jButton43;
        btn[8]=jButton44;
        btn[9]=jButton45;
        btn[10]=jButton46;
        btn[11]=jButton47;
        btn[12]=jButton48;
        btn[13]=jButton49;
        btn[14]=jButton50;
        btn[15]=jButton51;
        btn[16]=jButton52;
        btn[17]=jButton53;
        btn[18]=jButton54;
        btn[19]=jButton55;
   //     btn[20]=jButton36;
   //     btn[21]=jButton30;
   //     btn[22]=jButton35;
   //     btn[23]=jButton36;
        
        String searched=search.getText();
        searched=searched.toLowerCase();
       // System.out.println(searched);
        String [] movie=new String[100];
        int i=0,p=0;
      //  String sql="select * from movies where movie_name='"+searched+"'";
         try
        {
                    
String sql="(select * from movies where movie_name='"+searched+"' or genre='"+searched+"' or hero ='"+searched+"' or lang='"+searched+"' or director='"+searched+"') "
        + "union (select * from movies where movie_name REGEXP '"+searched+"' order by rating desc) union (select * from movies where genre REGEXP '"+searched+"' order by rating desc) union (select * from movies where  hero REGEXP '"+searched+"' order by rating desc) union (select * from movies where lang REGEXP '"+searched+"' order by rating desc) union (select * from movies where director REGEXP '"+searched+"' order by rating desc) ";
                   ResultSet res=stmt.executeQuery(sql);
                      while(res.next())
                   {
                        movie[i]=res.getString("movie_name");
                        i++;
                    }
                    
                          for(p=0;p<i;p++)
                            {
                                
                                if(p<20)
                            {
                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                    loc=loc+movie[p]+".png";
                                    btn[p].setVisible(true);
                                    btn[p].setIcon(new ImageIcon(loc));
                                   // jButton43.setI
                                   btn[p].setText(movie[p]);
                                //   btn[p].setForeground(Color.white);
                            }
                                else
                                {
                                    break;
                                }
                                
                            }
                    int size=searched.length();
                    String trash=""; 
                    int w=0;
                    for(int x=0;x<size-1;x++)
                     {
                         trash=trash+searched.charAt(x);
                         for(int y=x+1;y<size;y++)
                         {
                             trash=trash+searched.charAt(y);
                             sql=" select * from movies where movie_name REGEXP '"+trash+"' or genre REGEXP '"+trash+"' or hero REGEXP '"+trash+"' or lang REGEXP '"+trash+"' or director REGEXP '"+trash+"' order by rating desc";
                             res=stmt.executeQuery(sql);
                            while(res.next())
                             {
                                                    String check=res.getString("movie_name");
                                                    for(w=0;w<i;w++)
                                                    {
                                                        if(check.equals(movie[w]))
                                                        {
                                                            break;
                                                        }
                                                    }
                                                    if(w==i)
                                                    {
                                                        movie[i]=res.getString("movie_name");
                                                        i++;
                                                    }
                                           
                              }
                                if(i==0)
                                {
                                    jLabel15.setVisible(true);
                                }
                                        
                                             for(int z=p;z<i;z++)
                                               {

                                                   if(z<20)
                                                     {
                                                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                                                loc=loc+movie[z]+".png";
                                                                btn[z].setVisible(true);
                                                                btn[z].setIcon(new ImageIcon(loc));
                                                               // jButton43.setI
                                                                btn[z].setText(movie[z]);
                                                            //   btn[p].setForeground(Color.white);
                                                      }
                                                    else
                                                      {
                                                            break;
                                                      }
                                
                                                }
                         }
                         trash="";
                     }
                            for( p=i;p<20;p++)
                            {
                                btn[p].setVisible(false);
                            }
                            search.setText("");
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(this, "3...........");
        }
    }
    public void tvshow_search()
    {
         jLabel15.setVisible(false);
         jPanel41.setVisible(false);
        jPanel38.setVisible(true);
        jButton37.setVisible(true);
        jPanel9.setBounds(1680, 80, 230, 310);
            jPanel9.setVisible(false);//menu
        jPanel40.removeAll();
        jPanel40.repaint();
        jPanel40.revalidate();
        jPanel40.add(jPanel38);
        jPanel40.repaint();
        jPanel40.revalidate();
        
        JButton [] btn=new JButton[1000];
        btn[0]=jButton30;
        btn[1]=jButton35;
        btn[2]=jButton36;
        btn[3]=jButton38;
        btn[4]=jButton39;
        btn[5]=jButton41;
        btn[6]=jButton42;
        btn[7]=jButton43;
        btn[8]=jButton44;
        btn[9]=jButton45;
        btn[10]=jButton46;
        btn[11]=jButton47;
        btn[12]=jButton48;
        btn[13]=jButton49;
        btn[14]=jButton50;
        btn[15]=jButton51;
        btn[16]=jButton52;
        btn[17]=jButton53;
        btn[18]=jButton54;
        btn[19]=jButton55;
   //     btn[20]=jButton36;
   //     btn[21]=jButton30;
   //     btn[22]=jButton35;
   //     btn[23]=jButton36;
        int zami=0;
        String searched=search.getText();
        searched=searched.toLowerCase();
       // System.out.println(searched);
        String [] movie=new String[100];
        int i=0,p=0,zex=0;
      //  String sql="select * from movies where movie_name='"+searched+"'";
         try
        {
                    
String sql="(select * from tv_shows where show_name='"+searched+"' or genre='"+searched+"' or hero ='"+searched+"' or lang='"+searched+"') "
        + "union (select * from tv_shows where show_name REGEXP '"+searched+"' order by rating desc) union (select * from tv_shows where genre REGEXP '"+searched+"' order by rating desc)  union (select * from tv_shows where lang REGEXP '"+searched+"' order by rating desc)";
                   ResultSet res=stmt.executeQuery(sql);
                      while(res.next())
                   {
                       System.out.println(res.getString("show_name"));
                       String macha="";
                       String sexa[]=res.getString("show_name").split(" ");
                       for(int arnab=0;arnab<sexa.length-2;arnab++)
                       {
                           macha=macha+sexa[arnab]+" ";
                       }
                       macha=macha+sexa[sexa.length-2];
                       for(zami=0;zami<i;zami++)
                       {
                           if(movie[zami].equals(macha))
                           {
                               break;
                           }
                       }
                       if(zami==i)
                       {
                           movie[i]=macha;
                            i++;
                       }
                       
                    }
                    
                          for(p=0;p<i;p++)
                            {
                                
                                        if(p<20)
                                    {
                                        String loc="C://Users//dines//Desktop//se7en//originals//";
                                           // String sexa[]=movie[p].split("[1-9]$");
                                            loc=loc+movie[p]+".png";
                                            Icon ikea=new ImageIcon(loc);
                                            for(zex=0;zex<p;zex++)
                                            {
                                                if(btn[zex].getIcon()==ikea)
                                                {
                                                    p--;
                                                    break;
                                                }
                                            }
                                            if(zex==p)
                                            {
                                                btn[p].setVisible(true);
                                                btn[p].setIcon(new ImageIcon(loc));
                                                btn[p].setText(movie[p]);
                                            }

                                           // jButton43.setI

                                        //   btn[p].setForeground(Color.white);
                                    }
                                else
                                {
                                    break;
                                }
                                
                            }
                          System.out.println(Arrays.toString(movie));
                    int size=searched.length();
                    String trash=""; 
                    int w=0;
                    for(int x=0;x<size-1;x++)
                     {
                         trash=trash+searched.charAt(x);
                         for(int y=x+1;y<size;y++)
                         {
                             trash=trash+searched.charAt(y);
                             sql=" select * from tv_shows where show_name REGEXP '"+trash+"' or genre REGEXP '"+trash+"'  or lang REGEXP '"+trash+"'";
                             res=stmt.executeQuery(sql);
                            while(res.next())
                             {
                                                    //String check=res.getString("show_name");
                                                           String macha="";
                                                           String sexa[]=res.getString("show_name").split(" ");
                                                           for(int arnab=0;arnab<sexa.length-2;arnab++)
                                                           {
                                                               macha=macha+sexa[arnab]+" ";
                                                           }
                                                           macha=macha+sexa[sexa.length-2];
                                                           
                                                    for(w=0;w<i;w++)
                                                    {
                                                        if(macha.equals(movie[w]))
                                                        {
                                                            break;
                                                        }
                                                    }
                                                    if(w==i)
                                                    {
                                                       // String sexa[]=res.getString("show_name").split("[0-9]$");
                                                     
                                                           //macha="";
                                                           //String sexa[]=res.getString("show_name").split(" ");
                                                          
                                                            movie[i]=macha;
                                                            i++;
                                                       
                                                     
                                                    }
                                           
                              }
                            
                                if(i==0)
                                {
                                    jLabel15.setVisible(true);
                                }
                                            
                                             for(int z=p;z<i;z++)
                                               {

                                                   if(z<20)
                                                     {
                                                              //  System.out.println(movie.length);
                                                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                                                //String sexa[]=movie[mx].split(" [0-9]$");
                                                                loc=loc+movie[z]+".png";
                                                                
                                                                    btn[z].setVisible(true);
                                                                    btn[z].setIcon(new ImageIcon(loc));
                                                                    btn[z].setText(movie[z]);
                                                                  //  System.out.println(sexa[0]);
                                                                
                                                            //   btn[p].setForeground(Color.white);
                                                      }
                                                    else
                                                      {
                                                            break;
                                                      }
                                                   
                                                }
                         }
                         trash="";
                     }
                            for( p=i;p<20;p++)
                            {
                                btn[p].setVisible(false);
                            }
                            search.setText("");
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(this, "3...........");
        }
    }
    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        if(search_flag==0)
        {
            movie_search();
        }
        else
        {
            tvshow_search();
        }
       
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        search.setVisible(true);
            jButton6.setVisible(true);
        search_flag=0;
         jButton27.setForeground(Color.white);
        //jButton26.setForeground(Color.white);
        jButton28.setForeground(Color.white);
         jPanel40.removeAll();
        jPanel40.repaint();
        jPanel40.revalidate();

        jPanel40.add(jPanel3);
       jPanel40.repaint();
        jPanel40.revalidate();
       
      jPanel9.setBounds(1680, 80, 230, 310);
            jPanel9.setVisible(false);
      //  jPanel38.setVisible(false);
        jButton2.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton1.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.red));
          jButton3.setBorder(BorderFactory.createMatteBorder(0, 2, 0, 2, Color.red));
          jButton4.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton5.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton222.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
          //jButton3.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        // TODO add your handling code here:
        // jButton1.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.red));
    }//GEN-LAST:event_jButton1MouseClicked
public void recom(String string)
{
   JButton [] btn=new JButton[1000];
        btn[0]=jButton40;
        btn[1]=jButton56;
        btn[2]=jButton57;
        btn[3]=jButton58;
        btn[4]=jButton59;
        btn[5]=jButton60;
   
    String gen="";
    int ui=0,r=0;
    int g=0;
    int k=0;
    String [] rt1=new String[100];
    String [] tr1=new String [100];
    int mx=0;
    String lang1="";
    int z=0,pi=0,highest=0;
    try
    {
            String sql="select * from movies where movie_name = '"+string+"' " ;
            ResultSet res=stmt.executeQuery(sql);
          
            if(res.next())
            {
                 gen=res.getString("genre");
                   lang1=res.getString("lang");
                 System.out.println(gen);
            }
            res.close();
              String sql_1="SELECT *, ROW_NUMBER() OVER(order by rating desc,movie_name) AS Row_Number FROM movies where genre='"+gen+"'";
                ResultSet set1=stmt.executeQuery(sql_1);
                while(set1.next())
                {
                    rt1[mx]=set1.getString("movie_name");
                    tr1[mx]=set1.getString("Row_Number");
                    mx++;
                }
                   set1.close();
            for(int y=0;y<6;y++)
            { 
               String check=btn[y].getText();
               for(int s=0;s<mx;s++)
               {
                   if(check.equals(rt1[s]))
                   {
                       if(highest<Integer.parseInt(tr1[s]))
                       {
                            highest=Integer.parseInt(tr1[s]);
                       }
                    }
               }
              
            }
            System.out.println(highest+"----->highest");
           int highest_1=highest;
            sql="select * from movies where genre= '"+gen+"' order by rating desc";
            ResultSet res3=stmt.executeQuery(sql);
        
           int t=0;
           String [] trash=new String [100];
                while(res3.next())
                {
                   trash[t]=res3.getString("movie_name");
                   System.out.println(trash[t]);
                   t++;
                }
                res3.close();
                  
            
                int u=0;
                String [] rt=new String[1000];
                for(u=0;u<6;u++)
                {
                    rt[u]=btn[u].getText();
                }
                   
                                for(int q=0;q<t;q++)
                {
                        String mov=btn[k].getText();
                      
                            String sql1="select * from movies where movie_name='"+mov+"' ";
                            ResultSet res2=stmt.executeQuery(sql1);
                      
                        
                        
                        if(res2.next())
                        {
                        if(gen.equals(res2.getString("genre")))
                        {
                            for(u=0;u<highest;u++)
                            {
                                if(btn[k].getText().equals(trash[u]))
                                {
                                    break;
                                }
                                
                                   
                                
                            }
                            if(u==highest)
                            {
                                             System.out.println("mg");
                            }
                            else
                            {
                                if(string.equals(btn[k].getText()))
                                {
                                    if(!string.equals(trash[highest]))
                                    {   
                                               if(highest<t)
                                               {
                                                        String po=trash[highest];
                                                        String loc="C://Users//dines//Desktop//se7en//originals//";
                                                        loc=loc+po+".png";
                                                        btn[k].setIcon(new ImageIcon(loc));
                                                        btn[k].setText(po);
                                                        z++;
                                                        highest++;
                                               }
                                    
                                    else
                                    {
                                                for( r=0;r<highest;r++)
                                                {
                                                    for( g=0;g<6;g++)
                                                    {
                                                    if(btn[g].getText().equals(trash[r]) )
                                                    {
                                                        break;
                                                    }
                                                    }
                                                    if(g==6)
                                                    {
                                                        if(!string.equals(trash[r]))
                                                        {
                                                                System.out.println("gh");
                                                                String po=trash[r];
                                                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                                                loc=loc+po+".png";
                                                                btn[k].setIcon(new ImageIcon(loc));
                                                                btn[k].setText(po);
                                                                z++;
                                                                // zin++;
                                                                // highest++;
                                                                break;

                                                        }

                                                    }
                                                }
                                    }
                                }
                                    else
                                    {
                                                      for( r=0;r<highest;r++)
                                                {
                                                    for( g=0;g<6;g++)
                                                    {
                                                    if(btn[g].getText().equals(trash[r]) )
                                                    {
                                                        break;
                                                    }
                                                    }
                                                    if(g==6)
                                                    {
                                                        if(!string.equals(trash[r]))
                                                        {
                                                                System.out.println("gh");
                                                                String po=trash[r];
                                                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                                                loc=loc+po+".png";
                                                                btn[k].setIcon(new ImageIcon(loc));
                                                                btn[k].setText(po);
                                                                z++;
                                                                // zin++;
                                                                // highest++;
                                                                break;

                                                        }

                                                    }
                                                }
                                        
                                    }
                                }
                            }
                               
                        }
                        else
                        {
                           int zin=0;
                           
                                for( r=0;r<highest;r++)
                                {
                                    for( g=0;g<6;g++)
                                    {
                                    if(btn[g].getText().equals(trash[r]) )
                                    {
                                        break;
                                    }
                                    }
                                    if(g==6)
                                    {
                                        if(!string.equals(trash[r]))
                                        {
                                                System.out.println("gh");
                                                String po=trash[r];
                                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                                loc=loc+po+".png";
                                                btn[k].setIcon(new ImageIcon(loc));
                                                btn[k].setText(po);
                                                z++;
                                                 zin++;
                                                // highest++;
                                                break;
                                                
                                    }
                                               
                                    }
                                }
                                    if(zin==0)
                                    {
                                        if(!string.equals(trash[highest]))
                                        {
                                                System.out.println("g23h");
                                                String po=trash[highest];
                                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                                loc=loc+po+".png";
                                                btn[k].setIcon(new ImageIcon(loc));
                                                btn[k].setText(po);
                                                z++;
                                                highest++;
                                               // break;
                                        }
                                        else
                                        {
                                             System.out.println("g233h");
                                             highest++;
                                                String po=trash[highest];
                                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                                loc=loc+po+".png";
                                                btn[k].setIcon(new ImageIcon(loc));
                                                btn[k].setText(po);
                                                z++;
                                                highest++;
                                        }
                                    }
}
                         System.out.println("hi");
                       if(z%2==0&&z!=0)
                        {
                            break;
                        }
                        }
                        
               k++;
               if(k<6)
               {
                   jPanel54.setVisible(true);
                   int c=0,x=0;
                   JButton [] btn7 =new JButton[100];
                   btn7[0]=jButton62;
                   btn7[1]=jButton63;
                   btn7[2]=jButton64;
                   btn7[3]=jButton65;
                   btn7[4]=jButton66;
                   btn7[5]=jButton67;
                   String sql7="select * from movies where lang='"+lang1+"' and genre <>'"+gen+"' order by rating desc";
                   ResultSet res7=stmt.executeQuery(sql7);
                   while(res7.next())
                   {
                       String china=res7.getString("movie_name");
                       for(x=0;x<6;x++)
                       {
                           if(btn[x].getText().equals(china))
                           {
                               break;
                           }
                       }
                       if(x==6)
                       {
                                                //String po=china;
                                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                                loc=loc+china+".png";
                                                btn7[c].setIcon(new ImageIcon(loc));
                                                btn7[c].setText(china);
                                                 c++;
                       }
                       
                       if(c>=6)
                       {
                           break;
                       }
                   }
                  // break;
               }
               else
               {
                   break;
               }
               res2.close();
              
                }
               
                    
            
    }
    catch(Exception ex)
    {
         JOptionPane.showMessageDialog(this,ex);
         ex.printStackTrace();
    }
            
}
    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
        // TODO add your handling code here:
        search.setVisible(false);
            jButton6.setVisible(false);
         jButton28.setForeground(Color.red);
        //jButton26.setForeground(Color.white);
        jButton27.setForeground(Color.white);
        
        jPanel9.setBounds(1680, 80, 230, 310);
            jPanel9.setVisible(false);
        jPanel83.setVisible(true);
        //jButton27.setForeground(Color.red);
        //jButton26.setForeground(Color.white);
       // jButton28.setForeground(Color.white);
          jPanel40.removeAll();
        jPanel40.repaint();
        jPanel40.revalidate();

        jPanel40.add(jPanel83);
       jPanel40.repaint();
        jPanel40.revalidate();
        
      //  jPanel58.setVisible(false);
        jButton2.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton1.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
          jButton3.setBorder(BorderFactory.createMatteBorder(0, 2, 0, 2, Color.orange));
          jButton4.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton5.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton222.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
    }//GEN-LAST:event_jButton28ActionPerformed

    private void jButton27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton27ActionPerformed
        // TODO add your handling code here:
      // jLabel15.setVisible(false);
        search.setVisible(false);
            jButton6.setVisible(false);
        jPanel9.setBounds(1680, 80, 230, 310);
            jPanel9.setVisible(false);
        jPanel56.setVisible(true);
        jButton27.setForeground(Color.red);
        //jButton26.setForeground(Color.white);
        jButton28.setForeground(Color.white);
          jPanel40.removeAll();
        jPanel40.repaint();
        jPanel40.revalidate();

        jPanel40.add(jPanel56);
       jPanel40.repaint();
        jPanel40.revalidate();
        
      //  jPanel58.setVisible(false);
        jButton2.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton1.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
          jButton3.setBorder(BorderFactory.createMatteBorder(0, 2, 0, 2, Color.orange));
          jButton4.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton5.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton222.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
        
    }//GEN-LAST:event_jButton27ActionPerformed
public void season()
{
    int count=0;
    JButton [] butn=new JButton[100];
    butn[0]=jButton109;
    butn[1]=jButton110;
    butn[2]=jButton111;
    butn[3]=jButton112;
    butn[4]=jButton113;
    butn[5]=jButton114;
    butn[6]=jButton115;
    butn[7]=jButton116;
    butn[8]=jButton117;
    for(int i=0;i<9;i++)
        {
            butn[i].setVisible(true);
        }
    System.out.println("show    ---->"+show);    
    try
    {
        String sql="select count(*) as count from tv_shows where show_name REGEXP '"+show+"'";
        ResultSet res=stmt.executeQuery(sql);
        if(res.next())
        {
              count=Integer.parseInt(res.getString("count"));
        }
        
        
        for(int i=0;i<count;i++)
        {
            butn[i].setVisible(true);
        }
        for(int i=count;i<9;i++)
        {
            butn[i].setVisible(false);
        }
        jPanel59.setVisible(true);
        jPanel60.setVisible(false);
        jPanel74.setVisible(false);
        
        
    }
    catch(Exception ex)
    {
         JOptionPane.showMessageDialog(this, ex);
    }
    
}
    private void jButton108ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton108ActionPerformed
        // TODO add your handling code here:
        
        season();
        
    }//GEN-LAST:event_jButton108ActionPerformed

    private void jButton107ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton107ActionPerformed
        // TODO add your handling code here:
        jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        
        jPanel57.setVisible(true);
        Rectangle r=thriller_show.getBounds();
        Rectangle t=jButton107.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
        jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
          show=jButton107.getText();
       // jLabel14.setVisible(false);
       // jLabel21.setVisible(false);
          dhoni="";
          dhoni=jButton107.getText();
          jPanel74.setVisible(false);
    }//GEN-LAST:event_jButton107ActionPerformed

    private void jButton111ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton111ActionPerformed
        // TODO add your handling code here:
        jPanel59.setVisible(false);
        jPanel60.setVisible(true);
        Rectangle r=jPanel59.getBounds();
        jPanel60.setBounds(r.x, r.y, r.width, r.height);
            jPanel74.setBounds(r.x, r.y, r.width, r.height);
            dhoni=dhoni+"_"+jButton111.getText();
            episode(3);
    }//GEN-LAST:event_jButton111ActionPerformed

    private void jButton129ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton129ActionPerformed
        // TODO add your handling code here:
        jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel74.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=thriller_show.getBounds();
        Rectangle t=jButton129.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
        jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
          show=jButton129.getText();
    }//GEN-LAST:event_jButton129ActionPerformed

    private void jButton130ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton130ActionPerformed
        // TODO add your handling code here:
        jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel74.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=thriller_show.getBounds();
        Rectangle t=jButton130.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
        jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
          show=jButton130.getText();
    }//GEN-LAST:event_jButton130ActionPerformed

    private void jButton131ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton131ActionPerformed
        // TODO add your handling code here:
        jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=thriller_show.getBounds();
        Rectangle t=jButton131.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
        jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
          show=jButton131.getText();
    }//GEN-LAST:event_jButton131ActionPerformed

    private void jButton132ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton132ActionPerformed
        // TODO add your handling code here:
        jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=thriller_show.getBounds();
        Rectangle t=jButton132.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
             show=jButton132.getText();
    }//GEN-LAST:event_jButton132ActionPerformed

    private void jButton133ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton133ActionPerformed
        // TODO add your handling code here:
         jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=drama_show.getBounds();
        Rectangle t=jButton133.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton133.getText();
    }//GEN-LAST:event_jButton133ActionPerformed

    private void jButton134ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton134ActionPerformed
        // TODO add your handling code here:
         jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=drama_show.getBounds();
        Rectangle t=jButton134.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton134.getText();
    }//GEN-LAST:event_jButton134ActionPerformed

    private void jButton135ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton135ActionPerformed
        // TODO add your handling code here:
         jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=drama_show.getBounds();
        Rectangle t=jButton135.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton135.getText();
           dhoni="";
          dhoni=jButton107.getText();
          jPanel74.setVisible(false);
    }//GEN-LAST:event_jButton135ActionPerformed

    private void jButton136ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton136ActionPerformed
        // TODO add your handling code here:
         jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=drama_show.getBounds();
        Rectangle t=jButton136.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton136.getText();
    }//GEN-LAST:event_jButton136ActionPerformed

    private void jButton137ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton137ActionPerformed
        // TODO add your handling code here:
         jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=drama_show.getBounds();
        Rectangle t=jButton137.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton137.getText();
    }//GEN-LAST:event_jButton137ActionPerformed
public void top10_show()
{
    int k=0;
    JButton [] butn=new JButton[100];
    butn[0]=jButton153;
    butn[1]=jButton154;
    butn[2]=jButton155;
    butn[3]=jButton156;
    butn[4]=jButton157;
    butn[5]=jButton158;
    butn[6]=jButton159;
    butn[7]=jButton160;
    butn[8]=jButton161;
    butn[9]=jButton162;
    
    try
    {
    String sql="select * from tv_shows where show_name like  \"%1\" order by rating desc limit 10";
    ResultSet res=stmt.executeQuery(sql);
    while(res.next())
    {
        String str=res.getString("show_name");
        String str1[]=str.split(" [0-9]$");
                                                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                                                loc=loc+str1[0]+".png";
                                                                butn[k].setIcon(new ImageIcon(loc));
                                                                butn[k].setText(str1[0]);
                                                                k++;
        
    }
    }
    catch(Exception ex)
    {
         JOptionPane.showMessageDialog(this, ex);
    }
    
}
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
      //   jPanel56.setVisible(false);
      //  jPanel40.setVisible(false);
      //  jPanel58.setVisible(true);
        search.setVisible(true);
            jButton6.setVisible(true);
        search_flag=1;
        jPanel58.setVisible(true);
         jButton27.setForeground(Color.white);
        //jButton26.setForeground(Color.white);
        jButton28.setForeground(Color.white);
     jPanel40.removeAll();
        jPanel40.repaint();
        jPanel40.revalidate();

        jPanel40.add(jPanel58);
       jPanel40.repaint();
        jPanel40.revalidate();
        jPanel9.setBounds(1680, 80, 230, 310);
            jPanel9.setVisible(false);
        jButton2.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.red));
         jButton1.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
          jButton3.setBorder(BorderFactory.createMatteBorder(0, 2, 0, 2, Color.red));
          jButton4.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton5.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton222.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
        // jPanel82.setVisible(false);
         top10_show();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton138ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton138ActionPerformed
        // TODO add your handling code here:
         jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=scifi_show.getBounds();
        Rectangle t=jButton138.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton138.getText();
           dhoni="";
          dhoni=jButton138.getText();
          jPanel74.setVisible(false);
    }//GEN-LAST:event_jButton138ActionPerformed

    private void jButton139ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton139ActionPerformed
        // TODO add your handling code here:
             jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=scifi_show.getBounds();
        Rectangle t=jButton139.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton139.getText();
    }//GEN-LAST:event_jButton139ActionPerformed

    private void jButton140ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton140ActionPerformed
        // TODO add your handling code here:
             jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=scifi_show.getBounds();
        Rectangle t=jButton140.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton140.getText();
    }//GEN-LAST:event_jButton140ActionPerformed

    private void jButton141ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton141ActionPerformed
        // TODO add your handling code here:
             jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=scifi_show.getBounds();
        Rectangle t=jButton141.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton141.getText();
    }//GEN-LAST:event_jButton141ActionPerformed

    private void jButton142ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton142ActionPerformed
        // TODO add your handling code here:
             jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=scifi_show.getBounds();
        Rectangle t=jButton142.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
             show=jButton142.getText();
    }//GEN-LAST:event_jButton142ActionPerformed

    private void jButton143ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton143ActionPerformed
        // TODO add your handling code here:
             jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=crime_show.getBounds();
        Rectangle t=jButton143.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton143.getText();
    }//GEN-LAST:event_jButton143ActionPerformed

    private void jButton144ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton144ActionPerformed
        // TODO add your handling code here:
         jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=crime_show.getBounds();
        Rectangle t=jButton144.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton144.getText();
           dhoni="";
          dhoni=jButton107.getText();
          jPanel74.setVisible(false);
    }//GEN-LAST:event_jButton144ActionPerformed

    private void jButton145ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton145ActionPerformed
        // TODO add your handling code here:
         jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=crime_show.getBounds();
        Rectangle t=jButton145.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton145.getText();
           dhoni="";
          dhoni=jButton145.getText();
          jPanel74.setVisible(false);
    }//GEN-LAST:event_jButton145ActionPerformed

    private void jButton146ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton146ActionPerformed
        // TODO add your handling code here:
         jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=crime_show.getBounds();
        Rectangle t=jButton146.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton146.getText();
    }//GEN-LAST:event_jButton146ActionPerformed

    private void jButton147ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton147ActionPerformed
        // TODO add your handling code here:
         jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=crime_show.getBounds();
        Rectangle t=jButton147.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton147.getText();
    }//GEN-LAST:event_jButton147ActionPerformed

    private void jButton148ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton148ActionPerformed
        // TODO add your handling code here:
         jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=comedy_show.getBounds();
        Rectangle t=jButton148.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton148.getText();
    }//GEN-LAST:event_jButton148ActionPerformed

    private void jButton149ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton149ActionPerformed
        // TODO add your handling code here:
           jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=comedy_show.getBounds();
        Rectangle t=jButton149.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton149.getText();
    }//GEN-LAST:event_jButton149ActionPerformed

    private void jButton150ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton150ActionPerformed
        // TODO add your handling code here:
           jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=comedy_show.getBounds();
        Rectangle t=jButton150.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton150.getText();
    }//GEN-LAST:event_jButton150ActionPerformed

    private void jButton151ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton151ActionPerformed
        // TODO add your handling code here:
           jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=comedy_show.getBounds();
        Rectangle t=jButton151.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton151.getText();
    }//GEN-LAST:event_jButton151ActionPerformed

    private void jButton152ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton152ActionPerformed
        // TODO add your handling code here:
           jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=comedy_show.getBounds();
        Rectangle t=jButton152.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton152.getText();
    }//GEN-LAST:event_jButton152ActionPerformed

    private void jButton112ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton112ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton112.getText();
        jPanel59.setVisible(false);
        jPanel60.setVisible(true);
        Rectangle r=jPanel59.getBounds();
        jPanel60.setBounds(r.x, r.y, r.width, r.height);
            jPanel74.setBounds(r.x, r.y, r.width, r.height);
            episode(4);
            
    }//GEN-LAST:event_jButton112ActionPerformed

    private void top10_btn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_top10_btn1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_top10_btn1MouseClicked

    private void top10_btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_top10_btn1ActionPerformed
        // TODO add your handling code here:
        top10_show.removeAll();
        top10_show.repaint();
        top10_show.revalidate();

        top10_show.add(jPanel71);
        top10_show.repaint();
        top10_show.revalidate();
        top10_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));
        top10_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));
         jPanel57.setVisible(false);
         jPanel59.setVisible(false);
         jPanel60.setVisible(false);
         
    }//GEN-LAST:event_top10_btn1ActionPerformed

    private void top10_btn2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_top10_btn2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_top10_btn2MouseClicked

    private void top10_btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_top10_btn2ActionPerformed
        // TODO add your handling code here:
                top10_show.removeAll();
        top10_show.repaint();
        top10_show.revalidate();

        top10_show.add(jPanel72);
        top10_show.repaint();
        top10_show.revalidate();
        top10_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));
        top10_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));
         jPanel57.setVisible(false);
         jPanel59.setVisible(false);
         jPanel60.setVisible(false);
    }//GEN-LAST:event_top10_btn2ActionPerformed

    private void jPanel73MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel73MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel73MouseExited
static String show="";
    private void jButton153ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton153ActionPerformed
        // TODO add your handling code here:
        jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=top10_show.getBounds();
        Rectangle t=jButton153.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton153.getText();
    }//GEN-LAST:event_jButton153ActionPerformed

    private void jButton154ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton154ActionPerformed
        // TODO add your handling code here:
            jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=top10_show.getBounds();
        Rectangle t=jButton154.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton154.getText();
    }//GEN-LAST:event_jButton154ActionPerformed

    private void jButton155ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton155ActionPerformed
        // TODO add your handling code here:
            jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=top10_show.getBounds();
        Rectangle t=jButton155.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton155.getText();
    }//GEN-LAST:event_jButton155ActionPerformed

    private void jButton156ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton156ActionPerformed
        // TODO add your handling code here:
            jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=top10_show.getBounds();
        Rectangle t=jButton156.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton156.getText();
    }//GEN-LAST:event_jButton156ActionPerformed

    private void jButton157ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton157ActionPerformed
        // TODO add your handling code here:
            jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=top10_show.getBounds();
        Rectangle t=jButton157.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton157.getText();
    }//GEN-LAST:event_jButton157ActionPerformed

    private void jButton158ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton158ActionPerformed
        // TODO add your handling code here:
            jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=top10_show.getBounds();
        Rectangle t=jButton158.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton158.getText();
    }//GEN-LAST:event_jButton158ActionPerformed

    private void jButton159ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton159ActionPerformed
        // TODO add your handling code here:
            jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=top10_show.getBounds();
        Rectangle t=jButton159.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton159.getText();
    }//GEN-LAST:event_jButton159ActionPerformed

    private void jButton160ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton160ActionPerformed
        // TODO add your handling code here:
            jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=top10_show.getBounds();
        Rectangle t=jButton160.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton160.getText();
    }//GEN-LAST:event_jButton160ActionPerformed

    private void jButton161ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton161ActionPerformed
        // TODO add your handling code here:
            jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=top10_show.getBounds();
        Rectangle t=jButton161.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton161.getText();
    }//GEN-LAST:event_jButton161ActionPerformed

    private void jButton162ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton162ActionPerformed
        // TODO add your handling code here:
            jPanel59.setVisible(false);
        jPanel60.setVisible(false);
        jPanel57.setVisible(true);
        Rectangle r=top10_show.getBounds();
        Rectangle t=jButton162.getBounds();
        jPanel59.setBounds(t.x, r.y+r.height-40, 370, 130);
           jPanel57.setBounds(t.x+t.width+2, r.y, 40, 190);
           show=jButton162.getText();
    }//GEN-LAST:event_jButton162ActionPerformed
public void episode(int ep)
{
    show=show+" "+ep;
    JButton [] butn=new JButton[100];
    butn[0]=jButton118;
    butn[1]=jButton119;
    butn[2]=jButton120;
    butn[3]=jButton121;
    butn[4]=jButton122;
    butn[5]=jButton123;
    butn[6]=jButton124;
    butn[7]=jButton125;
    butn[8]=jButton126;
    butn[9]=jButton163;
    butn[10]=jButton164;
    butn[11]=jButton165;
    butn[12]=jButton166;
    butn[13]=jButton167;
    butn[14]=jButton168;
    butn[15]=jButton169;
    butn[16]=jButton170;
    butn[17]=jButton171;
    
    try
    {
        String sql="select episodes from tv_shows where show_name='"+show+"'";
        ResultSet res=stmt.executeQuery(sql);
        if(res.next())
        {
            ep=Integer.parseInt(res.getString("episodes"));
            for(int i=0;i<ep;i++)
            {
                butn[i].setVisible(true);
            }
            if(ep<=9)
            {
                    for(int i=ep;i<18;i++)
            {
                butn[i].setVisible(false);
            }
                    ep_btn1.setVisible(false);
                    ep_btn2.setVisible(false);
            }
            else
            {
                    ep_btn1.setVisible(true);
                    ep_btn2.setVisible(true);
                    for(int i=ep;i<18;i++)
            {
                butn[i].setVisible(false);
            }
            }
            
            
        }
       // int ninja=len(show);
        show=show.substring(0,show.length()-2);
        System.out.println("this is a show"+show);
    }
    catch(Exception ex)
    {
        JOptionPane.showMessageDialog(this,ex);
    }
}
    private void jButton109ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton109ActionPerformed
        // TODO add your handling code here:
         jPanel59.setVisible(false);
        jPanel60.setVisible(true);
        Rectangle r=jPanel59.getBounds();
        jPanel60.setBounds(r.x, r.y, r.width, r.height);
        jPanel74.setBounds(r.x, r.y, r.width, r.height);
        dhoni=dhoni+"_"+jButton109.getText();
        episode(1);
    }//GEN-LAST:event_jButton109ActionPerformed

    private void jButton110ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton110ActionPerformed
        // TODO add your handling code here:
         jPanel59.setVisible(false);
        jPanel60.setVisible(true);
        Rectangle r=jPanel59.getBounds();
        jPanel60.setBounds(r.x, r.y, r.width, r.height);
            jPanel74.setBounds(r.x, r.y, r.width, r.height);
            dhoni=dhoni+"_"+jButton110.getText();
        episode(2);
    }//GEN-LAST:event_jButton110ActionPerformed

    private void ep_btn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ep_btn1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_ep_btn1MouseClicked

    private void ep_btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ep_btn1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ep_btn1ActionPerformed

    private void ep_btn2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ep_btn2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_ep_btn2MouseClicked

    private void ep_btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ep_btn2ActionPerformed
        // TODO add your handling code here:
        jPanel74.setVisible(true);
        jPanel60.setVisible(false);
    }//GEN-LAST:event_ep_btn2ActionPerformed

    private void ep_btn4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ep_btn4MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_ep_btn4MouseClicked

    private void ep_btn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ep_btn4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ep_btn4ActionPerformed

    private void ep_btn3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ep_btn3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_ep_btn3MouseClicked

    private void ep_btn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ep_btn3ActionPerformed
        // TODO add your handling code here:
         jPanel74.setVisible(false);
        jPanel60.setVisible(true);
    }//GEN-LAST:event_ep_btn3ActionPerformed

    private void jButton113ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton113ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton113.getText();
        jPanel59.setVisible(false);
        jPanel60.setVisible(true);
        Rectangle r=jPanel59.getBounds();
        jPanel60.setBounds(r.x, r.y, r.width, r.height);
            jPanel74.setBounds(r.x, r.y, r.width, r.height);
            episode(5);
    }//GEN-LAST:event_jButton113ActionPerformed

    private void jButton114ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton114ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton114.getText();
        jPanel59.setVisible(false);
        jPanel60.setVisible(true);
        Rectangle r=jPanel59.getBounds();
        jPanel60.setBounds(r.x, r.y, r.width, r.height);
            jPanel74.setBounds(r.x, r.y, r.width, r.height);
            episode(6);
    }//GEN-LAST:event_jButton114ActionPerformed

    private void jButton115ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton115ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton115.getText();
        jPanel59.setVisible(false);
        jPanel60.setVisible(true);
        Rectangle r=jPanel59.getBounds();
        jPanel60.setBounds(r.x, r.y, r.width, r.height);
            jPanel74.setBounds(r.x, r.y, r.width, r.height);
            episode(7);
    }//GEN-LAST:event_jButton115ActionPerformed

    private void jButton116ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton116ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton116.getText();
        jPanel59.setVisible(false);
        jPanel60.setVisible(true);
        Rectangle r=jPanel59.getBounds();
        jPanel60.setBounds(r.x, r.y, r.width, r.height);
            jPanel74.setBounds(r.x, r.y, r.width, r.height);
            episode(8);
    }//GEN-LAST:event_jButton116ActionPerformed

    private void jButton117ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton117ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton117.getText();
        jPanel59.setVisible(false);
        jPanel60.setVisible(true);
        Rectangle r=jPanel59.getBounds();
        jPanel60.setBounds(r.x, r.y, r.width, r.height);
            jPanel74.setBounds(r.x, r.y, r.width, r.height);
            episode(9);
    }//GEN-LAST:event_jButton117ActionPerformed

    private void jButton172MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton172MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton172MouseClicked

    private void jButton173ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton173ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton173ActionPerformed

    private void jButton174ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton174ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton174ActionPerformed

    private void jButton175ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton175ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton175ActionPerformed

    private void jButton176ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton176ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton176ActionPerformed

    private void jButton177ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton177ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton177ActionPerformed
public void show_recom(String string)
{
        JButton [] btn=new JButton[1000];
        btn[0]=jButton178;
        btn[1]=jButton179;
        btn[2]=jButton180;
        btn[3]=jButton181;
        btn[4]=jButton182;
        //btn[5]=jButton60;
   
    String gen="";
    int ui=0,r=0;
    int g=0;
    int k=0;
    String [] rt1=new String[100];
    String [] tr1=new String [100];
    int mx=0;
    String lang1="";
    int z=0,pi=0,highest=0;
    try
    {
            String sql="select * from tv_shows where show_name = '"+string+"' " ;
            ResultSet res=stmt.executeQuery(sql);
          
            if(res.next())
            {
                 gen=res.getString("genre");
                   lang1=res.getString("lang");
                 System.out.println(gen);
            }
            res.close();
              String sql_1="SELECT *, ROW_NUMBER() OVER(order by rating desc,show_name) AS Row_Number FROM tv_shows where genre='"+gen+"' and show_name like \"%1\" ";
                ResultSet set1=stmt.executeQuery(sql_1);
                while(set1.next())
                {
                    rt1[mx]=set1.getString("show_name");
                    tr1[mx]=set1.getString("Row_Number");
                    mx++;
                }
                   set1.close();
            for(int y=0;y<5;y++)
            { 
               String check=btn[y].getText();
               for(int s=0;s<mx;s++)
               {
                   if(check.equals(rt1[s]))
                   {
                       if(highest<Integer.parseInt(tr1[s]))
                       {
                            highest=Integer.parseInt(tr1[s]);
                       }
                    }
               }
              
            }
            System.out.println(highest+"----->highest");
           int highest_1=highest;
            sql="select * from tv_shows where genre= '"+gen+"' and show_name like '%1' order by rating desc";
            ResultSet res3=stmt.executeQuery(sql);
        
           int t=0;
           String [] trash=new String [100];
                while(res3.next())
                {
                   trash[t]=res3.getString("show_name");
                   System.out.println(trash[t]);
                   t++;
                }
                res3.close();
                  
            
                int u=0;
                String [] rt=new String[1000];
                for(u=0;u<5;u++)
                {
                    rt[u]=btn[u].getText();
                }
                   
                                for(int q=0;q<t;q++)
                {
                        String mov=btn[k].getText();
                      
                            String sql1="select * from tv_shows where show_name='"+mov+"' ";
                            ResultSet res2=stmt.executeQuery(sql1);
                      
                        
                        
                        if(res2.next())
                        {
                        if(gen.equals(res2.getString("genre")))
                        {
                            for(u=0;u<highest;u++)
                            {
                                if(btn[k].getText().equals(trash[u]))
                                {
                                    break;
                                }
                                
                            }
                            if(u==highest)
                            {
                                             System.out.println("mg");
                            }
                            else
                            {
                                if(string.equals(btn[k].getText()))
                                {
                                    if(!string.equals(trash[highest]))
                                    {   
                                               if(highest<t)
                                               {
                                                        String po=trash[highest];
                                                        String po1[]=po.split(" [0-9]$");
                                                        String loc="C://Users//dines//Desktop//se7en//originals//";
                                                        loc=loc+po1[0]+".png";
                                                        btn[k].setIcon(new ImageIcon(loc));
                                                        btn[k].setText(po);
                                                        z++;
                                                        highest++;
                                               }
                                    
                                    else
                                    {
                                                for( r=0;r<highest;r++)
                                                {
                                                    for( g=0;g<5;g++)
                                                    {
                                                    if(btn[g].getText().equals(trash[r]) )
                                                    {
                                                        break;
                                                    }
                                                    }
                                                    if(g==5)
                                                    {
                                                        if(!string.equals(trash[r]))
                                                        {
                                                                System.out.println("gh");
                                                                String po=trash[r];
                                                                String po1[]=po.split(" [0-9]$");
                                                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                                                loc=loc+po1[0]+".png";
                                                                btn[k].setIcon(new ImageIcon(loc));
                                                                btn[k].setText(po);
                                                                z++;
                                                                // zin++;
                                                                // highest++;
                                                                break;

                                                        }

                                                    }
                                                }
                                    }
                                }
                                    else
                                    {
                                                      for( r=0;r<highest;r++)
                                                {
                                                    for( g=0;g<5;g++)
                                                    {
                                                    if(btn[g].getText().equals(trash[r]) )
                                                    {
                                                        break;
                                                    }
                                                    }
                                                    if(g==5)
                                                    {
                                                        if(!string.equals(trash[r]))
                                                        {
                                                                System.out.println("gh");
                                                                String po=trash[r];
                                                                String po1[]=po.split(" [0-9]$");
                                                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                                                loc=loc+po1[0]+".png";
                                                                btn[k].setIcon(new ImageIcon(loc));
                                                                btn[k].setText(po);
                                                                z++;
                                                                // zin++;
                                                                // highest++;
                                                                break;

                                                        }
                                                        else
                                                        {
                                                            if(r==highest)
                                                            {
                                                                z++;
                                                            }
                                                        }

                                                    }
                                                }
                                        
                                    }
                                }
                            }
                               
                        }
                        else
                        {
                           int zin=0;
                           
                                for( r=0;r<highest;r++)
                                {
                                    for( g=0;g<5;g++)
                                    {
                                    if(btn[g].getText().equals(trash[r]) )
                                    {
                                        break;
                                    }
                                    }
                                    if(g==5)
                                    {
                                        if(!string.equals(trash[r]))
                                        {
                                                System.out.println("gh");
                                                String po=trash[r];
                                                String po1[]=po.split(" [0-9]$");
                                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                                loc=loc+po1[0]+".png";
                                                btn[k].setIcon(new ImageIcon(loc));
                                                btn[k].setText(po);
                                                z++;
                                                 zin++;
                                                // highest++;
                                                break;
                                                
                                    }
                                               
                                    }
                                }
                                    if(zin==0)
                                    {
                                        if(!string.equals(trash[highest]))
                                        {
                                                System.out.println("g23h");
                                                String po=trash[highest];
                                                String po1[]=po.split(" [0-9]$");
                                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                                loc=loc+po1[0]+".png";
                                                btn[k].setIcon(new ImageIcon(loc));
                                                btn[k].setText(po);
                                                z++;
                                                highest++;
                                               // break;
                                        }
                                        else
                                        {
                                             System.out.println("g233h");
                                             highest++;
                                                String po=trash[highest];
                                                String po1[]=po.split(" [0-9]$");
                                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                                loc=loc+po1[0]+".png";
                                                btn[k].setIcon(new ImageIcon(loc));
                                                btn[k].setText(po);
                                                z++;
                                                highest++;
                                        }
                                    }
}
                         System.out.println("hi");
                       if(z%2==1&&z!=0)
                        {
                            break;
                        }
                        }
                        
               k++;
               if(k<4)
               {
                   jPanel78.setVisible(true);
                 //  jPanel77.setVisible(true);
                   int c=0,x=0;
                   JButton [] btn7 =new JButton[100];
                   btn7[0]=jButton183;
                   btn7[1]=jButton184;
                   btn7[2]=jButton185;
                   btn7[3]=jButton186;
                   btn7[4]=jButton187;
                
                   String sql7="select * from tv_shows where lang='"+lang1+"' and genre <>'"+gen+"' and show_name like '%1' order by rating desc";
                   ResultSet res7=stmt.executeQuery(sql7);
                   while(res7.next())
                   {
                       String china=res7.getString("show_name");
                       for(x=0;x<5;x++)
                       {
                           if(btn[x].getText().equals(china))
                           {
                               break;
                           }
                       }
                       if(x==5)
                       {
                                                String china1[]=china.split(" [0-9]$");
                                                String loc="C://Users//dines//Desktop//se7en//originals//";
                                                loc=loc+china+".png";
                                                btn7[c].setIcon(new ImageIcon(loc));
                                                btn7[c].setText(china1[0]);
                                                 c++;
                       }
                       
                       if(c>=5)
                       {
                           break;
                       }
                   }
                  // break;
               }
                else
               {
                   break;
               }
               res2.close();
              
                }
               
                    
            
    }
    catch(Exception ex)
    {
         JOptionPane.showMessageDialog(this,ex);
         ex.printStackTrace();
    }
}
    private void jButton118ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton118ActionPerformed
        // TODO add your handling code here:
        
       
        dhoni=dhoni+"_"+jButton118.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton118ActionPerformed

    private void recomshow_btn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_recomshow_btn1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_recomshow_btn1MouseClicked

    private void recomshow_btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_recomshow_btn1ActionPerformed
        // TODO add your handling code here:
         jPanel77.setVisible(false);
        recom_show.removeAll();
        recom_show.repaint();
        recom_show.revalidate();

        recom_show.add(jPanel76);
        recom_show.repaint();
        recom_show.revalidate();
        recomshow_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));
        recomshow_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));
        
    }//GEN-LAST:event_recomshow_btn1ActionPerformed

    private void recomshow_btn2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_recomshow_btn2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_recomshow_btn2MouseClicked

    private void recomshow_btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_recomshow_btn2ActionPerformed
        // TODO add your handling code here:
          recom_show.removeAll();
        recom_show.repaint();
        recom_show.revalidate();

        recom_show.add(jPanel77);
        recom_show.repaint();
        recom_show.revalidate();
        recomshow_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));
        recomshow_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));
         jPanel76.setVisible(false);
    }//GEN-LAST:event_recomshow_btn2ActionPerformed

    private void jPanel78MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel78MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel78MouseExited

    private void jButton37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton37ActionPerformed
        // TODO add your handling code here:
        if(search_flag==0)
        {
            jPanel40.removeAll();
            jPanel40.repaint();
            jPanel40.revalidate();

            jPanel40.add(jPanel3);
            jPanel40.repaint();
            jPanel40.revalidate();
            jButton37.setVisible(false);
            jPanel38.setVisible(false);
        }
        else
        {
            jPanel40.removeAll();
            jPanel40.repaint();
            jPanel40.revalidate();

            jPanel40.add(jPanel58);
            jPanel40.repaint();
            jPanel40.revalidate();
            jButton37.setVisible(false);
            jPanel38.setVisible(false);
        }
        
    }//GEN-LAST:event_jButton37ActionPerformed

    private void search_add_listMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_search_add_listMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_search_add_listMouseEntered

    private void search_wtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_wtActionPerformed
        // TODO add your handling code here:
        String html=movie+".html";
        try {
            Desktop.getDesktop().open(new File(html));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
        //  jPanel9.setVisible(false);
        jPanel41.setVisible(false);
    }//GEN-LAST:event_search_wtActionPerformed

    private void jButton55ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton55ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton55.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton55.getText();
    }//GEN-LAST:event_jButton55ActionPerformed

    private void jButton54ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton54ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton54.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton54.getText();
    }//GEN-LAST:event_jButton54ActionPerformed

    private void jButton53ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton53ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton53.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton53.getText();
    }//GEN-LAST:event_jButton53ActionPerformed

    private void jButton52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton52ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton52.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton52.getText();
    }//GEN-LAST:event_jButton52ActionPerformed

    private void jButton51ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton51ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton51.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton51.getText();
    }//GEN-LAST:event_jButton51ActionPerformed

    private void jButton50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton50ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton50.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton50.getText();
    }//GEN-LAST:event_jButton50ActionPerformed

    private void jButton49ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton49ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton49.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton49.getText();
    }//GEN-LAST:event_jButton49ActionPerformed

    private void jButton48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton48ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton48.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton48.getText();
    }//GEN-LAST:event_jButton48ActionPerformed

    private void jButton47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton47ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton47.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton47.getText();
    }//GEN-LAST:event_jButton47ActionPerformed

    private void jButton46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton46ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton46.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton46.getText();
    }//GEN-LAST:event_jButton46ActionPerformed

    private void jButton45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton45ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton45.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton45.getText();
    }//GEN-LAST:event_jButton45ActionPerformed

    private void jButton44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton44ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton44.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton44.getText();
    }//GEN-LAST:event_jButton44ActionPerformed

    private void jButton43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton43ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton43.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton43.getText();
    }//GEN-LAST:event_jButton43ActionPerformed

    private void jButton42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton42ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton42.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton42.getText();
    }//GEN-LAST:event_jButton42ActionPerformed

    private void jButton41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton41ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton41.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton41.getText();
    }//GEN-LAST:event_jButton41ActionPerformed

    private void jButton39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton39ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton39.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton39.getText();
    }//GEN-LAST:event_jButton39ActionPerformed

    private void jButton38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton38ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton38.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton38.getText();
    }//GEN-LAST:event_jButton38ActionPerformed

    private void jButton36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton36ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton36.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton36.getText();
    }//GEN-LAST:event_jButton36ActionPerformed

    private void jButton35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton35ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton35.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton35.getText();
    }//GEN-LAST:event_jButton35ActionPerformed

    private void jButton30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton30ActionPerformed
        // TODO add your handling code here:
        jPanel41.setVisible(true);
        //jButton30.getText();
        Rectangle hi= jButton30.getBounds();
        int x1=hi.x+hi.width;
        jPanel41.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton30.getText();
    }//GEN-LAST:event_jButton30ActionPerformed

    private void jPanel45MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel45MouseExited
        // TODO add your handling code here:
//        jPanel51.setVisible(false);
    }//GEN-LAST:event_jPanel45MouseExited

    private void jButton77ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton77ActionPerformed
        // TODO add your handling code here:
    //    jPanel51.setVisible(true);
        //jButton30.getText();
        jPanel30.setVisible(true);
      Rectangle jig1=horror_panel.getBounds(shift);
      Rectangle jig=jButton77.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
   //     jPanel51.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton77.getText();
    }//GEN-LAST:event_jButton77ActionPerformed

    private void jButton76ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton76ActionPerformed
        // TODO add your handling code here:
 //       jPanel51.setVisible(true);
        //jButton30.getText();
        jPanel30.setVisible(true);
      Rectangle jig1=horror_panel.getBounds(shift);
      Rectangle jig=jButton76.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
  //      jPanel51.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton76.getText();
    }//GEN-LAST:event_jButton76ActionPerformed

    private void jButton75ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton75ActionPerformed
        // TODO add your handling code here:
   //     jPanel51.setVisible(true);
        //jButton30.getText();
        jPanel30.setVisible(true);
      Rectangle jig1=horror_panel.getBounds(shift);
      Rectangle jig=jButton75.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
   //     jPanel51.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton75.getText();
    }//GEN-LAST:event_jButton75ActionPerformed

    private void jButton74ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton74ActionPerformed
        // TODO add your handling code here:
  //      jPanel51.setVisible(true);
        //jButton30.getText();
       jPanel30.setVisible(true);
      Rectangle jig1=horror_panel.getBounds(shift);
      Rectangle jig=jButton74.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
   //     jPanel51.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton74.getText();
    }//GEN-LAST:event_jButton74ActionPerformed

    private void jButton73ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton73ActionPerformed
        // TODO add your handling code here:
    //    jPanel51.setVisible(true);
        //jButton30.getText();
        jPanel30.setVisible(true);
      Rectangle jig1=horror_panel.getBounds(shift);
      Rectangle jig=jButton73.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
  //      jPanel51.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton73.getText();
    }//GEN-LAST:event_jButton73ActionPerformed

    private void jButton86ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton86ActionPerformed
        // TODO add your handling code here:
     //   jPanel53.setVisible(true);
        //jButton30.getText();
      jPanel30.setVisible(true);
      Rectangle jig1=scifi_panel.getBounds(shift);
      Rectangle jig=jButton86.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    //    jPanel53.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton86.getText();
    }//GEN-LAST:event_jButton86ActionPerformed

    private void jButton85ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton85ActionPerformed
        // TODO add your handling code here:
     //   jPanel53.setVisible(true);
        //jButton30.getText();
       jPanel30.setVisible(true);
      Rectangle jig1=scifi_panel.getBounds(shift);
      Rectangle jig=jButton85.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    //    jPanel53.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton85.getText();
    }//GEN-LAST:event_jButton85ActionPerformed

    private void jButton83ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton83ActionPerformed
        // TODO add your handling code here:
     //   jPanel50.setVisible(true);
        //jButton30.getText();
       jPanel30.setVisible(true);
      Rectangle jig1=scifi_panel.getBounds(shift);
      Rectangle jig=jButton83.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
     //   jPanel50.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton83.getText();
    }//GEN-LAST:event_jButton83ActionPerformed

    private void jButton82ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton82ActionPerformed
        // TODO add your handling code here:
      //  jPanel50.setVisible(true);
        //jButton30.getText();
       jPanel30.setVisible(true);
      Rectangle jig1=scifi_panel.getBounds(shift);
      Rectangle jig=jButton82.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
     //   jPanel50.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton82.getText();
    }//GEN-LAST:event_jButton82ActionPerformed

    private void jButton81ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton81ActionPerformed
        // TODO add your handling code here:
     //   jPanel50.setVisible(true);
        //jButton30.getText();
       jPanel30.setVisible(true);
      Rectangle jig1=scifi_panel.getBounds(shift);
      Rectangle jig=jButton81.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    //    jPanel50.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton81.getText();
    }//GEN-LAST:event_jButton81ActionPerformed

    private void jButton80ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton80ActionPerformed
        // TODO add your handling code here:
    //    jPanel50.setVisible(true);
        //jButton30.getText();
        jPanel30.setVisible(true);
      Rectangle jig1=scifi_panel.getBounds(shift);
      Rectangle jig=jButton80.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
     //   jPanel50.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton80.getText();
    }//GEN-LAST:event_jButton80ActionPerformed

    private void jButton79ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton79ActionPerformed
        // TODO add your handling code here:
     //   jPanel50.setVisible(true);
        //jButton30.getText();
     jPanel30.setVisible(true);
      Rectangle jig1=scifi_panel.getBounds(shift);
      Rectangle jig=jButton79.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
     //   jPanel50.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton79.getText();

    }//GEN-LAST:event_jButton79ActionPerformed

    private void jPanel42MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel42MouseExited
        // TODO add your handling code here:
     //   jPanel49.setVisible(false);
    }//GEN-LAST:event_jPanel42MouseExited

    private void drama_btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drama_btn2ActionPerformed
        // TODO add your handling code here:

     //   jPanel49.setVisible(false);
        jPanel44.setVisible(true);
        drama_panel.removeAll();
        drama_panel.repaint();
        drama_panel.revalidate();

        drama_panel.add(jPanel44);
        drama_panel.repaint();
        drama_panel.revalidate();
        drama_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));
        drama_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));
    }//GEN-LAST:event_drama_btn2ActionPerformed

    private void drama_btn2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_drama_btn2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_drama_btn2MouseClicked

    private void drama_btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drama_btn1ActionPerformed
        // TODO add your handling code here:
    //    jPanel52.setVisible(false);
        //     jPanel49.setVisible(true);
        jPanel44.setVisible(false);
        drama_panel.removeAll();
        drama_panel.repaint();
        drama_panel.revalidate();

        drama_panel.add(jPanel47);
        drama_panel.repaint();
        drama_panel.revalidate();
        drama_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));
        drama_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));
    }//GEN-LAST:event_drama_btn1ActionPerformed

    private void drama_btn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_drama_btn1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_drama_btn1MouseClicked

    private void jPanel48MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel48MouseExited
        // TODO add your handling code here:
    //    jPanel50.setVisible(false);
    }//GEN-LAST:event_jPanel48MouseExited

    private void scifi_btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scifi_btn2ActionPerformed
        // TODO add your handling code here:
     //   jPanel50.setVisible(false);
        jPanel43.setVisible(true);
        scifi_panel.removeAll();
        scifi_panel.repaint();
        scifi_panel.revalidate();

        scifi_panel.add(jPanel43);
        scifi_panel.repaint();
        scifi_panel.revalidate();
        scifi_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));
        scifi_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));

    }//GEN-LAST:event_scifi_btn2ActionPerformed

    private void scifi_btn2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_scifi_btn2MouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_scifi_btn2MouseClicked

    private void scifi_btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scifi_btn1ActionPerformed
        // TODO add your handling code here:
    //    jPanel53.setVisible(false);
        jPanel43.setVisible(false);
        scifi_panel.removeAll();
        scifi_panel.repaint();
        scifi_panel.revalidate();

        scifi_panel.add(jPanel46);
        scifi_panel.repaint();
        scifi_panel.revalidate();
        scifi_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));
        scifi_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));
    }//GEN-LAST:event_scifi_btn1ActionPerformed

    private void scifi_btn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_scifi_btn1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_scifi_btn1MouseClicked

    private void jButton97ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton97ActionPerformed
        // TODO add your handling code here:
    //    jPanel52.setVisible(true);
        //jButton30.getText();
      jPanel30.setVisible(true);
      Rectangle jig1=drama_panel.getBounds(shift);
      Rectangle jig=jButton97.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
   //     jPanel52.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton97.getText();
    }//GEN-LAST:event_jButton97ActionPerformed

    private void jButton95ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton95ActionPerformed
        // TODO add your handling code here:
    //    jPanel49.setVisible(true);
        //jButton30.getText();
      jPanel30.setVisible(true);
      Rectangle jig1=drama_panel.getBounds(shift);
      Rectangle jig=jButton95.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    //    jPanel49.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton95.getText();
    }//GEN-LAST:event_jButton95ActionPerformed

    private void jButton94ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton94ActionPerformed
        // TODO add your handling code here:
    //    jPanel49.setVisible(true);
        //jButton30.getText();
       jPanel30.setVisible(true);
      Rectangle jig1=drama_panel.getBounds(shift);
      Rectangle jig=jButton94.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
   //     jPanel49.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton94.getText();
    }//GEN-LAST:event_jButton94ActionPerformed

    private void jButton93ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton93ActionPerformed
        // TODO add your handling code here:
    //    jPanel49.setVisible(true);
        //jButton30.getText();
       jPanel30.setVisible(true);
      Rectangle jig1=drama_panel.getBounds(shift);
      Rectangle jig=jButton93.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    //    jPanel49.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton93.getText();
    }//GEN-LAST:event_jButton93ActionPerformed

    private void jButton92ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton92ActionPerformed
        // TODO add your handling code here:
     //   jPanel49.setVisible(true);
        //jButton30.getText();
        jPanel30.setVisible(true);
      Rectangle jig1=drama_panel.getBounds(shift);
      Rectangle jig=jButton92.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    //    jPanel49.setBounds(x1, hi.y, hi.width, hi.height);
        movie=jButton92.getText();
    }//GEN-LAST:event_jButton92ActionPerformed

    private void jButton91ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton91ActionPerformed
        // TODO add your handling code here:
    
        movie=jButton91.getText();
        jPanel30.setVisible(true);
      Rectangle jig1=drama_panel.getBounds(shift);
      Rectangle jig=jButton19.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    }//GEN-LAST:event_jButton91ActionPerformed

    private void jButton25MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton25MouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_jButton25MouseClicked

    private void jButton31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton31ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton31ActionPerformed

    private void jButton32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton32ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton32ActionPerformed

    private void jButton33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton33ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton33ActionPerformed

    private void jButton34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton34ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton34ActionPerformed

    private void jButton61ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton61ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton61ActionPerformed

    private void jPanel39MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel39MouseExited
        // TODO add your handling code here:
    //    jPanel28.setVisible(false);
   //     jPanel29.setVisible(false);
        jPanel30.setVisible(false);
    //    jPanel31.setVisible(false);
    //    jPanel32.setVisible(false);
   //     jPanel34.setVisible(false);
     //   jPanel35.setVisible(false);
     //   jPanel36.setVisible(false);
    }//GEN-LAST:event_jPanel39MouseExited

    private void thriller_btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_thriller_btn2ActionPerformed
        // TODO add your handling code here:
        thriller_panel.removeAll();
        thriller_panel.repaint();
        thriller_panel.revalidate();

        thriller_panel.add(jPanel33);
        thriller_panel.repaint();
        thriller_panel.revalidate();
        thriller_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));
        thriller_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));
    }//GEN-LAST:event_thriller_btn2ActionPerformed

    private void thriller_btn2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_thriller_btn2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_thriller_btn2MouseClicked

    private void thriller_btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_thriller_btn1ActionPerformed
        // TODO add your handling code here:
        thriller_panel.removeAll();
        thriller_panel.repaint();
        thriller_panel.revalidate();

        thriller_panel.add(jPanel27);
        thriller_panel.repaint();
        thriller_panel.revalidate();
        thriller_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));
        thriller_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));
    }//GEN-LAST:event_thriller_btn1ActionPerformed

    private void thriller_btn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_thriller_btn1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_thriller_btn1MouseClicked

    private void sarkar4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sarkar4ActionPerformed
        // TODO add your handling code here:
        movie="seven";
        jPanel30.setVisible(true);
      Rectangle jig1=thriller_panel.getBounds(shift);
      Rectangle jig=sarkar4.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    //    jPanel34.setVisible(false);
    //    jPanel35.setVisible(false);
    //    jPanel36.setVisible(true);
    }//GEN-LAST:event_sarkar4ActionPerformed

    private void sarkar4MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar4MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar4MouseReleased

    private void sarkar4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar4MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar4MouseExited

    private void sarkar4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar4MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar4MouseEntered

    private void sarkar4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar4MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar4MouseClicked

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
        // TODO add your handling code here:
        movie="parasite";
        jPanel30.setVisible(true);
      Rectangle jig1=thriller_panel.getBounds(shift);
      Rectangle jig=jButton24.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    //    jPanel34.setVisible(false);
     //   jPanel35.setVisible(true);
     //   jPanel36.setVisible(false);
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jButton24MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton24MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton24MouseReleased

    private void jButton24MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton24MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton24MouseExited

    private void jButton24MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton24MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton24MouseEntered

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
        // TODO add your handling code here:
        movie="predestination";
        jPanel30.setVisible(true);
      Rectangle jig1=thriller_panel.getBounds(shift);
      Rectangle jig=jButton23.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
   //     jPanel34.setVisible(true);
   //     jPanel35.setVisible(false);
    //    jPanel36.setVisible(false);

    }//GEN-LAST:event_jButton23ActionPerformed

    private void jButton23MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton23MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton23MouseReleased

    private void jButton23MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton23MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton23MouseExited

    private void jButton23MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton23MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton23MouseEntered

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
        // TODO add your handling code here:
        movie="khaidi";
        jPanel30.setVisible(true);
      Rectangle jig1=thriller_panel.getBounds(shift);
      Rectangle jig=jButton22.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    //    jPanel28.setVisible(false);
    //    jPanel29.setVisible(false);
    //    jPanel30.setVisible(false);
    //    jPanel31.setVisible(false);
    //    jPanel32.setVisible(true);
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jButton22MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton22MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton22MouseReleased

    private void jButton22MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton22MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton22MouseExited

    private void jButton22MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton22MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton22MouseEntered

    private void jButton22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton22MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton22MouseClicked

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        // TODO add your handling code here:
        movie="manu";
        jPanel30.setVisible(true);
      Rectangle jig1=thriller_panel.getBounds(shift);
      Rectangle jig=jButton21.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
     //   jPanel28.setVisible(false);
     //   jPanel29.setVisible(false);
      //  jPanel30.setVisible(false);
     //   jPanel31.setVisible(true);
     //   jPanel32.setVisible(false);
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton21MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton21MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton21MouseReleased

    private void jButton21MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton21MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton21MouseExited

    private void jButton21MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton21MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton21MouseEntered

    private void jButton21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton21MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton21MouseClicked

    private void sarkar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sarkar3ActionPerformed
        // TODO add your handling code here:
        movie="lucy";
        jPanel30.setVisible(true);
      Rectangle jig1=thriller_panel.getBounds(shift);
      Rectangle jig=sarkar3.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    //    jPanel28.setVisible(false);
    //    jPanel29.setVisible(false);
    //    jPanel30.setVisible(true);
   //     jPanel31.setVisible(false);
    //    jPanel32.setVisible(false);
    }//GEN-LAST:event_sarkar3ActionPerformed

    private void sarkar3MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar3MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar3MouseReleased

    private void sarkar3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar3MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar3MouseExited

    private void sarkar3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar3MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar3MouseEntered

    private void sarkar3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar3MouseClicked

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
        // TODO add your handling code here:
        movie="mathu vadalara";
        jPanel30.setVisible(true);
      Rectangle jig1=thriller_panel.getBounds(shift);
      Rectangle jig=jButton20.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    //    jPanel28.setVisible(false);
     //   jPanel29.setVisible(true);
   //     jPanel30.setVisible(false);
   //     jPanel31.setVisible(false);
    //    jPanel32.setVisible(false);
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton20MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton20MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton20MouseReleased

    private void jButton20MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton20MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton20MouseExited

    private void jButton20MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton20MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton20MouseEntered

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
        // TODO add your handling code here:
        movie="agent sai srinivasa athreya";
         jPanel30.setVisible(true);
      Rectangle jig1=thriller_panel.getBounds(shift);
      Rectangle jig=jButton19.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
   //     jPanel28.setVisible(true);
   //     jPanel29.setVisible(false);
        
   //     jPanel31.setVisible(false);
    //    jPanel32.setVisible(false);
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton19MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton19MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton19MouseReleased

    private void jButton19MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton19MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton19MouseExited

    private void jButton19MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton19MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton19MouseEntered

    private void jPanel26MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel26MouseExited
        // TODO add your handling code here:

     

    }//GEN-LAST:event_jPanel26MouseExited

    private void action_btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_action_btn2ActionPerformed
        // TODO add your handling code here:
        action_panel.removeAll();
        action_panel.repaint();
        action_panel.revalidate();

        action_panel.add(jPanel21);
        action_panel.repaint();
        action_panel.revalidate();
        action_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));
        action_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));

      
    }//GEN-LAST:event_action_btn2ActionPerformed

    private void action_btn2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_action_btn2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_action_btn2MouseClicked

    private void action_btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_action_btn1ActionPerformed
        // TODO add your handling code here:
        action_panel.removeAll();
        action_panel.repaint();
        action_panel.revalidate();

        action_panel.add(jPanel5);
        action_panel.repaint();
        action_panel.revalidate();
        action_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));
        action_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));

       
    }//GEN-LAST:event_action_btn1ActionPerformed

    private void action_btn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_action_btn1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_action_btn1MouseClicked

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        // TODO add your handling code here:
        movie="uri the surgical strike";
         jPanel30.setVisible(true);
      Rectangle jig1=action_panel.getBounds(shift);
      Rectangle jig=jButton18.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
      
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton18MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton18MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton18MouseReleased

    private void jButton18MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton18MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton18MouseExited

    private void jButton18MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton18MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton18MouseEntered

    private void jButton18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton18MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton18MouseClicked

    private void sarkar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sarkar2ActionPerformed
        // TODO add your handling code here:
        movie="aravinda sametha veera raghava";
         jPanel30.setVisible(true);
      Rectangle jig1=action_panel.getBounds(shift);
      Rectangle jig=sarkar2.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
     
    }//GEN-LAST:event_sarkar2ActionPerformed

    private void sarkar2MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar2MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar2MouseReleased

    private void sarkar2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar2MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar2MouseExited

    private void sarkar2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar2MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar2MouseEntered

    private void sarkar2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar2MouseClicked

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        // TODO add your handling code here:
        movie="darbar";
    jPanel30.setVisible(true);
      Rectangle jig1=action_panel.getBounds(shift);
      Rectangle jig=jButton17.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton17MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton17MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton17MouseReleased

    private void jButton17MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton17MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton17MouseExited

    private void jButton17MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton17MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton17MouseEntered

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        // TODO add your handling code here:
        movie="sye raa narasimha reddy";
      jPanel30.setVisible(true);
      Rectangle jig1=action_panel.getBounds(shift);
      Rectangle jig=jButton16.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
        //jPanel313.setVisible(false);
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton16MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton16MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton16MouseReleased

    private void jButton16MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton16MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton16MouseExited

    private void jButton16MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton16MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton16MouseEntered

    private void jPanel5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel5MouseExited
        // TODO add your handling code here:

    }//GEN-LAST:event_jPanel5MouseExited

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        // TODO add your handling code here:
        movie="chanakya";
        jPanel30.setVisible(true);
      Rectangle jig1=action_panel.getBounds(shift);
      Rectangle jig=jButton15.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton15MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton15MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton15MouseReleased

    private void jButton15MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton15MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton15MouseExited

    private void jButton15MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton15MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton15MouseEntered

    private void jButton15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton15MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton15MouseClicked

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        // TODO add your handling code here:
        movie="ala vaikuntapuram lo";
         jPanel30.setVisible(true);
      Rectangle jig1=action_panel.getBounds(shift);
      Rectangle jig=jButton14.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton14MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton14MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton14MouseReleased

    private void jButton14MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton14MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton14MouseExited

    private void jButton14MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton14MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton14MouseEntered

    private void jButton14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton14MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton14MouseClicked

    private void sarkar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sarkar1ActionPerformed
        // TODO add your handling code here:
        movie="kgf";
         jPanel30.setVisible(true);
      Rectangle jig1=action_panel.getBounds(shift);
      Rectangle jig=sarkar1.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    
    }//GEN-LAST:event_sarkar1ActionPerformed

    private void sarkar1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar1MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar1MouseReleased

    private void sarkar1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar1MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar1MouseExited

    private void sarkar1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar1MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar1MouseEntered

    private void sarkar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar1MouseClicked

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        movie="saaho";
       jPanel30.setVisible(true);
      Rectangle jig1=action_panel.getBounds(shift);
      Rectangle jig=jButton8.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton8MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8MouseReleased

    private void jButton8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8MouseExited

    private void jButton8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8MouseEntered

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        // TODO add your handling code here:
     movie="sarkar";
      jPanel30.setVisible(true);
      Rectangle jig1=action_panel.getBounds(shift);
      Rectangle jig=jButton13.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);

    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton13MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton13MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton13MouseReleased

    private void jButton13MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton13MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton13MouseExited

    private void jButton13MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton13MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton13MouseEntered

    private void jPanel8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel8MouseExited
        // TODO add your handling code here:
      

    }//GEN-LAST:event_jPanel8MouseExited

    private void rom_com_btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rom_com_btn2ActionPerformed
        // TODO add your handling code here:
        rom_com_panel.removeAll();
        rom_com_panel.repaint();
        rom_com_panel.revalidate();

        rom_com_panel.add(jPanel7);
        rom_com_panel.repaint();
        rom_com_panel.revalidate();
        rom_com_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));
        rom_com_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));

   
    }//GEN-LAST:event_rom_com_btn2ActionPerformed

    private void rom_com_btn2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rom_com_btn2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rom_com_btn2MouseClicked

    private void rom_com_btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rom_com_btn1ActionPerformed
        // TODO add your handling code here:
        rom_com_panel.removeAll();
        rom_com_panel.repaint();
        rom_com_panel.revalidate();

        rom_com_panel.add(jPanel6);
        rom_com_panel.repaint();
        rom_com_panel.revalidate();
        rom_com_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));
        rom_com_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));
      //  jPanel14.setVisible(false);
    }//GEN-LAST:event_rom_com_btn1ActionPerformed

    private void rom_com_btn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rom_com_btn1MouseClicked
        // TODO add your handling code here:
        //    rom_com_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));
        //  rom_com_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));
    }//GEN-LAST:event_rom_com_btn1MouseClicked

    private void jPanel54MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel54MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel54MouseExited

    private void recom_btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_recom_btn2ActionPerformed
        // TODO add your handling code here:
        jPanel55.setVisible(true);
        recom_panel.removeAll();
        recom_panel.repaint();
        recom_panel.revalidate();

        recom_panel.add(jPanel55);
        recom_panel.repaint();
        recom_panel.revalidate();
        recom_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));
        recom_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));
        jPanel4.setVisible(false);
    }//GEN-LAST:event_recom_btn2ActionPerformed

    private void recom_btn2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_recom_btn2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_recom_btn2MouseClicked

    private void recom_btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_recom_btn1ActionPerformed
        // TODO add your handling code here:
        jPanel4.setVisible(true);
        recom_panel.removeAll();
        recom_panel.repaint();
        recom_panel.revalidate();

        recom_panel.add(jPanel4);
        recom_panel.repaint();
        recom_panel.revalidate();
        recom_btn2.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16 (1).png"));
        recom_btn1.setIcon(new ImageIcon("C://Users//dines//Desktop//se7en//se7en images//icons8-filled-circle-16.png"));
        jPanel55.setVisible(false);
    }//GEN-LAST:event_recom_btn1ActionPerformed

    private void recom_btn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_recom_btn1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_recom_btn1MouseClicked

    private void jPanel7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel7MouseExited
        // TODO add your handling code here:
        //  jPanel14.setVisible(false);
    }//GEN-LAST:event_jPanel7MouseExited

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
        movie="hello guru prema kosame";
         jPanel30.setVisible(true);
      Rectangle jig1=rom_com_panel.getBounds(shift);
      Rectangle jig=jButton12.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    //    jPanel14.setVisible(true);
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton12MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton12MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton12MouseReleased

    private void jButton12MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton12MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton12MouseExited

    private void jButton12MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton12MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton12MouseEntered

    private void jButton67ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton67ActionPerformed
        // TODO add your handling code here:
        String html=jButton67.getText()+".html";
        try {
            Desktop.getDesktop().open(new File(html));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton67ActionPerformed

    private void jButton67MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton67MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton67MouseReleased

    private void jButton67MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton67MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton67MouseExited

    private void jButton67MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton67MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton67MouseEntered

    private void jButton66ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton66ActionPerformed
        // TODO add your handling code here:
        String html=jButton66.getText()+".html";
        try {
            Desktop.getDesktop().open(new File(html));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton66ActionPerformed

    private void jButton66MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton66MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton66MouseReleased

    private void jButton66MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton66MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton66MouseExited

    private void jButton66MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton66MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton66MouseEntered

    private void jButton65ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton65ActionPerformed
        // TODO add your handling code here:
        String html=jButton65.getText()+".html";
        try {
            Desktop.getDesktop().open(new File(html));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton65ActionPerformed

    private void jButton65MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton65MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton65MouseReleased

    private void jButton65MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton65MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton65MouseExited

    private void jButton65MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton65MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton65MouseEntered

    private void jButton64ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton64ActionPerformed
        // TODO add your handling code here:
        String html=jButton64.getText()+".html";
        try {
            Desktop.getDesktop().open(new File(html));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton64ActionPerformed

    private void jButton64MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton64MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton64MouseReleased

    private void jButton64MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton64MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton64MouseExited

    private void jButton64MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton64MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton64MouseEntered

    private void jButton63ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton63ActionPerformed
        // TODO add your handling code here:
        String html=jButton63.getText()+".html";
        try {
            Desktop.getDesktop().open(new File(html));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton63ActionPerformed

    private void jButton63MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton63MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton63MouseReleased

    private void jButton63MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton63MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton63MouseExited

    private void jButton63MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton63MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton63MouseEntered

    private void jButton62ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton62ActionPerformed
        // TODO add your handling code here:
        String html=jButton62.getText()+".html";
        try {
            Desktop.getDesktop().open(new File(html));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton62ActionPerformed

    private void jButton62MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton62MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton62MouseReleased

    private void jButton62MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton62MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton62MouseExited

    private void jButton62MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton62MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton62MouseEntered

    private void jButton60ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton60ActionPerformed
        // TODO add your handling code here:
        String html=jButton60.getText()+".html";
        try {
            Desktop.getDesktop().open(new File(html));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
        //  jPanel9.setVisible(false);

    }//GEN-LAST:event_jButton60ActionPerformed

    private void jButton60MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton60MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton60MouseReleased

    private void jButton60MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton60MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton60MouseExited

    private void jButton60MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton60MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton60MouseEntered

    private void jButton59ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton59ActionPerformed
        // TODO add your handling code here:
        String html=jButton59.getText()+".html";
        try {
            Desktop.getDesktop().open(new File(html));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
        //  jPanel9.setVisible(false);

    }//GEN-LAST:event_jButton59ActionPerformed

    private void jButton59MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton59MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton59MouseReleased

    private void jButton59MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton59MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton59MouseExited

    private void jButton59MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton59MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton59MouseEntered

    private void jButton58ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton58ActionPerformed
        // TODO add your handling code here:
        String html=jButton58.getText()+".html";
        try {
            Desktop.getDesktop().open(new File(html));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
        //  jPanel9.setVisible(false);

    }//GEN-LAST:event_jButton58ActionPerformed

    private void jButton58MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton58MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton58MouseReleased

    private void jButton58MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton58MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton58MouseExited

    private void jButton58MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton58MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton58MouseEntered

    private void jButton57ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton57ActionPerformed
        // TODO add your handling code here:
        String html=jButton57.getText()+".html";
        try {
            Desktop.getDesktop().open(new File(html));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
        //  jPanel9.setVisible(false);

    }//GEN-LAST:event_jButton57ActionPerformed

    private void jButton57MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton57MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton57MouseReleased

    private void jButton57MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton57MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton57MouseExited

    private void jButton57MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton57MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton57MouseEntered

    private void jButton56ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton56ActionPerformed
        // TODO add your handling code here:
        String html=jButton56.getText()+".html";
        try {
            Desktop.getDesktop().open(new File(html));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
        //  jPanel9.setVisible(false);

    }//GEN-LAST:event_jButton56ActionPerformed

    private void jButton56MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton56MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton56MouseReleased

    private void jButton56MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton56MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton56MouseExited

    private void jButton56MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton56MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton56MouseEntered

    private void jButton40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton40ActionPerformed
        // TODO add your handling code here:
        String html=jButton40.getText()+".html";
        try {
            Desktop.getDesktop().open(new File(html));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
        //  jPanel9.setVisible(false);

    }//GEN-LAST:event_jButton40ActionPerformed

    private void jButton40MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton40MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton40MouseReleased

    private void jButton40MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton40MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton40MouseExited

    private void jButton40MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton40MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton40MouseEntered

    private void jButton105ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton105ActionPerformed
 check(jButton105.getText(),jButton105.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton105ActionPerformed

    private void jButton104ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton104ActionPerformed
 check(jButton104.getText(),jButton104.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton104ActionPerformed

    private void jButton103ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton103ActionPerformed
 check(jButton103.getText(),jButton103.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton103ActionPerformed

    private void jButton102ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton102ActionPerformed
 check(jButton102.getText(),jButton102.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton102ActionPerformed

    private void jButton101ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton101ActionPerformed
 check(jButton101.getText(),jButton101.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton101ActionPerformed

    private void jButton100ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton100ActionPerformed
 check(jButton100.getText(),jButton100.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton100ActionPerformed

    private void jButton99ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton99ActionPerformed
 check(jButton99.getText(),jButton99.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton99ActionPerformed

    private void jButton98ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton98ActionPerformed
 check(jButton98.getText(),jButton98.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton98ActionPerformed

    private void jButton96ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton96ActionPerformed
 check(jButton96.getText(),jButton96.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton96ActionPerformed

    private void jButton90ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton90ActionPerformed
 check(jButton90.getText(),jButton90.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton90ActionPerformed

    private void jButton89ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton89ActionPerformed
 check(jButton89.getText(),jButton89.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton89ActionPerformed

    private void jButton88ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton88ActionPerformed
 check(jButton88.getText(),jButton88.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton88ActionPerformed

    private void jButton87ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton87ActionPerformed
 check(jButton87.getText(),jButton87.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton87ActionPerformed

    private void jButton84ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton84ActionPerformed
 check(jButton84.getText(),jButton84.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton84ActionPerformed

    private void jButton78ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton78ActionPerformed
 check(jButton78.getText(),jButton78.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton78ActionPerformed

    private void jButton72ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton72ActionPerformed
 check(jButton72.getText(),jButton72.getBounds());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton72ActionPerformed

    private void jButton71ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton71ActionPerformed
        // TODO add your handling code here:
        check(jButton71.getText(),jButton71.getBounds());
    }//GEN-LAST:event_jButton71ActionPerformed

    private void jButton70ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton70ActionPerformed
        // TODO add your handling code here:
         check(jButton70.getText(),jButton70.getBounds());
    }//GEN-LAST:event_jButton70ActionPerformed

    private void jButton69ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton69ActionPerformed
        // TODO add your handling code here:
         check(jButton69.getText(),jButton69.getBounds());
    }//GEN-LAST:event_jButton69ActionPerformed
public void check(String kim,Rectangle r)
{
  // jPanel75.setVisible(false);
   jPanel79.setVisible(false);
    if(dev>0)
    {
            JButton [] btnx1=new JButton[100];
         btnx1[0]=jButton68;
        btnx1[1]=jButton69;
        btnx1[2]=jButton70;
        btnx1[3]=jButton71;
        btnx1[4]=jButton72;
        btnx1[5]=jButton78;
        btnx1[6]=jButton84;
        btnx1[7]=jButton87;
        btnx1[8]=jButton88;
        btnx1[9]=jButton89;
        btnx1[10]=jButton90;
        btnx1[11]=jButton96;
        btnx1[12]=jButton98;
        btnx1[13]=jButton99;
        btnx1[14]=jButton100;
        btnx1[15]=jButton101;
        btnx1[16]=jButton102;
        btnx1[17]=jButton103;
        btnx1[18]=jButton104;
        btnx1[19]=jButton105;
        for(int ui=0;ui<20;ui++)
        {
            if(btnx1[ui].getBounds().equals(shift))
            {
                btnx1[ui].setBounds(shift.x, shift.y-68, 330, 190);
            }
        }
         
    }
    jPanel80.setVisible(false);
    jPanel81.setVisible(false);
    jPanel82.setVisible(false);
    try
    {
        
        String sql="select type from my_list where flick='"+kim+"'";
        
        ResultSet res=stmt.executeQuery(sql);
        if(res.next())
        {
        if(res.getString("type").equals("movie"))
        {
          //  jPanel75.setVisible(true);
            watch_movie=kim;
            watch_show="";
                  try {
            Desktop.getDesktop().open(new File(watch_movie+".html"));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
           // jPanel75.setBounds(r.x+r.width, r.y,40, 190);
            
        }
        else
        {
            watch_movie="";
            String [] rizwan=new String[100];
            rizwan=kim.split(" [0-9]$");
            kim=rizwan[0];
            watch_show=kim;
            jPanel79.setVisible(true);
            jPanel79.setBounds(r.x+r.width, r.y,40, 190);
        }
        }
    }
    catch(Exception ex)
    {
         JOptionPane.showMessageDialog(this,ex);
    }
}
    private void jButton68ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton68ActionPerformed
        // TODO add your handling code here:
        check(jButton68.getText(),jButton68.getBounds());
    }//GEN-LAST:event_jButton68ActionPerformed
public void set()
{
    JButton [] btnx=new JButton[100];
       btnx[0]=jButton68;
        btnx[1]=jButton69;
        btnx[2]=jButton70;
        btnx[3]=jButton71;
        btnx[4]=jButton72;
        btnx[5]=jButton78;
        btnx[6]=jButton84;
        btnx[7]=jButton87;
        btnx[8]=jButton88;
        btnx[9]=jButton89;
        btnx[10]=jButton90;
        btnx[11]=jButton96;
        btnx[12]=jButton98;
        btnx[13]=jButton99;
        btnx[14]=jButton100;
        btnx[15]=jButton101;
        btnx[16]=jButton102;
        btnx[17]=jButton103;
        btnx[18]=jButton104;
        btnx[19]=jButton105;
        Rectangle z=jPanel79.getBounds();
        for(int i=0;i<20;i++)
        {
            Rectangle y=btnx[i].getBounds();
            System.out.println(i+"   "+"mawaaaaa"+z.y+" "+(y.y-190-70));
            if((y.x==z.x-330 && z.y==y.y-190-70)||(y.x==z.x-330 && z.y==y.y-190-70-68))
            {
                dev++;
                System.out.println("mgggg");
                if(y.x==z.x-330 && z.y==y.y-190-70)
                {
                    btnx[i].setBounds(y.x, y.y+68, y.width, y.height);
                }
                shift=btnx[i].getBounds();
                jPanel80.setVisible(true);
                jPanel81.setVisible(false);
                jPanel82.setVisible(false);
                jPanel80.setBounds(z.x-330,z.y+192,370,190);
                String yo=btnx[i].getText();
               // JButton [] btnx2=new JButton[100];
                   btnx[0]=jButton191;
                   btnx[1]=jButton192;
                   btnx[2]=jButton193;
                   btnx[3]=jButton194;
                   btnx[4]=jButton195;
                   btnx[5]=jButton196;
                   btnx[6]=jButton197;
                   btnx[7]=jButton198;
                   btnx[8]=jButton199;
                   
                   int p=0;
                try
                {
                    String jeev[]=savu.split(" [0-9]$");
                    savu=jeev[0];
                    String sql="select * from tv_shows where show_name REGEXP '"+jeev[0]+"'";
                    ResultSet res=stmt.executeQuery(sql);
                    while(res.next())
                    {
                        btnx[p].setVisible(true);
                        p++;
                    }
                    for(int d=p;d<9;d++)
                    {
                        btnx[d].setVisible(false);
                    }
                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(this,ex);
                }
                break;
            }
            else
            {
                Rectangle m=btnx[i].getBounds();
                if(m.x==z.x-330 && z.y==m.y)
                {
                    savu=btnx[i].getText();
                }
            }
        }
}
static String savu="";
Rectangle shift=null;
int dev=0;
    private void jButton188ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton188ActionPerformed
        // TODO add your handling code here:
        set();
    }//GEN-LAST:event_jButton188ActionPerformed
public void mingey(int c,String upsc)
{
    savu=savu+"_"+upsc;
    System.out.println(savu);
    int i=0;
    JButton [] btnx=new JButton[100];
                  // btnx[9]=jButton200;
                   btnx[10]=jButton200;
                   btnx[11]=jButton201;
                   btnx[12]=jButton202;
                   btnx[13]=jButton203;
                   btnx[14]=jButton204;
                   btnx[15]=jButton205;
                   btnx[16]=jButton206;
                   btnx[17]=jButton207;
                   btnx[18]=jButton208;
                   btnx[19]=jButton209;
                   btnx[20]=jButton210;
                   btnx[21]=jButton211;
                   btnx[22]=jButton212;
                   btnx[23]=jButton213;
                   btnx[24]=jButton214;
                   btnx[25]=jButton215;
                   btnx[26]=jButton216;
                   btnx[27]=jButton217;
                   jPanel81.setBounds(jPanel80.getBounds());
                   jPanel82.setBounds(jPanel80.getBounds());
                   jPanel81.setVisible(true);
                    jPanel80.setVisible(false);
                     ep_btn5.setVisible(false);
                    ep_btn6.setVisible(false);
    try
    {
        String sql="select * from tv_shows where show_name='"+savu+"'";
        ResultSet res=stmt.executeQuery(sql);
        if(res.next())
        {
            for( i=10;i<Integer.parseInt(res.getString("episodes"))+10;i++)
            {
                btnx[i].setVisible(true);
                if(i>=19)
                {
                    ep_btn5.setVisible(true);
                    ep_btn6.setVisible(true);
                }
               
            }
             
            for(int m=i;m<28;m++)
            {
                btnx[m].setVisible(false);
            }
        }
    }
   catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(this, ex);    
                }
        
    
}
    private void jButton191ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton191ActionPerformed
        // TODO add your handling code here:
        mingey(1,jButton191.getText());
    }//GEN-LAST:event_jButton191ActionPerformed

    private void jButton192ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton192ActionPerformed
        // TODO add your handling code here:
        mingey(2,jButton192.getText());
    }//GEN-LAST:event_jButton192ActionPerformed

    private void jButton193ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton193ActionPerformed
mingey(3,jButton193.getText());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton193ActionPerformed

    private void jButton194ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton194ActionPerformed
   mingey(4,jButton194.getText());     // TODO add your handling code here:
    }//GEN-LAST:event_jButton194ActionPerformed

    private void jButton195ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton195ActionPerformed
     mingey(5,jButton195.getText());   // TODO add your handling code here:
    }//GEN-LAST:event_jButton195ActionPerformed

    private void jButton196ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton196ActionPerformed
  mingey(6,jButton196.getText());      // TODO add your handling code here:
    }//GEN-LAST:event_jButton196ActionPerformed

    private void jButton197ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton197ActionPerformed
   mingey(7,jButton197.getText());     // TODO add your handling code here:
    }//GEN-LAST:event_jButton197ActionPerformed

    private void jButton198ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton198ActionPerformed
  mingey(8,jButton198.getText());      // TODO add your handling code here:
    }//GEN-LAST:event_jButton198ActionPerformed

    private void jButton199ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton199ActionPerformed
  mingey(9,jButton199.getText());      // TODO add your handling code here:
    }//GEN-LAST:event_jButton199ActionPerformed

    private void jButton200ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton200ActionPerformed
        // TODO add your handling code here:
         savu=savu+"_"+jButton200.getText()+".html";
        //System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(savu));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         
    }//GEN-LAST:event_jButton200ActionPerformed

    private void ep_btn5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ep_btn5MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_ep_btn5MouseClicked

    private void ep_btn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ep_btn5ActionPerformed
        // TODO add your handling code here:
           jPanel81.setVisible(false);
        jPanel82.setVisible(true);
    }//GEN-LAST:event_ep_btn5ActionPerformed

    private void ep_btn6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ep_btn6MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_ep_btn6MouseClicked

    private void ep_btn6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ep_btn6ActionPerformed
        // TODO add your handling code here:
     
    }//GEN-LAST:event_ep_btn6ActionPerformed

    private void ep_btn7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ep_btn7MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_ep_btn7MouseClicked

    private void ep_btn7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ep_btn7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ep_btn7ActionPerformed

    private void ep_btn8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ep_btn8MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_ep_btn8MouseClicked

    private void ep_btn8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ep_btn8ActionPerformed
        // TODO add your handling code here:
        jPanel81.setVisible(true);
        jPanel82.setVisible(false);
    }//GEN-LAST:event_ep_btn8ActionPerformed

    private void jButton127ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton127ActionPerformed
        // TODO add your handling code here:
        watch_list1();
    }//GEN-LAST:event_jButton127ActionPerformed

    private void jButton119ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton119ActionPerformed
        // TODO add your handling code here:
            dhoni=dhoni+"_"+jButton119.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton119ActionPerformed

    private void jButton120ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton120ActionPerformed
        // TODO add your handling code here:
            dhoni=dhoni+"_"+jButton120.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton120ActionPerformed

    private void jButton121ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton121ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton121.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton121ActionPerformed

    private void jButton122ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton122ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton122.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton122ActionPerformed

    private void jButton123ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton123ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton123.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton123ActionPerformed

    private void jButton124ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton124ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton124.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton124ActionPerformed

    private void jButton125ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton125ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton125.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton125ActionPerformed

    private void jButton126ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton126ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton126.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton126ActionPerformed

    private void jButton163ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton163ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton163.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton163ActionPerformed

    private void jButton164ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton164ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton164.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton164ActionPerformed

    private void jButton165ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton165ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton165.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton165ActionPerformed

    private void jButton166ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton166ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton166.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton166ActionPerformed

    private void jButton167ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton167ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton167.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton167ActionPerformed

    private void jButton168ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton168ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton168.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton168ActionPerformed

    private void jButton169ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton169ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton169.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton169ActionPerformed

    private void jButton170ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton170ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton170.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton170ActionPerformed

    private void jButton171ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton171ActionPerformed
        // TODO add your handling code here:
        dhoni=dhoni+"_"+jButton171.getText()+".html";
        System.out.println("dhoni"+dhoni);
        try {
            Desktop.getDesktop().open(new File(dhoni));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
         show_recom(show);
    }//GEN-LAST:event_jButton171ActionPerformed

    private void sarkar_add_list8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sarkar_add_list8ActionPerformed
        // TODO add your handling code here:
        watch_list();
    }//GEN-LAST:event_sarkar_add_list8ActionPerformed

    private void sarkar_add_list8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkar_add_list8MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkar_add_list8MouseEntered

    private void sarkar_wt8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sarkar_wt8ActionPerformed
        // TODO add your handling code here:
        //String string="lucy";

        try {
            Desktop.getDesktop().open(new File(movie+".html"));
        } catch (IOException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
        //  jPanel9.setVisible(false);
        //   jPanel10.setVisible(false);
        jPanel30.setVisible(false);
        recom(movie);
    }//GEN-LAST:event_sarkar_wt8ActionPerformed

    private void jPanel6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel6MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel6MouseExited

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        movie="padi padi leche manasu";
         jPanel30.setVisible(true);
      Rectangle jig1=rom_com_panel.getBounds(shift);
      Rectangle jig=jButton11.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
       
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton11MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton11MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11MouseReleased

    private void jButton11MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton11MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11MouseExited

    private void jButton11MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton11MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11MouseEntered

    private void jButton11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton11MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11MouseClicked

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        movie="meeku maathrame cheptha";
         jPanel30.setVisible(true);
      Rectangle jig1=rom_com_panel.getBounds(shift);
      Rectangle jig=jButton10.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
       
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton10MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton10MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10MouseReleased

    private void jButton10MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton10MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10MouseExited

    private void jButton10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton10MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10MouseEntered

    private void jButton10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton10MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10MouseClicked

    private void sarkarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sarkarActionPerformed
        // TODO add your handling code here:
        movie="chila sow";
       jPanel30.setVisible(true);
      Rectangle jig1=rom_com_panel.getBounds(shift);
      Rectangle jig=sarkar.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    }//GEN-LAST:event_sarkarActionPerformed

    private void sarkarMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkarMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkarMouseReleased

    private void sarkarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkarMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkarMouseExited

    private void sarkarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkarMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkarMouseEntered

    private void sarkarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sarkarMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_sarkarMouseClicked

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
       // jPanel11.setVisible(true);
        movie="evariki cheppadu";
         jPanel30.setVisible(true);
      Rectangle jig1=rom_com_panel.getBounds(shift);
      Rectangle jig=jButton7.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
      
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton7MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MouseReleased
        //  jPanel9.setVisible(false);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7MouseReleased

    private void jButton7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7MouseExited

    private void jButton7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7MouseEntered

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        movie="ee nagaraniki emaindi";
        jPanel30.setVisible(true);
      Rectangle jig1=rom_com_panel.getBounds(shift);
      Rectangle jig=jButton9.getBounds();
      jPanel30.setBounds(jig.x+jig.width,jig1.y,40,190);
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton9MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9MouseReleased

    private void jButton9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9MouseExited

    private void jButton9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9MouseEntered

    private void jButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton29ActionPerformed
        // TODO add your handling code here:
        jPanel9.setVisible(true);
        if(jPanel9.getX()!=1702 && jPanel9.getY()!=70)
        {
            jPanel9.setBounds(1702, 70, 200, 230);
        AnimationClass anim=new AnimationClass();
        anim.jButtonXLeft(jButton106.getX(),jButton106.getX()-50,6,1,jButton106);
        anim.jButtonXLeft(jButton218.getX(),jButton218.getX()-30,8,1,jButton218);
        anim.jButtonXLeft(jButton190.getX(),jButton190.getX()-50,10,1,jButton190);
        anim.jButtonXLeft(jButton26.getX(),jButton26.getX()-20,12,1,jButton26);
        anim.jButtonXLeft(jButton189.getX(),jButton189.getX()-0,14,1,jButton189);
        }
        else
        {
            jPanel9.setBounds(1703, 80, 200,230);
            jPanel9.setVisible(false);
        }
        
    }//GEN-LAST:event_jButton29ActionPerformed

    private void jButton218ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton218ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton218ActionPerformed

    private void jButton190ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton190ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton190ActionPerformed

    private void jButton189ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton189ActionPerformed
        // TODO add your handling code here:
        jPanel11.setVisible(false);
        jPanel40.setVisible(false);
        jPanel10.setVisible(true);
        if(jPanel10.getY()!=400)
        {
            jPanel10.setBounds(jPanel10.getX(), 400, 510, 330);
            AnimationClass anim=new AnimationClass();
            anim.jLabelXLeft(jLabel26.getX(),jLabel26.getX()-200,3,1,jLabel26);
            anim.jLabelXLeft(jLabel33.getX(),jLabel33.getX()-200,3,1,jLabel33);
            anim.jLabelXLeft(jLabel34.getX(),jLabel34.getX()-200,3,1,jLabel34);
            jPanel9.setBounds(1680, 80, 230, 310);
        }
     
            jPanel9.setVisible(false);
    }//GEN-LAST:event_jButton189ActionPerformed

    private void jButton106ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton106ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton106ActionPerformed

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
        // TODO add your handling code here:
        jPanel10.setVisible(false);
        jPanel11.setVisible(true);
        jPanel40.setVisible(false);
        if(jPanel11.getY()!=400)
        {
            jPanel11.setBounds(700, 400, 510, 330);
            jPanel9.setBounds(1680, 80, 230, 310);
        }
        jPanel9.setVisible(false);
        
        
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jButton190MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton190MouseEntered
        // TODO add your handling code here:
        jButton190.setOpaque(true);
        jButton190.setBackground(Color.red);
    }//GEN-LAST:event_jButton190MouseEntered

    private void jButton26MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton26MouseEntered
        // TODO add your handling code here:
        jButton26.setOpaque(true);
         jButton26.setBackground(Color.red);
    }//GEN-LAST:event_jButton26MouseEntered

    private void jButton218MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton218MouseEntered
        // TODO add your handling code here:
        jButton218.setOpaque(true);
         jButton218.setBackground(Color.red);
    }//GEN-LAST:event_jButton218MouseEntered

    private void jButton189MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton189MouseEntered
        // TODO add your handling code here:
         jButton189.setBackground(Color.red);
         jButton189.setOpaque(true);
    }//GEN-LAST:event_jButton189MouseEntered

    private void jButton106MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton106MouseEntered
        // TODO add your handling code here:
        jButton106.setOpaque(true);
         jButton106.setBackground(Color.red);
    }//GEN-LAST:event_jButton106MouseEntered

    private void jButton106MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton106MouseExited
        // TODO add your handling code here:
         jButton106.setBackground(Color.black);
         jButton106.setOpaque(false);
    }//GEN-LAST:event_jButton106MouseExited

    private void jButton189MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton189MouseExited
        // TODO add your handling code here:
         jButton189.setBackground(Color.black);
         jButton189.setOpaque(false);
    }//GEN-LAST:event_jButton189MouseExited

    private void jButton218MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton218MouseExited
        // TODO add your handling code here:
         jButton218.setBackground(Color.black);
         jButton218.setOpaque(false);
    }//GEN-LAST:event_jButton218MouseExited

    private void jButton26MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton26MouseExited
        // TODO add your handling code here:
         jButton26.setBackground(Color.black);
         jButton26.setOpaque(false);
    }//GEN-LAST:event_jButton26MouseExited

    private void jButton190MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton190MouseExited
        // TODO add your handling code here:
         jButton190.setBackground(Color.black);
         jButton190.setOpaque(false);
    }//GEN-LAST:event_jButton190MouseExited

    private void jButton219ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton219ActionPerformed
        // TODO add your handling code here:
        String gautham=jLabel16.getText();
        try{
                String sql="select pswd from users where userid='"+gautham+"'";
                ResultSet res=stmt.executeQuery(sql);
                if(res.next())
                {
                    
                
                char [] si=new char[100];
                si=jPasswordField1.getPassword();
                String su="";
                for (int i=0;i<si.length;i++)
                {
                    su=su+si[i];
                }
                System.out.println(su+"-----"+(res.getString("pswd")));
                if(su.equals(res.getString("pswd")))
                {
                    System.out.println("scsdsdcsdcsd");
                    si=jPasswordField2.getPassword();
                    su="";
                    for (int i=0;i<si.length;i++)
                    {
                         su=su+si[i];
                    }
                    char [] si1=new char[100];
                    si1=jPasswordField3.getPassword();
                    String su1="";
                    for (int i=0;i<si1.length;i++)
                    {
                         su1=su1+si1[i];
                    }
                    if(su.equals(su1))
                    {
                        sql="update users set pswd='"+su1+"' where userid='"+gautham+"'";
                        stmt.executeUpdate(sql);
                        jPanel10.setVisible(false);
                        jPanel40.setVisible(true);
                        jLabel33.setBounds(jLabel33.getX()+200, jLabel33.getY(), 190, 35);
                        jLabel34.setBounds(jLabel34.getX()+200, jLabel34.getY(), 190, 35);
                        jLabel26.setBounds(jLabel26.getX()+200, jLabel26.getY(), 190, 35);
                        jPasswordField1.setText("");
                        jPasswordField2.setText("");
                        jPasswordField3.setText("");

                            jPanel10.setBounds(jPanel10.getX(), 410, 510, 320);

                    }
                    else
                    {
                        jLabel31.setText("Confirmed Password not Matching");
                    }
                }
                else
                {
                    jLabel31.setText("Password Incorrect"); 
                }
        }
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(this,ex);
        }
        
        
    }//GEN-LAST:event_jButton219ActionPerformed

    private void jButton220ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton220ActionPerformed
        // TODO add your handling code here:
        jPanel10.setVisible(false);
        jPanel40.setVisible(true);
        jLabel33.setBounds(jLabel33.getX()+200, jLabel33.getY(), 190, 35);
        jLabel34.setBounds(jLabel34.getX()+200, jLabel34.getY(), 190, 35);
        jLabel26.setBounds(jLabel26.getX()+200, jLabel26.getY(), 190, 35);
        jPasswordField1.setText("");
        jPasswordField2.setText("");
        jPasswordField3.setText("");
        
            jPanel10.setBounds(jPanel10.getX(), 410, 510, 320);
       
    }//GEN-LAST:event_jButton220ActionPerformed

    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jPasswordField1ActionPerformed

    private void jButton219MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton219MouseEntered
        // TODO add your handling code here:
        jButton219.setBackground(Color.red);
    }//GEN-LAST:event_jButton219MouseEntered

    private void jButton220MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton220MouseEntered
        // TODO add your handling code here:
        jButton220.setBackground(Color.red);
    }//GEN-LAST:event_jButton220MouseEntered

    private void jButton219MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton219MouseExited
        // TODO add your handling code here:
        jButton219.setBackground(Color.black);
    }//GEN-LAST:event_jButton219MouseExited

    private void jButton220MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton220MouseExited
        // TODO add your handling code here:
        jButton220.setBackground(Color.black);
    }//GEN-LAST:event_jButton220MouseExited

    private void jButton221ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton221ActionPerformed
        // TODO add your handling code here:
        jPanel11.setVisible(false);
        jPanel40.setVisible(true);
        jPanel11.setBounds(700,401,510,330);
    }//GEN-LAST:event_jButton221ActionPerformed

    private void jButton221MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton221MouseEntered
        // TODO add your handling code here:
        jButton221.setBackground(Color.red);
    }//GEN-LAST:event_jButton221MouseEntered

    private void jButton221MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton221MouseExited
        // TODO add your handling code here:
        jButton221.setBackground(Color.black);
    }//GEN-LAST:event_jButton221MouseExited
String html = "<html>\n" +
              "    <body>\n" +
              "        <head><Hello, world</head>\n" +
              "    </body>\n" +
              " <h5> <font color=\"red\" >sdf</font></h5>"+
              "</html>\n";
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
     
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseEntered
        // TODO add your handling code here:
      //  jButton3.setContentAreaFilled(true);
        jButton3.setBackground(new Color(251,0,51));
        jLabel40.setVisible(true);
    }//GEN-LAST:event_jButton3MouseEntered

    private void jButton3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseExited
        // TODO add your handling code here:
        jButton3.setBackground(Color.black);
        jLabel40.setVisible(false);
    }//GEN-LAST:event_jButton3MouseExited
public void movement()
{
    java.util.Timer mytimer = new java.util.Timer();
 TimerTask task=new TimerTask()
 {
     public void run()
     {
         //jPanel14.setVisible(false);
     }
};
  mytimer.schedule(task, 500);
}
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
         jPanel9.setBounds(1680, 80, 230, 310);
            jPanel9.setVisible(false);
            search.setVisible(false);
            jButton6.setVisible(false);
        jPanel12.setVisible(true);
         jPanel40.removeAll();
        jPanel40.repaint();
        jPanel40.revalidate();
 jButton27.setForeground(Color.white);
        //jButton26.setForeground(Color.white);
        jButton28.setForeground(Color.white);
        jPanel40.add(jPanel12);
       jPanel40.repaint();
        jPanel40.revalidate();
        
        
        
        jButton2.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton1.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
          jButton3.setBorder(BorderFactory.createMatteBorder(0, 2, 0, 2, Color.red));
          jButton4.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.red));
         jButton5.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton222.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jPanel18MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel18MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel18MouseExited

    private void jPanel18MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel18MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel18MouseEntered

    private void jButton243ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton243ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton243ActionPerformed

    private void jButton243MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton243MouseEntered
        // TODO add your handling code here:
        Rectangle r=jButton243.getBounds();
        detective_on(r);
    }//GEN-LAST:event_jButton243MouseEntered

    private void jPanel17MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel17MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel17MouseExited

    private void jPanel17MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel17MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel17MouseEntered

    private void jButton242ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton242ActionPerformed
        // TODO add your handling code here:
        AnimationClass anim=new AnimationClass();
      //  jPanel18.setVisible(true);
        Thread th=new Thread()
        {
            @Override
            public void run()
            {
                try
                {

                    jPanel18.setBounds(0,370,1910,230);

                    JButton [] butx=new JButton[6];
                    butx[0]=jButton243;
                    butx[1]=jButton244;
                    butx[2]=jButton245;
                    butx[3]=jButton246;
                    butx[4]=jButton247;
                    while(true)
                    {
                        Thread.sleep(1);

                        for (int i=0;i<5;i++)
                        {
                            butx[i].setBounds(butx[i].getX()+30, butx[i].getY(), 310, 190);
                            //  System.out.println(butx[i].getX()-10);
                        }
                        if(butx[0].getX()==2160)
                        {
                            // System.out.println("srujanaaa");
                            jButton243.setBounds(60+350*6,20,340,190);
                            jButton244.setBounds(350*6+410,20,340,190);
                            jButton245.setBounds(350*6+760,20,340,190);
                            jButton246.setBounds(350*6+1110,20,340,190);
                            jButton247.setBounds(350*6+1460,20,340,190);
                            break;
                        }

                    }

                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,ex);
                }

            }
        };th.start();

        jButton241.setEnabled(true);
        jButton242.setEnabled(false);

        Thread th1=new Thread()
        {
            @Override
            public void run()
            {
                try
                {

                    int i=0;
                    // System.out.println("srujanaaa");
                    JButton [] butx=new JButton[6];
                    butx[0]=jButton236;
                    butx[1]=jButton237;
                    butx[2]=jButton238;
                    butx[3]=jButton239;
                    butx[4]=jButton240;
                    while(true)
                    {
                        Thread.sleep(1);

                        for ( i=0;i<5;i++)
                        {
                            butx[i].setBounds(butx[i].getX()+30, butx[i].getY(), 310, 190);
                            //System.out.println(butx[i].getX()-10);

                        }
                        //System.out.println("srujanaaa");
                        if(butx[4].getX()==1460)
                        {
                            System.out.println("Code------->2");
                            System.out.println(butx[0].getX());
                            System.out.println(butx[1].getX());
                            System.out.println(butx[2].getX());
                            System.out.println(butx[3].getX());

                            jButton236.setBounds(60, 20, 340, 190);
                            jButton237.setBounds(410, 20, 340, 190);
                            jButton238.setBounds(760, 20, 340, 190);
                            jButton239.setBounds(1110, 20, 340, 190);
                            jButton240.setBounds(1460, 20, 340, 190);
                            jPanel17.setOpaque(true);
                            break;
                        }

                    }

                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,ex);
                }

            }
        };th1.start();

    }//GEN-LAST:event_jButton242ActionPerformed

    private void jButton241ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton241ActionPerformed
        // TODO add your handling code here:
        AnimationClass anim=new AnimationClass();
        jPanel17.setOpaque(false);

        Thread th=new Thread()
        {
            @Override
            public void run()
            {
                try
                {

                    jPanel18.setBounds(0,370,1910,230);
                    while(true)
                    {
                        if(jButton243.getX()==2160)
                        {
                            break;
                        }

                        jButton243.setBounds(jButton243.getX()+350,20,340,190);
                        jButton244.setBounds(350+jButton244.getX(),20,340,190);
                        jButton245.setBounds(350+jButton245.getX(),20,340,190);
                        jButton246.setBounds(350+jButton246.getX(),20,340,190);
                        jButton247.setBounds(350+jButton247.getX(),20,340,190);

                    }
                    JButton [] butx=new JButton[6];
                    butx[0]=jButton236;
                    butx[1]=jButton237;
                    butx[2]=jButton238;
                    butx[3]=jButton239;
                    butx[4]=jButton240;
                    while(true)
                    {
                        Thread.sleep(1);

                        for (int i=0;i<5;i++)
                        {
                            butx[i].setBounds(butx[i].getX()-30, butx[i].getY(), 310, 190);
                            //  System.out.println(butx[i].getX()-10);
                        }
                        if(butx[4].getX()<-5000)
                        {
                            jButton236.setBounds(410-7*350, 20, 340, 190);
                            jButton237.setBounds(760-7*350, 20, 340, 190);
                            jButton238.setBounds(1110-7*350, 20, 340, 190);
                            jButton239.setBounds(1460-7*350, 20, 340, 190);
                            jButton240.setBounds(1810-7*350, 20, 340, 190);

                            System.out.println("---------3----------");
                            System.out.println(butx[0].getX());
                            System.out.println(butx[1].getX());
                            System.out.println(butx[2].getX());
                            System.out.println(butx[3].getX());
                            System.out.println(butx[4].getX());

                            break;
                        }

                    }

                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,ex);
                }

            }
        };th.start();

        jButton241.setEnabled(false);
        jButton242.setEnabled(true);

        //jPanel17.setVisible(false);

        Thread th1=new Thread()
        {
            @Override
            public void run()
            {
                try
                {

                    int i=0;
                    System.out.println("<----------code 1");
                    JButton [] butx=new JButton[6];
                    butx[0]=jButton243;
                    butx[1]=jButton244;
                    butx[2]=jButton245;
                    butx[3]=jButton246;
                    butx[4]=jButton247;
                    while(true)
                    {
                        Thread.sleep(1);

                        for ( i=0;i<5;i++)
                        {
                            butx[i].setBounds(butx[i].getX()-30, butx[i].getY(), 310, 190);
                            //System.out.println(butx[i].getX()-10);

                        }
                        //System.out.println("srujanaaa");
                        if(butx[0].getX()==60)
                        {
                            System.out.println(butx[0].getX());
                            System.out.println(butx[1].getX());
                            System.out.println(butx[2].getX());
                            System.out.println(butx[3].getX());

                            ////////////////////
                            jButton243.setBounds(60,20,340,190);
                            jButton244.setBounds(410,20,340,190);
                            jButton245.setBounds(760,20,340,190);
                            jButton246.setBounds(1110,20,340,190);
                            jButton247.setBounds(1460,20,340,190);
                            break;
                        }

                    }

                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,ex);
                }

            }
        };th1.start();

    }//GEN-LAST:event_jButton241ActionPerformed

    private void jButton237ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton237ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton237ActionPerformed

    private void jButton236ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton236ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton236ActionPerformed

    private void jButton236MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton236MouseEntered
        // TODO add your handling code here:
        Rectangle r=jButton236.getBounds();
        detective_on(r);
    }//GEN-LAST:event_jButton236MouseEntered

    private void jPanel16MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel16MouseExited
        // TODO add your handling code here:

    }//GEN-LAST:event_jPanel16MouseExited

    private void jPanel16MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel16MouseEntered
        // TODO add your handling code here:

    }//GEN-LAST:event_jPanel16MouseEntered

    private void jButton231ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton231ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton231ActionPerformed

    private void jButton231MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton231MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton231MouseEntered

    private void jPanel14MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel14MouseExited
        // TODO add your handling code here:

    }//GEN-LAST:event_jPanel14MouseExited

    private void jPanel14MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel14MouseEntered
        // TODO add your handling code here:

    }//GEN-LAST:event_jPanel14MouseEntered

    private void jButton226ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton226ActionPerformed
        // TODO add your handling code here:
        AnimationClass anim=new AnimationClass();

        Thread th=new Thread()
        {
            @Override
            public void run()
            {
                try
                {

                    jPanel16.setBounds(0,630,1910,230);

                    JButton [] butx=new JButton[6];
                    butx[0]=jButton231;
                    butx[1]=jButton232;
                    butx[2]=jButton233;
                    butx[3]=jButton234;
                    butx[4]=jButton235;
                    while(true)
                    {
                        Thread.sleep(1);

                        for (int i=0;i<5;i++)
                        {
                            butx[i].setBounds(butx[i].getX()+30, butx[i].getY(), 310, 190);
                            //  System.out.println(butx[i].getX()-10);
                        }
                        if(butx[0].getX()==2160)
                        {
                            // System.out.println("srujanaaa");
                            jButton231.setBounds(60+350*6,20,340,190);
                            jButton232.setBounds(350*6+410,20,340,190);
                            jButton233.setBounds(350*6+760,20,340,190);
                            jButton234.setBounds(350*6+1110,20,340,190);
                            jButton235.setBounds(350*6+1460,20,340,190);
                            break;
                        }

                    }

                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,ex);
                }

            }
        };th.start();

        jButton225.setEnabled(true);
        jButton226.setEnabled(false);

        Thread th1=new Thread()
        {
            @Override
            public void run()
            {
                try
                {

                    int i=0;
                    // System.out.println("srujanaaa");
                    JButton [] butx=new JButton[6];
                    butx[0]=jButton224;
                    butx[1]=jButton227;
                    butx[2]=jButton228;
                    butx[3]=jButton229;
                    butx[4]=jButton230;
                    while(true)
                    {
                        Thread.sleep(1);

                        for ( i=0;i<5;i++)
                        {
                            butx[i].setBounds(butx[i].getX()+30, butx[i].getY(), 310, 190);
                            //System.out.println(butx[i].getX()-10);

                        }
                        //System.out.println("srujanaaa");
                        if(butx[4].getX()==1460)
                        {
                            System.out.println("Code------->2");
                            System.out.println(butx[0].getX());
                            System.out.println(butx[1].getX());
                            System.out.println(butx[2].getX());
                            System.out.println(butx[3].getX());

                            jButton224.setBounds(60, 20, 340, 190);
                            jButton227.setBounds(410, 20, 340, 190);
                            jButton228.setBounds(760, 20, 340, 190);
                            jButton229.setBounds(1110, 20, 340, 190);
                            jButton230.setBounds(1460, 20, 340, 190);
                            jPanel14.setOpaque(true);
                            break;
                        }

                    }

                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,ex);
                }

            }
        };th1.start();

    }//GEN-LAST:event_jButton226ActionPerformed

    private void jButton225ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton225ActionPerformed
        // TODO add your handling code here:
        AnimationClass anim=new AnimationClass();
        jPanel14.setOpaque(false);

        Thread th=new Thread()
        {
            @Override
            public void run()
            {
                try
                {

                    jPanel16.setBounds(0,630,1910,230);
                    while(true)
                    {
                        if(jButton231.getX()==2160)
                        {
                            break;
                        }

                        jButton231.setBounds(jButton231.getX()+350,20,340,190);
                        jButton232.setBounds(350+jButton232.getX(),20,340,190);
                        jButton233.setBounds(350+jButton233.getX(),20,340,190);
                        jButton234.setBounds(350+jButton234.getX(),20,340,190);
                        jButton235.setBounds(350+jButton235.getX(),20,340,190);

                    }
                    JButton [] butx=new JButton[6];
                    butx[0]=jButton224;
                    butx[1]=jButton227;
                    butx[2]=jButton228;
                    butx[3]=jButton229;
                    butx[4]=jButton230;
                    while(true)
                    {
                        Thread.sleep(1);

                        for (int i=0;i<5;i++)
                        {
                            butx[i].setBounds(butx[i].getX()-30, butx[i].getY(), 310, 190);
                            //  System.out.println(butx[i].getX()-10);
                        }
                        if(butx[4].getX()<-5000)
                        {
                            jButton224.setBounds(410-7*350, 20, 340, 190);
                            jButton227.setBounds(760-7*350, 20, 340, 190);
                            jButton228.setBounds(1110-7*350, 20, 340, 190);
                            jButton229.setBounds(1460-7*350, 20, 340, 190);
                            jButton230.setBounds(1810-7*350, 20, 340, 190);

                            System.out.println("---------3----------");
                            System.out.println(butx[0].getX());
                            System.out.println(butx[1].getX());
                            System.out.println(butx[2].getX());
                            System.out.println(butx[3].getX());
                            System.out.println(butx[4].getX());

                            break;
                        }

                    }

                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,ex);
                }

            }
        };th.start();

        jButton225.setEnabled(false);
        jButton226.setEnabled(true);

        //jPanel14.setVisible(false);

        Thread th1=new Thread()
        {
            @Override
            public void run()
            {
                try
                {

                    int i=0;
                    System.out.println("<----------code 1");
                    JButton [] butx=new JButton[6];
                    butx[0]=jButton231;
                    butx[1]=jButton232;
                    butx[2]=jButton233;
                    butx[3]=jButton234;
                    butx[4]=jButton235;
                    while(true)
                    {
                        Thread.sleep(1);

                        for ( i=0;i<5;i++)
                        {
                            butx[i].setBounds(butx[i].getX()-30, butx[i].getY(), 310, 190);
                            //System.out.println(butx[i].getX()-10);

                        }
                        //System.out.println("srujanaaa");
                        if(butx[0].getX()==60)
                        {
                            System.out.println(butx[0].getX());
                            System.out.println(butx[1].getX());
                            System.out.println(butx[2].getX());
                            System.out.println(butx[3].getX());

                            ////////////////////
                            jButton231.setBounds(60,20,340,190);
                            jButton232.setBounds(410,20,340,190);
                            jButton233.setBounds(760,20,340,190);
                            jButton234.setBounds(1110,20,340,190);
                            jButton235.setBounds(1460,20,340,190);

                            break;
                        }

                    }

                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,ex);
                }

            }
        };th1.start();

    }//GEN-LAST:event_jButton225ActionPerformed

    private void jButton227ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton227ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jButton227ActionPerformed

    private void jButton224ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton224ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton224ActionPerformed

    private void jButton224MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton224MouseEntered
        // TODO add your handling code here:

    }//GEN-LAST:event_jButton224MouseEntered

    private void jButton248MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton248MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton248MouseEntered

    private void jButton248ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton248ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton248ActionPerformed

    private void jButton249ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton249ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton249ActionPerformed

    private void jButton253ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton253ActionPerformed
        // TODO add your handling code here:
        AnimationClass anim=new AnimationClass();
       jPanel19.setOpaque(false);

       Thread th=new Thread()
       {
           @Override
           public void run()
           {
               try
               {

                   jPanel20.setBounds(0,100,1910,230);
                   while(true)
                   {
                       if(jButton255.getX()==2160)
                       {
                           break;
                       }

                       jButton255.setBounds(jButton255.getX()+350,20,340,190);
                       jButton256.setBounds(350+jButton256.getX(),20,340,190);
                       jButton257.setBounds(350+jButton257.getX(),20,340,190);
                       jButton258.setBounds(350+jButton258.getX(),20,340,190);
                       jButton259.setBounds(350+jButton259.getX(),20,340,190);

                   }
                   JButton [] butx=new JButton[6];
                   butx[0]=jButton248;
                   butx[1]=jButton249;
                   butx[2]=jButton250;
                   butx[3]=jButton251;
                   butx[4]=jButton252;
                   while(true)
                   {
                       Thread.sleep(1);

                       for (int i=0;i<5;i++)
                       {
                           butx[i].setBounds(butx[i].getX()-30, butx[i].getY(), 310, 190);
                           //  System.out.println(butx[i].getX()-10);
                       }
                       if(butx[4].getX()<-5000)
                       {
                           jButton248.setBounds(410-7*350, 20, 340, 190);
                           jButton249.setBounds(760-7*350, 20, 340, 190);
                           jButton250.setBounds(1110-7*350, 20, 340, 190);
                           jButton251.setBounds(1460-7*350, 20, 340, 190);
                           jButton252.setBounds(1810-7*350, 20, 340, 190);

                           System.out.println("---------3----------");
                           System.out.println(butx[0].getX());
                           System.out.println(butx[1].getX());
                           System.out.println(butx[2].getX());
                           System.out.println(butx[3].getX());
                           System.out.println(butx[4].getX());

                           break;
                       }

                   }

               }
               catch(Exception ex)
               {
                   JOptionPane.showMessageDialog(null,ex);
               }

           }
       };th.start();

       jButton253.setEnabled(false);
       jButton254.setEnabled(true);

       //jPanel19.setVisible(false);

       Thread th1=new Thread()
       {
           @Override
           public void run()
           {
               try
               {

                   int i=0;
                   System.out.println("<----------code 1");
                   JButton [] butx=new JButton[6];
                   butx[0]=jButton255;
                   butx[1]=jButton256;
                   butx[2]=jButton257;
                   butx[3]=jButton258;
                   butx[4]=jButton259;
                   while(true)
                   {
                       Thread.sleep(1);

                       for ( i=0;i<5;i++)
                       {
                           butx[i].setBounds(butx[i].getX()-30, butx[i].getY(), 310, 190);
                           //System.out.println(butx[i].getX()-10);

                       }
                       //System.out.println("srujanaaa");
                       if(butx[0].getX()==60)
                       {
                           System.out.println(butx[0].getX());
                           System.out.println(butx[1].getX());
                           System.out.println(butx[2].getX());
                           System.out.println(butx[3].getX());

                           ////////////////////
                           jButton255.setBounds(60,20,340,190);
                           jButton256.setBounds(410,20,340,190);
                           jButton257.setBounds(760,20,340,190);
                           jButton258.setBounds(1110,20,340,190);
                           jButton259.setBounds(1460,20,340,190);
                           break;
                       }

                   }

               }
               catch(Exception ex)
               {
                   JOptionPane.showMessageDialog(null,ex);
               }

           }
       };th1.start();
    }//GEN-LAST:event_jButton253ActionPerformed

    private void jButton254ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton254ActionPerformed
        // TODO add your handling code here:
           AnimationClass anim=new AnimationClass();

       Thread th=new Thread()
       {
           @Override
           public void run()
           {
               try
               {

                   jPanel20.setBounds(0,100,1910,230);

                   JButton [] butx=new JButton[6];
                   butx[0]=jButton255;
                   butx[1]=jButton256;
                   butx[2]=jButton257;
                   butx[3]=jButton258;
                   butx[4]=jButton259;
                   while(true)
                   {
                       Thread.sleep(1);

                       for (int i=0;i<5;i++)
                       {
                           butx[i].setBounds(butx[i].getX()+30, butx[i].getY(), 310, 190);
                           //  System.out.println(butx[i].getX()-10);
                       }
                       if(butx[0].getX()==2160)
                       {
                           // System.out.println("srujanaaa");
                           jButton255.setBounds(60+350*6,20,340,190);
                           jButton256.setBounds(350*6+410,20,340,190);
                           jButton257.setBounds(350*6+760,20,340,190);
                           jButton258.setBounds(350*6+1110,20,340,190);
                           jButton259.setBounds(350*6+1460,20,340,190);
                           break;
                       }

                   }

               }
               catch(Exception ex)
               {
                   JOptionPane.showMessageDialog(null,ex);
               }

           }
       };th.start();

       jButton253.setEnabled(true);
       jButton254.setEnabled(false);

       Thread th1=new Thread()
       {
           @Override
           public void run()
           {
               try
               {

                   int i=0;
                   // System.out.println("srujanaaa");
                   JButton [] butx=new JButton[6];
                   butx[0]=jButton248;
                   butx[1]=jButton249;
                   butx[2]=jButton250;
                   butx[3]=jButton251;
                   butx[4]=jButton252;
                   while(true)
                   {
                       Thread.sleep(1);

                       for ( i=0;i<5;i++)
                       {
                           butx[i].setBounds(butx[i].getX()+30, butx[i].getY(), 310, 190);
                           //System.out.println(butx[i].getX()-10);

                       }
                       //System.out.println("srujanaaa");
                       if(butx[4].getX()==1460)
                       {
                           System.out.println("Code------->2");
                           System.out.println(butx[0].getX());
                           System.out.println(butx[1].getX());
                           System.out.println(butx[2].getX());
                           System.out.println(butx[3].getX());

                           jButton248.setBounds(60, 20, 340, 190);
                           jButton249.setBounds(410, 20, 340, 190);
                           jButton250.setBounds(760, 20, 340, 190);
                           jButton251.setBounds(1110, 20, 340, 190);
                           jButton252.setBounds(1460, 20, 340, 190);
                           jPanel19.setOpaque(true);
                           break;
                       }

                   }

               }
               catch(Exception ex)
               {
                   JOptionPane.showMessageDialog(null,ex);
               }

           }
       };th1.start();

    }//GEN-LAST:event_jButton254ActionPerformed

    private void jPanel19MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel19MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel19MouseEntered

    private void jPanel19MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel19MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel19MouseExited

    private void jButton255MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton255MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton255MouseEntered

    private void jButton255ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton255ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton255ActionPerformed

    private void jPanel20MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel20MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel20MouseEntered

    private void jPanel20MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel20MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel20MouseExited

    private void jButton260MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton260MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton260MouseEntered

    private void jButton260ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton260ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton260ActionPerformed

    private void jButton261ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton261ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton261ActionPerformed

    private void jButton265ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton265ActionPerformed
        // TODO add your handling code here:
        AnimationClass anim=new AnimationClass();
       jPanel22.setOpaque(false);

       Thread th=new Thread()
       {
           @Override
           public void run()
           {
               try
               {

                   jPanel23.setBounds(0,910,1910,230);
                   while(true)
                   {
                       if(jButton267.getX()==2160)
                       {
                           break;
                       }

                       jButton267.setBounds(jButton267.getX()+350,20,340,190);
                       jButton268.setBounds(350+jButton268.getX(),20,340,190);
                       jButton269.setBounds(350+jButton269.getX(),20,340,190);
                       jButton270.setBounds(350+jButton270.getX(),20,340,190);
                       jButton271.setBounds(350+jButton271.getX(),20,340,190);

                   }
                   JButton [] butx=new JButton[6];
                   butx[0]=jButton260;
                   butx[1]=jButton261;
                   butx[2]=jButton262;
                   butx[3]=jButton263;
                   butx[4]=jButton264;
                   while(true)
                   {
                       Thread.sleep(1);

                       for (int i=0;i<5;i++)
                       {
                           butx[i].setBounds(butx[i].getX()-30, butx[i].getY(), 310, 190);
                           //  System.out.println(butx[i].getX()-10);
                       }
                       if(butx[4].getX()<-5000)
                       {
                           jButton260.setBounds(410-7*350, 20, 340, 190);
                           jButton261.setBounds(760-7*350, 20, 340, 190);
                           jButton262.setBounds(1110-7*350, 20, 340, 190);
                           jButton263.setBounds(1460-7*350, 20, 340, 190);
                           jButton264.setBounds(1810-7*350, 20, 340, 190);

                           System.out.println("---------3----------");
                           System.out.println(butx[0].getX());
                           System.out.println(butx[1].getX());
                           System.out.println(butx[2].getX());
                           System.out.println(butx[3].getX());
                           System.out.println(butx[4].getX());

                           break;
                       }

                   }

               }
               catch(Exception ex)
               {
                   JOptionPane.showMessageDialog(null,ex);
               }

           }
       };th.start();

       jButton265.setEnabled(false);
       jButton266.setEnabled(true);

       //jPanel22.setVisible(false);

       Thread th1=new Thread()
       {
           @Override
           public void run()
           {
               try
               {

                   int i=0;
                   System.out.println("<----------code 1");
                   JButton [] butx=new JButton[6];
                   butx[0]=jButton267;
                   butx[1]=jButton268;
                   butx[2]=jButton269;
                   butx[3]=jButton270;
                   butx[4]=jButton271;
                   while(true)
                   {
                       Thread.sleep(1);

                       for ( i=0;i<5;i++)
                       {
                           butx[i].setBounds(butx[i].getX()-30, butx[i].getY(), 310, 190);
                           //System.out.println(butx[i].getX()-10);

                       }
                       //System.out.println("srujanaaa");
                       if(butx[0].getX()==60)
                       {
                           System.out.println(butx[0].getX());
                           System.out.println(butx[1].getX());
                           System.out.println(butx[2].getX());
                           System.out.println(butx[3].getX());

                           ////////////////////
                           jButton267.setBounds(60,20,340,190);
                           jButton268.setBounds(410,20,340,190);
                           jButton269.setBounds(760,20,340,190);
                           jButton270.setBounds(1110,20,340,190);
                           jButton271.setBounds(1460,20,340,190);

                           break;
                       }

                   }

               }
               catch(Exception ex)
               {
                   JOptionPane.showMessageDialog(null,ex);
               }

           }
       };th1.start();
    }//GEN-LAST:event_jButton265ActionPerformed

    private void jButton266ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton266ActionPerformed
        // TODO add your handling code here:
        AnimationClass anim=new AnimationClass();

       Thread th=new Thread()
       {
           @Override
           public void run()
           {
               try
               {

                   jPanel23.setBounds(0,910,1910,230);

                   JButton [] butx=new JButton[6];
                   butx[0]=jButton267;
                   butx[1]=jButton268;
                   butx[2]=jButton269;
                   butx[3]=jButton270;
                   butx[4]=jButton271;
                   while(true)
                   {
                       Thread.sleep(1);

                       for (int i=0;i<5;i++)
                       {
                           butx[i].setBounds(butx[i].getX()+30, butx[i].getY(), 310, 190);
                           //  System.out.println(butx[i].getX()-10);
                       }
                       if(butx[0].getX()==2160)
                       {
                           // System.out.println("srujanaaa");
                           jButton267.setBounds(60+350*6,20,340,190);
                           jButton268.setBounds(350*6+410,20,340,190);
                           jButton269.setBounds(350*6+760,20,340,190);
                           jButton270.setBounds(350*6+1110,20,340,190);
                           jButton271.setBounds(350*6+1460,20,340,190);
                           break;
                       }

                   }

               }
               catch(Exception ex)
               {
                   JOptionPane.showMessageDialog(null,ex);
               }

           }
       };th.start();

       jButton265.setEnabled(true);
       jButton266.setEnabled(false);

       Thread th1=new Thread()
       {
           @Override
           public void run()
           {
               try
               {

                   int i=0;
                   // System.out.println("srujanaaa");
                   JButton [] butx=new JButton[6];
                   butx[0]=jButton260;
                   butx[1]=jButton261;
                   butx[2]=jButton262;
                   butx[3]=jButton263;
                   butx[4]=jButton264;
                   while(true)
                   {
                       Thread.sleep(1);

                       for ( i=0;i<5;i++)
                       {
                           butx[i].setBounds(butx[i].getX()+30, butx[i].getY(), 310, 190);
                           //System.out.println(butx[i].getX()-10);

                       }
                       //System.out.println("srujanaaa");
                       if(butx[4].getX()==1460)
                       {
                           System.out.println("Code------->2");
                           System.out.println(butx[0].getX());
                           System.out.println(butx[1].getX());
                           System.out.println(butx[2].getX());
                           System.out.println(butx[3].getX());

                           jButton260.setBounds(60, 20, 340, 190);
                           jButton261.setBounds(410, 20, 340, 190);
                           jButton262.setBounds(760, 20, 340, 190);
                           jButton263.setBounds(1110, 20, 340, 190);
                           jButton264.setBounds(1460, 20, 340, 190);
                           jPanel22.setOpaque(true);
                           break;
                       }

                   }

               }
               catch(Exception ex)
               {
                   JOptionPane.showMessageDialog(null,ex);
               }

           }
       };th1.start();

    }//GEN-LAST:event_jButton266ActionPerformed

    private void jPanel22MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel22MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel22MouseEntered

    private void jPanel22MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel22MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel22MouseExited

    private void jButton267MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton267MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton267MouseEntered

    private void jButton267ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton267ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton267ActionPerformed

    private void jPanel23MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel23MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel23MouseEntered

    private void jPanel23MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel23MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel23MouseExited

    private void jButton272MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton272MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton272MouseEntered

    private void jButton272ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton272ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton272ActionPerformed

    private void jButton273ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton273ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton273ActionPerformed

    private void jPanel24MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel24MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel24MouseEntered

    private void jPanel24MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel24MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel24MouseExited

    private void jButton284MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton284MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton284MouseEntered

    private void jButton284ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton284ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton284ActionPerformed

    private void jPanel28MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel28MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel28MouseEntered

    private void jPanel28MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel28MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel28MouseExited

    private void jPanel32MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel32MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel32MouseExited

    private void jPanel32MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel32MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel32MouseEntered

    private void jButton301ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton301ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton301ActionPerformed

    private void jButton301MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton301MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton301MouseEntered

    private void jPanel29MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel29MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel29MouseExited

    private void jPanel29MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel29MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel29MouseEntered

    private void jButton295ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton295ActionPerformed
        // TODO add your handling code here:
 
AnimationClass anim=new AnimationClass();

Thread th=new Thread()
{
   @Override
   public void run()
   {
       try
       {

           jPanel32.setBounds(0,1790,1910,230);

           JButton [] butx=new JButton[6];
           butx[0]=jButton301;
           butx[1]=jButton302;
           butx[2]=jButton303;
           butx[3]=jButton304;
           butx[4]=jButton305;
           while(true)
           {
               Thread.sleep(1);

               for (int i=0;i<5;i++)
               {
                   butx[i].setBounds(butx[i].getX()+30, butx[i].getY(), 310, 190);
                   //  System.out.println(butx[i].getX()-10);
               }
               if(butx[0].getX()==2160)
               {
                   // System.out.println("srujanaaa");
                   jButton301.setBounds(60+350*6,20,340,190);
                   jButton302.setBounds(350*6+410,20,340,190);
                   jButton303.setBounds(350*6+760,20,340,190);
                   jButton304.setBounds(350*6+1110,20,340,190);
                   jButton305.setBounds(350*6+1460,20,340,190);
                   break;
               }

           }

       }
       catch(Exception ex)
       {
           JOptionPane.showMessageDialog(null,ex);
       }

   }
};th.start();

jButton294.setEnabled(true);
jButton295.setEnabled(false);

Thread th1=new Thread()
{
   @Override
   public void run()
   {
       try
       {

           int i=0;
           // System.out.println("srujanaaa");
           JButton [] butx=new JButton[6];
           butx[0]=jButton289;
           butx[1]=jButton290;
           butx[2]=jButton291;
           butx[3]=jButton292;
           butx[4]=jButton293;
           while(true)
           {
               Thread.sleep(1);

               for ( i=0;i<5;i++)
               {
                   butx[i].setBounds(butx[i].getX()+30, butx[i].getY(), 310, 190);
                   //System.out.println(butx[i].getX()-10);

               }
               //System.out.println("srujanaaa");
               if(butx[4].getX()==1460)
               {
                   System.out.println("Code------->2");
                   System.out.println(butx[0].getX());
                   System.out.println(butx[1].getX());
                   System.out.println(butx[2].getX());
                   System.out.println(butx[3].getX());

                   jButton289.setBounds(60, 20, 340, 190);
                   jButton290.setBounds(410, 20, 340, 190);
                   jButton291.setBounds(760, 20, 340, 190);
                   jButton292.setBounds(1110, 20, 340, 190);
                   jButton293.setBounds(1460, 20, 340, 190);
                   jPanel25.setOpaque(true);
                   break;
               }

           }

       }
       catch(Exception ex)
       {
           JOptionPane.showMessageDialog(null,ex);
       }

   }
};th1.start();

    }//GEN-LAST:event_jButton295ActionPerformed

    private void jButton294ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton294ActionPerformed
        // TODO add your handling code here:
 AnimationClass anim=new AnimationClass();
     jPanel29.setOpaque(false);

     Thread th=new Thread()
     {
         @Override
         public void run()
         {
             try
             {

                 jPanel32.setBounds(0,1790,1910,230);
                 while(true)
                 {
                     if(jButton301.getX()==2160)
                     {
                         break;
                     }

                     jButton301.setBounds(jButton301.getX()+350,20,340,190);
                     jButton302.setBounds(350+jButton302.getX(),20,340,190);
                     jButton303.setBounds(350+jButton303.getX(),20,340,190);
                     jButton304.setBounds(350+jButton304.getX(),20,340,190);
                     jButton305.setBounds(350+jButton305.getX(),20,340,190);

                 }
                 JButton [] butx=new JButton[6];
                 butx[0]=jButton289;
                 butx[1]=jButton290;
                 butx[2]=jButton291;
                 butx[3]=jButton292;
                 butx[4]=jButton293;
                 while(true)
                 {
                     Thread.sleep(1);

                     for (int i=0;i<5;i++)
                     {
                         butx[i].setBounds(butx[i].getX()-30, butx[i].getY(), 310, 190);
                         //  System.out.println(butx[i].getX()-10);
                     }
                     if(butx[4].getX()<-5000)
                     {
                         jButton289.setBounds(410-7*350, 20, 340, 190);
                         jButton290.setBounds(760-7*350, 20, 340, 190);
                         jButton291.setBounds(1110-7*350, 20, 340, 190);
                         jButton292.setBounds(1460-7*350, 20, 340, 190);
                         jButton293.setBounds(1810-7*350, 20, 340, 190);

                         System.out.println("---------3----------");
                         System.out.println(butx[0].getX());
                         System.out.println(butx[1].getX());
                         System.out.println(butx[2].getX());
                         System.out.println(butx[3].getX());
                         System.out.println(butx[4].getX());

                         break;
                     }

                 }

             }
             catch(Exception ex)
             {
                 JOptionPane.showMessageDialog(null,ex);
             }

         }
     };th.start();

     jButton294.setEnabled(false);
     jButton295.setEnabled(true);

     //jPanel25.setVisible(false);

     Thread th1=new Thread()
     {
         @Override
         public void run()
         {
             try
             {

                 int i=0;
                 System.out.println("<----------code 1");
                 JButton [] butx=new JButton[6];
                 butx[0]=jButton301;
                 butx[1]=jButton302;
                 butx[2]=jButton303;
                 butx[3]=jButton304;
                 butx[4]=jButton305;
                 while(true)
                 {
                     Thread.sleep(1);

                     for ( i=0;i<5;i++)
                     {
                         butx[i].setBounds(butx[i].getX()-30, butx[i].getY(), 310, 190);
                         //System.out.println(butx[i].getX()-10);

                     }
                     //System.out.println("srujanaaa");
                     if(butx[0].getX()==60)
                     {
                         System.out.println(butx[0].getX());
                         System.out.println(butx[1].getX());
                         System.out.println(butx[2].getX());
                         System.out.println(butx[3].getX());

                         ////////////////////
                         jButton301.setBounds(60,20,340,190);
                         jButton302.setBounds(410,20,340,190);
                         jButton303.setBounds(760,20,340,190);
                         jButton304.setBounds(1110,20,340,190);
                         jButton305.setBounds(1460,20,340,190);

                         break;
                     }

                 }

             }
             catch(Exception ex)
             {
                 JOptionPane.showMessageDialog(null,ex);
             }

         }
     };th1.start();
    }//GEN-LAST:event_jButton294ActionPerformed

    private void jButton290ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton290ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton290ActionPerformed

    private void jButton289ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton289ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton289ActionPerformed

    private void jButton289MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton289MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton289MouseEntered

    private void jPanel25MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel25MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel25MouseExited

    private void jPanel25MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel25MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel25MouseEntered

    private void jButton283ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton283ActionPerformed
        // TODO add your handling code here:
        AnimationClass anim=new AnimationClass();

        Thread th=new Thread()
        {
            @Override
            public void run()
            {
                try
                {

                    jPanel28.setBounds(0,1500,1910,230);

                    JButton [] butx=new JButton[6];
                    butx[0]=jButton284;
                    butx[1]=jButton285;
                    butx[2]=jButton286;
                    butx[3]=jButton287;
                    butx[4]=jButton288;
                    while(true)
                    {
                        Thread.sleep(1);

                        for (int i=0;i<5;i++)
                        {
                            butx[i].setBounds(butx[i].getX()+30, butx[i].getY(), 310, 190);
                            //  System.out.println(butx[i].getX()-10);
                        }
                        if(butx[0].getX()==2160)
                        {
                            // System.out.println("srujanaaa");
                            jButton284.setBounds(60+350*6,20,340,190);
                            jButton285.setBounds(350*6+410,20,340,190);
                            jButton286.setBounds(350*6+760,20,340,190);
                            jButton287.setBounds(350*6+1110,20,340,190);
                            jButton288.setBounds(350*6+1460,20,340,190);
                            break;
                        }

                    }

                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,ex);
                }

            }
        };th.start();

        jButton282.setEnabled(true);
        jButton283.setEnabled(false);

        Thread th1=new Thread()
        {
            @Override
            public void run()
            {
                try
                {

                    int i=0;
                    // System.out.println("srujanaaa");
                    JButton [] butx=new JButton[6];
                    butx[0]=jButton277;
                    butx[1]=jButton278;
                    butx[2]=jButton279;
                    butx[3]=jButton280;
                    butx[4]=jButton281;
                    while(true)
                    {
                        Thread.sleep(1);

                        for ( i=0;i<5;i++)
                        {
                            butx[i].setBounds(butx[i].getX()+30, butx[i].getY(), 310, 190);
                            //System.out.println(butx[i].getX()-10);

                        }
                        //System.out.println("srujanaaa");
                        if(butx[4].getX()==1460)
                        {
                            System.out.println("Code------->2");
                            System.out.println(butx[0].getX());
                            System.out.println(butx[1].getX());
                            System.out.println(butx[2].getX());
                            System.out.println(butx[3].getX());

                            jButton277.setBounds(60, 20, 340, 190);
                            jButton278.setBounds(410, 20, 340, 190);
                            jButton279.setBounds(760, 20, 340, 190);
                            jButton280.setBounds(1110, 20, 340, 190);
                            jButton281.setBounds(1460, 20, 340, 190);
                            jPanel25.setOpaque(true);
                            break;
                        }

                    }

                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,ex);
                }

            }
        };th1.start();
    }//GEN-LAST:event_jButton283ActionPerformed

    private void jButton282ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton282ActionPerformed
        // TODO add your handling code here:
        AnimationClass anim=new AnimationClass();
        jPanel25.setOpaque(false);

        Thread th=new Thread()
        {
            @Override
            public void run()
            {
                try
                {

                    jPanel28.setBounds(0,1500,1910,230);
                    while(true)
                    {
                        if(jButton284.getX()==2160)
                        {
                            break;
                        }

                        jButton284.setBounds(jButton284.getX()+350,20,340,190);
                        jButton285.setBounds(350+jButton285.getX(),20,340,190);
                        jButton286.setBounds(350+jButton286.getX(),20,340,190);
                        jButton287.setBounds(350+jButton287.getX(),20,340,190);
                        jButton288.setBounds(350+jButton288.getX(),20,340,190);

                    }
                    JButton [] butx=new JButton[6];
                    butx[0]=jButton277;
                    butx[1]=jButton278;
                    butx[2]=jButton279;
                    butx[3]=jButton280;
                    butx[4]=jButton281;
                    while(true)
                    {
                        Thread.sleep(1);

                        for (int i=0;i<5;i++)
                        {
                            butx[i].setBounds(butx[i].getX()-30, butx[i].getY(), 310, 190);
                            //  System.out.println(butx[i].getX()-10);
                        }
                        if(butx[4].getX()<-5000)
                        {
                            jButton277.setBounds(410-7*350, 20, 340, 190);
                            jButton278.setBounds(760-7*350, 20, 340, 190);
                            jButton279.setBounds(1110-7*350, 20, 340, 190);
                            jButton280.setBounds(1460-7*350, 20, 340, 190);
                            jButton281.setBounds(1810-7*350, 20, 340, 190);

                            System.out.println("---------3----------");
                            System.out.println(butx[0].getX());
                            System.out.println(butx[1].getX());
                            System.out.println(butx[2].getX());
                            System.out.println(butx[3].getX());
                            System.out.println(butx[4].getX());

                            break;
                        }

                    }

                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,ex);
                }

            }
        };th.start();

        jButton282.setEnabled(false);
        jButton283.setEnabled(true);

        //jPanel25.setVisible(false);

        Thread th1=new Thread()
        {
            @Override
            public void run()
            {
                try
                {

                    int i=0;
                    System.out.println("<----------code 1");
                    JButton [] butx=new JButton[6];
                    butx[0]=jButton284;
                    butx[1]=jButton285;
                    butx[2]=jButton286;
                    butx[3]=jButton287;
                    butx[4]=jButton288;
                    while(true)
                    {
                        Thread.sleep(1);

                        for ( i=0;i<5;i++)
                        {
                            butx[i].setBounds(butx[i].getX()-30, butx[i].getY(), 310, 190);
                            //System.out.println(butx[i].getX()-10);

                        }
                        //System.out.println("srujanaaa");
                        if(butx[0].getX()==60)
                        {
                            System.out.println(butx[0].getX());
                            System.out.println(butx[1].getX());
                            System.out.println(butx[2].getX());
                            System.out.println(butx[3].getX());

                            ////////////////////
                            jButton284.setBounds(60,20,340,190);
                            jButton285.setBounds(410,20,340,190);
                            jButton286.setBounds(760,20,340,190);
                            jButton287.setBounds(1110,20,340,190);
                            jButton288.setBounds(1460,20,340,190);

                            break;
                        }

                    }

                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,ex);
                }

            }
        };th1.start();
    }//GEN-LAST:event_jButton282ActionPerformed

    private void jButton278ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton278ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton278ActionPerformed

    private void jButton277ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton277ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton277ActionPerformed

    private void jButton277MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton277MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton277MouseEntered

    private void sug1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sug1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sug1ActionPerformed

    private void sug2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sug2MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_sug2MouseEntered

    private void sug2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sug2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sug2ActionPerformed
//static String path_suggestme;
//static int path_flag=0;
     public boolean mouse_on;
     public boolean mouse_off=true;
     
    private void jPanel31MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel31MouseEntered
        // TODO add your handling code here:
       // jPanel31.setBackground(new java.awt.Color(51, 51, 51));
    
        
    }//GEN-LAST:event_jPanel31MouseEntered

    private void jLabel49MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel49MouseEntered
       
        
    }//GEN-LAST:event_jLabel49MouseEntered

    private void jPanel31MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel31MouseExited
 
        
         // mouse_off=false;
     //  playbutton_exit();
    }//GEN-LAST:event_jPanel31MouseExited
public void playbutton_exit()
{
    Thread th=new Thread()
    {
        @Override
        public void run()
        {
            try
            {
                Thread.sleep(7000);
            }
            catch(Exception ex)
            {
                JOptionPane.showMessageDialog(null,ex);
            }
              jPanel35.setVisible(false);
        }
    };th.start();
  
}
    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        search.setVisible(false);
            jButton6.setVisible(false);
        jPanel13.setVisible(true);
         jButton27.setForeground(Color.white);
        //jButton26.setForeground(Color.white);
        jButton28.setForeground(Color.white);
         jPanel40.removeAll();
        jPanel40.repaint();
        jPanel40.revalidate();

        jPanel40.add(jPanel13);
       jPanel40.repaint();
        jPanel40.revalidate();
        
         jPanel9.setBounds(1680, 80, 230, 310);
            jPanel9.setVisible(false);
        
        jButton2.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton1.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
          jButton3.setBorder(BorderFactory.createMatteBorder(0, 2, 0, 2, Color.red));
          jButton4.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton5.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.red));
         jButton222.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jLabel53MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel53MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel53MouseEntered

    private void jPanel34MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel34MouseEntered
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jPanel34MouseEntered

    private void jPanel34MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel34MouseExited
        // TODO add your handling code here:
        
     // path_suggestme="";
    }//GEN-LAST:event_jPanel34MouseExited

    private void jLabel56MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel56MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel56MouseEntered

    private void jPanel36MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel36MouseEntered
        // TODO add your handling code here:
    
    }//GEN-LAST:event_jPanel36MouseEntered

    private void jPanel36MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel36MouseExited
        // TODO add your handling code here:
       
    }//GEN-LAST:event_jPanel36MouseExited

    private void jLabel59MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel59MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel59MouseEntered

    private void jPanel49MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel49MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel49MouseEntered

    private void jPanel49MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel49MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel49MouseExited

    private void jLabel62MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel62MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel62MouseEntered

    private void jPanel50MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel50MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel50MouseEntered

    private void jPanel50MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel50MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel50MouseExited

    private void jLabel65MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel65MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel65MouseEntered

    private void jPanel51MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel51MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel51MouseEntered

    private void jPanel51MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel51MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel51MouseExited

    private void jLabel68MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel68MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel68MouseEntered

    private void jPanel52MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel52MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel52MouseEntered

    private void jPanel52MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel52MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel52MouseExited

    private void jLabel71MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel71MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel71MouseEntered

    private void jPanel53MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel53MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel53MouseEntered

    private void jPanel53MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel53MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel53MouseExited

    private void jLabel50MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel50MouseEntered
        // TODO add your handling code here:
       
    }//GEN-LAST:event_jLabel50MouseEntered

    private void jButton223ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton223ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton223ActionPerformed

    private void jButton296ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton296ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton296ActionPerformed

    private void jButton297ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton297ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton297ActionPerformed

    private void jButton298ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton298ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton298ActionPerformed

    private void jButton299ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton299ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton299ActionPerformed

    private void jButton300ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton300ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton300ActionPerformed

    private void jButton306ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton306ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton306ActionPerformed

    private void jButton307ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton307ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton307ActionPerformed

    private void jButton308ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton308ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton308ActionPerformed

    private void jButton309ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton309ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton309ActionPerformed

    private void jButton310ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton310ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton310ActionPerformed

    private void jButton311ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton311ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton311ActionPerformed

    private void jButton312ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton312ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton312ActionPerformed

    private void jButton313ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton313ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton313ActionPerformed

    private void jButton314ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton314ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton314ActionPerformed

    private void jButton315ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton315ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton315ActionPerformed

    private void jButton316ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton316ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton316ActionPerformed

    private void jButton317ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton317ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton317ActionPerformed

    private void jButton318ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton318ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton318ActionPerformed

    private void jButton319ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton319ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton319ActionPerformed

    private void sarkar_fav8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sarkar_fav8ActionPerformed
        // TODO add your handling code here:
        fav_list();
    }//GEN-LAST:event_sarkar_fav8ActionPerformed

    private void jButton128ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton128ActionPerformed
        // TODO add your handling code here:
        fav_list();
    }//GEN-LAST:event_jButton128ActionPerformed

    private void jPanel75MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel75MouseEntered
        // TODO add your handling code here:
         jPanel35.setVisible(true);
        jPanel36.setBorder(BorderFactory.createMatteBorder(0,0,0,1,new java.awt.Color(250, 204, 0, 255)));
        String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel56.getText()+".png";
        jLabel51.setBounds(jPanel36.getX(),jPanel36.getY(),0,220);
         System.out.println("p1  "+path_suggestme);
        Thread th=new Thread()
        {
            @Override
            public void run()
            {
                int i=0;
                try
                {
                    jPanel35.setBounds(jPanel36.getX()+873,jPanel36.getY(),40,190);
                    while(i<30)
                    {
                        jLabel56.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel56.getWidth()+1, jLabel56.getHeight()+1, Image.SCALE_DEFAULT)));
                        jLabel56.setBounds(jLabel56.getX()+1,jLabel56.getY(), jLabel56.getWidth()+1, jLabel56.getHeight()+1);
                        jLabel57.setBounds(jLabel57.getX()+2,jLabel57.getY(),jLabel57.getWidth(),jLabel57.getHeight());
                        jPanel36.setBounds(jPanel36.getX(), jPanel36.getY(), jPanel36.getWidth(), jPanel36.getHeight()+1);
                        jLabel58.setBounds(jLabel58.getX()+2,jLabel58.getY() ,jLabel58.getWidth(),jLabel58.getHeight());
                        jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()+30,jLabel51.getHeight()+1);
                        jPanel35.setBounds(jPanel35.getX()+1,jPanel35.getY(),jPanel35.getWidth(),jPanel35.getHeight());
                        
                        i++;
                        Thread.sleep(1);
                    }
                       
                }
                catch(Exception ex)
                {
                   JOptionPane.showMessageDialog(null,ex);
                }
            }
            
        };th.start();
    }//GEN-LAST:event_jPanel75MouseEntered

    private void jPanel75MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel75MouseExited
        // TODO add your handling code here:
         jPanel36.setBorder(BorderFactory.createMatteBorder(0,0,0,0,new java.awt.Color(0, 0, 0, 255)));
     
     //System.out.println("p2  "+path_suggestme);
      Thread th1=new Thread()
      {
          @Override
          public void run()
          {
              int i=0;
              String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel56.getText()+".png";
              try
              {
                  while(i<30)
                  {
                      jLabel56.setBounds(jLabel56.getX()-1,jLabel56.getY(), jLabel56.getWidth()-1, jLabel56.getHeight()-1);
                      jLabel56.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel56.getWidth()-1, jLabel56.getHeight()-1, Image.SCALE_DEFAULT)));
                      //jLabel56.setBounds(jLabel56.getX()-1,jLabel56.getY(), jLabel56.getWidth()-1, jLabel56.getHeight()-1);
                     jLabel57.setBounds(jLabel57.getX()-2,jLabel57.getY(),jLabel57.getWidth(),jLabel57.getHeight());
                      jLabel58.setBounds(jLabel58.getX()-2,jLabel58.getY() ,jLabel58.getWidth(),jLabel58.getHeight());
                      jPanel36.setBounds(jPanel36.getX(), jPanel36.getY(), jPanel36.getWidth(), jPanel36.getHeight()-1);
                      jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()-30,jLabel51.getHeight()-1);
                      i++;
                      Thread.sleep(1);
                  }
                     
              }
              catch(Exception ex)
              {
                 JOptionPane.showMessageDialog(null,ex);
              }
          }
          
      };th1.start();
     
      playbutton_exit();
    }//GEN-LAST:event_jPanel75MouseExited

    private void jPanel84MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel84MouseEntered
        // TODO add your handling code here:
        jPanel35.setVisible(true);
        jPanel34.setBorder(BorderFactory.createMatteBorder(0,0,0,1,new java.awt.Color(250, 204, 0, 255)));
        String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel53.getText()+".png";
        jLabel51.setBounds(jPanel34.getX(),jPanel34.getY(),0,220);
     //    System.out.println("p1  "+path_suggestme);
        Thread th=new Thread()
        {
            @Override
            public void run()
            {
                jPanel35.setBounds(jPanel34.getX()+873,jPanel34.getY(),40,190);
                int i=0;
                try
                {
                    while(i<30)
                    {
                        jLabel53.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel53.getWidth()+1, jLabel53.getHeight()+1, Image.SCALE_DEFAULT)));
                        jLabel53.setBounds(jLabel53.getX()+1,jLabel53.getY(), jLabel53.getWidth()+1, jLabel53.getHeight()+1);
                        jLabel54.setBounds(jLabel54.getX()+2,jLabel54.getY(),jLabel54.getWidth(),jLabel54.getHeight());
                        jPanel34.setBounds(jPanel34.getX(), jPanel34.getY(), jPanel34.getWidth(), jPanel34.getHeight()+1);
                        jLabel55.setBounds(jLabel55.getX()+2,jLabel55.getY(),jLabel55.getWidth(),jLabel55.getHeight());
                        jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()+30,jLabel51.getHeight()+1);
                      //  jPanel35.setBounds(jPanel35.getX()+2,jPanel35.getY(),jPanel35.getWidth(),jPanel35.getHeight());
                        jPanel35.setBounds(jPanel35.getX()+1,jPanel35.getY(),jPanel35.getWidth(),jPanel35.getHeight());
                        
                        i++;
                        Thread.sleep(1);
                    }
                       
                }
                catch(Exception ex)
                {
                   JOptionPane.showMessageDialog(null,ex);
                }
            }
            
        };th.start();

    }//GEN-LAST:event_jPanel84MouseEntered

    private void jPanel84MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel84MouseExited
        // TODO add your handling code here:
                jPanel34.setBorder(BorderFactory.createMatteBorder(0,0,0,0,new java.awt.Color(0, 0, 0, 255)));
               
                // System.out.println("p2  "+path_suggestme);
      Thread th1=new Thread()
      {
          @Override
          public void run()
          {
               String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel53.getText()+".png";
              int i=0;
              try
              {
                  
                  while(i<30)
                  {
                      jLabel53.setBounds(jLabel53.getX()-1,jLabel53.getY(), jLabel53.getWidth()-1, jLabel53.getHeight()-1);
                      jLabel53.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel53.getWidth()-1, jLabel53.getHeight()-1, Image.SCALE_DEFAULT)));
                      //jLabel53.setBounds(jLabel53.getX()-1,jLabel53.getY(), jLabel53.getWidth()-1, jLabel53.getHeight()-1);
                      jLabel54.setBounds(jLabel54.getX()-2,jLabel54.getY(),jLabel54.getWidth(),jLabel54.getHeight());
                      jLabel55.setBounds(jLabel55.getX()-2,jLabel55.getY(),jLabel55.getWidth(),jLabel55.getHeight());
                      jPanel34.setBounds(jPanel34.getX(), jPanel34.getY(), jPanel34.getWidth(), jPanel34.getHeight()-1);
                      jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()-30,jLabel51.getHeight()-1);
                      i++;
                      Thread.sleep(1);
                  }
                     
              }
              catch(Exception ex)
              {
                 JOptionPane.showMessageDialog(null,ex);
              }
          }
          
      };th1.start();
      playbutton_exit();
    }//GEN-LAST:event_jPanel84MouseExited

    private void jPanel85MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel85MouseEntered
        // TODO add your handling code here:
        jPanel35.setVisible(true);
        jPanel49.setBorder(BorderFactory.createMatteBorder(0,0,0,1,new java.awt.Color(250, 204, 0, 255)));
        String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel59.getText()+".png";
        jLabel51.setBounds(jPanel49.getX(),jPanel49.getY(),0,220);
         System.out.println("p1  "+path_suggestme);
        Thread th=new Thread()
        {
            @Override
            public void run()
            {
                int i=0;
                try
                {
                    jPanel35.setBounds(jPanel49.getX()+873,jPanel49.getY(),40,190);
                    while(i<30)
                    {
                        jLabel59.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel59.getWidth()+1, jLabel59.getHeight()+1, Image.SCALE_DEFAULT)));
                        jLabel59.setBounds(jLabel59.getX()+1,jLabel59.getY(), jLabel59.getWidth()+1, jLabel59.getHeight()+1);
                        jLabel60.setBounds(jLabel60.getX()+2,jLabel60.getY(),jLabel60.getWidth(),jLabel60.getHeight());
                        jPanel49.setBounds(jPanel49.getX(), jPanel49.getY(), jPanel49.getWidth(), jPanel49.getHeight()+1);
                        jLabel61.setBounds(jLabel61.getX()+2,jLabel61.getY(),jLabel61.getWidth(),jLabel61.getHeight());
                        jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()+30,jLabel51.getHeight()+1);
                        jPanel35.setBounds(jPanel35.getX()+1,jPanel35.getY(),jPanel35.getWidth(),jPanel35.getHeight());
                        
                        i++;
                        Thread.sleep(1);
                    }
                       
                }
                catch(Exception ex)
                {
                   JOptionPane.showMessageDialog(null,ex);
                }
            }
            
        };th.start();

    }//GEN-LAST:event_jPanel85MouseEntered

    private void jPanel85MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel85MouseExited
        // TODO add your handling code here:
     jPanel49.setBorder(BorderFactory.createMatteBorder(0,0,0,0,new java.awt.Color(0, 0, 0, 255)));
     
     //System.out.println("p2  "+path_suggestme);
      Thread th1=new Thread()
      {
          @Override
          public void run()
          {
              int i=0;
              String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel59.getText()+".png";
              try
              {
                  while(i<30)
                  {
                      jLabel59.setBounds(jLabel59.getX()-1,jLabel59.getY(), jLabel59.getWidth()-1, jLabel59.getHeight()-1);
                      jLabel59.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel59.getWidth()-1, jLabel59.getHeight()-1, Image.SCALE_DEFAULT)));
                      //jLabel59.setBounds(jLabel59.getX()-1,jLabel59.getY(), jLabel59.getWidth()-1, jLabel59.getHeight()-1);
                     jLabel60.setBounds(jLabel60.getX()-2,jLabel60.getY(),jLabel60.getWidth(),jLabel60.getHeight());
                      jLabel61.setBounds(jLabel61.getX()-2,jLabel61.getY(),jLabel61.getWidth(),jLabel61.getHeight());
                      jPanel49.setBounds(jPanel49.getX(), jPanel49.getY(), jPanel49.getWidth(), jPanel49.getHeight()-1);
                      jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()-30,jLabel51.getHeight()-1);
                      i++;
                      Thread.sleep(1);
                  }
                     
              }
              catch(Exception ex)
              {
                 JOptionPane.showMessageDialog(null,ex);
              }
          }
          
      };th1.start();
     
      playbutton_exit();
    }//GEN-LAST:event_jPanel85MouseExited

    private void jPanel86MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel86MouseEntered
        // TODO add your handling code here:
        jPanel35.setVisible(true);
        jPanel50.setBorder(BorderFactory.createMatteBorder(0,0,0,1,new java.awt.Color(250, 204, 0, 255)));
        String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel62.getText()+".png";
        jLabel51.setBounds(jPanel50.getX(),jPanel50.getY(),0,220);
         System.out.println("p1  "+path_suggestme);
        Thread th=new Thread()
        {
            @Override
            public void run()
            {
                int i=0;
                try
                {
                    jPanel35.setBounds(jPanel50.getX()+873,jPanel50.getY(),40,190);
                    while(i<30)
                    {
                        jLabel62.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel62.getWidth()+1, jLabel62.getHeight()+1, Image.SCALE_DEFAULT)));
                        jLabel62.setBounds(jLabel62.getX()+1,jLabel62.getY(), jLabel62.getWidth()+1, jLabel62.getHeight()+1);
                        jLabel63.setBounds(jLabel63.getX()+2,jLabel63.getY(),jLabel63.getWidth(),jLabel63.getHeight());
                        jPanel50.setBounds(jPanel50.getX(), jPanel50.getY(), jPanel50.getWidth(), jPanel50.getHeight()+1);
                        jLabel64.setBounds(jLabel64.getX()+2,jLabel64.getY(),jLabel64.getWidth(),jLabel64.getHeight());
                        jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()+30,jLabel51.getHeight()+1);
                        jPanel35.setBounds(jPanel35.getX()+1,jPanel35.getY(),jPanel35.getWidth(),jPanel35.getHeight());
                        
                        i++;
                        Thread.sleep(1);
                    }
                       
                }
                catch(Exception ex)
                {
                   JOptionPane.showMessageDialog(null,ex);
                }
            }
            
        };th.start();

    }//GEN-LAST:event_jPanel86MouseEntered

    private void jPanel86MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel86MouseExited
        // TODO add your handling code here:
        jPanel50.setBorder(BorderFactory.createMatteBorder(0,0,0,0,new java.awt.Color(0, 0, 0, 255)));
     
     //System.out.println("p2  "+path_suggestme);
      Thread th1=new Thread()
      {
          @Override
          public void run()
          {
              int i=0;
              String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel62.getText()+".png";
              try
              {
                  while(i<30)
                  {
                      jLabel62.setBounds(jLabel62.getX()-1,jLabel62.getY(), jLabel62.getWidth()-1, jLabel62.getHeight()-1);
                      jLabel62.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel62.getWidth()-1, jLabel62.getHeight()-1, Image.SCALE_DEFAULT)));
                      //jLabel62.setBounds(jLabel62.getX()-1,jLabel62.getY(), jLabel62.getWidth()-1, jLabel62.getHeight()-1);
                       jLabel63.setBounds(jLabel63.getX()-2,jLabel63.getY(),jLabel63.getWidth(),jLabel63.getHeight());
                      jLabel64.setBounds(jLabel64.getX()-2,jLabel64.getY(),jLabel64.getWidth(),jLabel64.getHeight());
                      jPanel50.setBounds(jPanel50.getX(), jPanel50.getY(), jPanel50.getWidth(), jPanel50.getHeight()-1);
                      jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()-30,jLabel51.getHeight()-1);
                      i++;
                      Thread.sleep(1);
                  }
                     
              }
              catch(Exception ex)
              {
                 JOptionPane.showMessageDialog(null,ex);
              }
          }
          
      };th1.start();
     
      playbutton_exit();
    }//GEN-LAST:event_jPanel86MouseExited

    private void jPanel87MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel87MouseEntered
        // TODO add your handling code here:
        jPanel35.setVisible(true);
        jPanel51.setBorder(BorderFactory.createMatteBorder(0,0,0,1,new java.awt.Color(250, 204, 0, 255)));
        String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel65.getText()+".png";
        jLabel51.setBounds(jPanel51.getX(),jPanel51.getY(),0,220);
         System.out.println("p1  "+path_suggestme);
        Thread th=new Thread()
        {
            @Override
            public void run()
            {
                int i=0;
                try
                {
                    jPanel35.setBounds(jPanel51.getX()+873,jPanel51.getY(),40,190);
                    while(i<30)
                    {
                        jLabel65.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel65.getWidth()+1, jLabel65.getHeight()+1, Image.SCALE_DEFAULT)));
                        jLabel65.setBounds(jLabel65.getX()+1,jLabel65.getY(), jLabel65.getWidth()+1, jLabel65.getHeight()+1);
                        jLabel66.setBounds(jLabel66.getX()+2,jLabel66.getY(),jLabel66.getWidth(),jLabel66.getHeight());
                        jPanel51.setBounds(jPanel51.getX(), jPanel51.getY(), jPanel51.getWidth(), jPanel51.getHeight()+1);
                        jLabel67.setBounds(jLabel67.getX()+2,jLabel67.getY(),jLabel67.getWidth(),jLabel67.getHeight());
                        jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()+30,jLabel51.getHeight()+1);
                        jPanel35.setBounds(jPanel35.getX()+1,jPanel35.getY(),jPanel35.getWidth(),jPanel35.getHeight());
                        
                        i++;
                        Thread.sleep(1);
                    }
                       
                }
                catch(Exception ex)
                {
                   JOptionPane.showMessageDialog(null,ex);
                }
            }
            
        };th.start();
    }//GEN-LAST:event_jPanel87MouseEntered

    private void jPanel87MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel87MouseExited
        // TODO add your handling code here:
        jPanel51.setBorder(BorderFactory.createMatteBorder(0,0,0,0,new java.awt.Color(0, 0, 0, 255)));
     
     //System.out.println("p2  "+path_suggestme);
      Thread th1=new Thread()
      {
          @Override
          public void run()
          {
              int i=0;
              String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel65.getText()+".png";
              try
              {
                  while(i<30)
                  {
                      jLabel65.setBounds(jLabel65.getX()-1,jLabel65.getY(), jLabel65.getWidth()-1, jLabel65.getHeight()-1);
                      jLabel65.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel65.getWidth()-1, jLabel65.getHeight()-1, Image.SCALE_DEFAULT)));
                      //jLabel65.setBounds(jLabel65.getX()-1,jLabel65.getY(), jLabel65.getWidth()-1, jLabel65.getHeight()-1);
                      jLabel66.setBounds(jLabel66.getX()-2,jLabel66.getY(),jLabel66.getWidth(),jLabel66.getHeight());
                       jLabel67.setBounds(jLabel67.getX()-2,jLabel67.getY(),jLabel67.getWidth(),jLabel67.getHeight());
                      jPanel51.setBounds(jPanel51.getX(), jPanel51.getY(), jPanel51.getWidth(), jPanel51.getHeight()-1);
                      jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()-30,jLabel51.getHeight()-1);
                      i++;
                      Thread.sleep(1);
                  }
                     
              }
              catch(Exception ex)
              {
                 JOptionPane.showMessageDialog(null,ex);
              }
          }
          
      };th1.start();
     
      playbutton_exit();
    }//GEN-LAST:event_jPanel87MouseExited

    private void jPanel88MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel88MouseEntered
        // TODO add your handling code here:
        jPanel35.setVisible(true);
        jPanel52.setBorder(BorderFactory.createMatteBorder(0,0,0,1,new java.awt.Color(250, 204, 0, 255)));
        String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel68.getText()+".png";
        jLabel51.setBounds(jPanel52.getX(),jPanel52.getY(),0,220);
         System.out.println("p1  "+path_suggestme);
        Thread th=new Thread()
        {
            @Override
            public void run()
            {
                int i=0;
                try
                {
                    jPanel35.setBounds(jPanel52.getX()+873,jPanel52.getY(),40,190);
                    while(i<30)
                    {
                        jLabel68.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel68.getWidth()+1, jLabel68.getHeight()+1, Image.SCALE_DEFAULT)));
                        jLabel68.setBounds(jLabel68.getX()+1,jLabel68.getY(), jLabel68.getWidth()+1, jLabel68.getHeight()+1);
                        jLabel69.setBounds(jLabel69.getX()+2,jLabel69.getY(),jLabel69.getWidth(),jLabel69.getHeight());
                        jPanel52.setBounds(jPanel52.getX(), jPanel52.getY(), jPanel52.getWidth(), jPanel52.getHeight()+1);
                        jLabel70.setBounds(jLabel70.getX()+2,jLabel70.getY(),jLabel70.getWidth(),jLabel70.getHeight());
                        jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()+30,jLabel51.getHeight()+1);
                        jPanel35.setBounds(jPanel35.getX()+1,jPanel35.getY(),jPanel35.getWidth(),jPanel35.getHeight());
                        
                        i++;
                        Thread.sleep(1);
                    }
                       
                }
                catch(Exception ex)
                {
                   JOptionPane.showMessageDialog(null,ex);
                }
            }
            
        };th.start();
    }//GEN-LAST:event_jPanel88MouseEntered

    private void jPanel88MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel88MouseExited
        // TODO add your handling code here:
        jPanel52.setBorder(BorderFactory.createMatteBorder(0,0,0,0,new java.awt.Color(0, 0, 0, 255)));
     
     //System.out.println("p2  "+path_suggestme);
      Thread th1=new Thread()
      {
          @Override
          public void run()
          {
              int i=0;
              String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel68.getText()+".png";
              try
              {
                  while(i<30)
                  {
                      jLabel68.setBounds(jLabel68.getX()-1,jLabel68.getY(), jLabel68.getWidth()-1, jLabel68.getHeight()-1);
                      jLabel68.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel68.getWidth()-1, jLabel68.getHeight()-1, Image.SCALE_DEFAULT)));
                      //jLabel68.setBounds(jLabel68.getX()-1,jLabel68.getY(), jLabel68.getWidth()-1, jLabel68.getHeight()-1);
                     jLabel69.setBounds(jLabel69.getX()-2,jLabel69.getY(),jLabel69.getWidth(),jLabel69.getHeight());
                      jLabel70.setBounds(jLabel70.getX()-2,jLabel70.getY(),jLabel70.getWidth(),jLabel70.getHeight());
                      jPanel52.setBounds(jPanel52.getX(), jPanel52.getY(), jPanel52.getWidth(), jPanel52.getHeight()-1);
                      jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()-30,jLabel51.getHeight()-1);
                      i++;
                      Thread.sleep(1);
                  }
                     
              }
              catch(Exception ex)
              {
                 JOptionPane.showMessageDialog(null,ex);
              }
          }
          
      };th1.start();
     
      playbutton_exit();
    }//GEN-LAST:event_jPanel88MouseExited

    private void jPanel89MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel89MouseEntered
        // TODO add your handling code here:
        jPanel35.setVisible(true);
        jPanel53.setBorder(BorderFactory.createMatteBorder(0,0,0,1,new java.awt.Color(250, 204, 0, 255)));
        String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel71.getText()+".png";
        jLabel51.setBounds(jPanel53.getX(),jPanel53.getY(),0,220);
         System.out.println("p1  "+path_suggestme);
        Thread th=new Thread()
        {
            @Override
            public void run()
            {
                int i=0;
                try
                {
                    jPanel35.setBounds(jPanel53.getX()+873,jPanel53.getY(),40,190);
                    while(i<30)
                    {
                        jLabel71.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel71.getWidth()+1, jLabel71.getHeight()+1, Image.SCALE_DEFAULT)));
                        jLabel71.setBounds(jLabel71.getX()+1,jLabel71.getY(), jLabel71.getWidth()+1, jLabel71.getHeight()+1);
                        jLabel72.setBounds(jLabel72.getX()+2,jLabel72.getY(),jLabel72.getWidth(),jLabel72.getHeight());
                        jPanel53.setBounds(jPanel53.getX(), jPanel53.getY(), jPanel53.getWidth(), jPanel53.getHeight()+1);
                        jLabel73.setBounds(jLabel73.getX()+2,jLabel73.getY(),jLabel73.getWidth(),jLabel73.getHeight());
                        jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()+30,jLabel51.getHeight()+1);
                        jPanel35.setBounds(jPanel35.getX()+1,jPanel35.getY(),jPanel35.getWidth(),jPanel35.getHeight());
                        
                        i++;
                        Thread.sleep(1);
                    }
                       
                }
                catch(Exception ex)
                {
                   JOptionPane.showMessageDialog(null,ex);
                }
            }
            
        };th.start();
    }//GEN-LAST:event_jPanel89MouseEntered

    private void jPanel89MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel89MouseExited
        // TODO add your handling code here:
        jPanel53.setBorder(BorderFactory.createMatteBorder(0,0,0,0,new java.awt.Color(0, 0, 0, 255)));
     
     //System.out.println("p2  "+path_suggestme);
      Thread th1=new Thread()
      {
          @Override
          public void run()
          {
              int i=0;
              String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel71.getText()+".png";
              try
              {
                  while(i<30)
                  {
                      jLabel71.setBounds(jLabel71.getX()-1,jLabel71.getY(), jLabel71.getWidth()-1, jLabel71.getHeight()-1);
                      jLabel71.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel71.getWidth()-1, jLabel71.getHeight()-1, Image.SCALE_DEFAULT)));
                      //jLabel71.setBounds(jLabel71.getX()-1,jLabel71.getY(), jLabel71.getWidth()-1, jLabel71.getHeight()-1);
                      jLabel72.setBounds(jLabel72.getX()-2,jLabel72.getY(),jLabel72.getWidth(),jLabel72.getHeight());
                      jLabel73.setBounds(jLabel73.getX()-2,jLabel73.getY(),jLabel73.getWidth(),jLabel73.getHeight());
                      jPanel53.setBounds(jPanel53.getX(), jPanel53.getY(), jPanel53.getWidth(), jPanel53.getHeight()-1);
                      jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()-30,jLabel51.getHeight()-1);
                      i++;
                      Thread.sleep(1);
                  }
                     
              }
              catch(Exception ex)
              {
                 JOptionPane.showMessageDialog(null,ex);
              }
          }
          
      };th1.start();
     
      playbutton_exit();
    }//GEN-LAST:event_jPanel89MouseExited

    private void jPanel90MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel90MouseEntered
        // TODO add your handling code here:
        jPanel35.setVisible(true);
        jPanel31.setBorder(BorderFactory.createMatteBorder(0,0,0,1,new java.awt.Color(250, 204, 0, 255)));
        String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel49.getText()+".png";
        jLabel51.setBounds(jPanel31.getX(),jPanel31.getY(),0,220);
         System.out.println("p1  "+path_suggestme);
        Thread th=new Thread()
        {
            @Override
            public void run()
            {
                int i=0;
                try
                {
                    jPanel35.setBounds(jPanel31.getX()+873,jPanel31.getY(),40,190);
                    while(i<30)
                    {
                        jLabel49.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel49.getWidth()+1, jLabel49.getHeight()+1, Image.SCALE_DEFAULT)));
                        jLabel49.setBounds(jLabel49.getX()+1,jLabel49.getY(), jLabel49.getWidth()+1, jLabel49.getHeight()+1);
                        jLabel50.setBounds(jLabel50.getX()+2,jLabel50.getY(),jLabel50.getWidth(),jLabel50.getHeight());
                        jPanel31.setBounds(jPanel31.getX(), jPanel31.getY(), jPanel31.getWidth(), jPanel31.getHeight()+1);
                        jLabel52.setBounds(jLabel52.getX()+2,jLabel52.getY(),jLabel52.getWidth(),jLabel52.getHeight());
                        jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()+30,jLabel51.getHeight()+1);
                        jPanel35.setBounds(jPanel35.getX()+1,jPanel35.getY(),jPanel35.getWidth(),jPanel35.getHeight());
                        
                        i++;
                        Thread.sleep(1);
                    }
                       
                }
                catch(Exception ex)
                {
                   JOptionPane.showMessageDialog(null,ex);
                }
            }
            
        };th.start();

    }//GEN-LAST:event_jPanel90MouseEntered

    private void jPanel90MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel90MouseExited
        // TODO add your handling code here:
        jPanel31.setBorder(BorderFactory.createMatteBorder(0,0,0,0,new java.awt.Color(0, 0, 0, 255)));
     
     //System.out.println("p2  "+path_suggestme);
      Thread th1=new Thread()
      {
          @Override
          public void run()
          {
              int i=0;
              String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+jLabel49.getText()+".png";
              try
              {
                  while(i<30)
                  {
                      jLabel49.setBounds(jLabel49.getX()-1,jLabel49.getY(), jLabel49.getWidth()-1, jLabel49.getHeight()-1);
                      jLabel49.setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(jLabel49.getWidth()-1, jLabel49.getHeight()-1, Image.SCALE_DEFAULT)));
                      //jLabel49.setBounds(jLabel49.getX()-1,jLabel49.getY(), jLabel49.getWidth()-1, jLabel49.getHeight()-1);
                     jLabel50.setBounds(jLabel50.getX()-2,jLabel50.getY(),jLabel50.getWidth(),jLabel50.getHeight());
                     jLabel52.setBounds(jLabel52.getX()-2,jLabel52.getY(),jLabel52.getWidth(),jLabel52.getHeight());
                      jPanel31.setBounds(jPanel31.getX(), jPanel31.getY(), jPanel31.getWidth(), jPanel31.getHeight()-1);
                      jLabel51.setBounds(jLabel51.getX(),jLabel51.getY(),jLabel51.getWidth()-30,jLabel51.getHeight()-1);
                      i++;
                      Thread.sleep(1);
                  }
                     
              }
              catch(Exception ex)
              {
                 JOptionPane.showMessageDialog(null,ex);
              }
          }
          
      };th1.start();
     
      playbutton_exit();
    }//GEN-LAST:event_jPanel90MouseExited

    private void jPanel92MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel92MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel92MouseEntered

    private void jPanel92MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel92MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel92MouseExited

    private void jLabel74MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel74MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel74MouseEntered

    private void jPanel93MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel93MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel93MouseEntered

    private void jPanel93MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel93MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel93MouseExited

    private void jPanel94MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel94MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel94MouseEntered

    private void jPanel94MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel94MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel94MouseExited

    private void jLabel77MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel77MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel77MouseEntered

    private void jPanel95MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel95MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel95MouseEntered

    private void jPanel95MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel95MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel95MouseExited

    private void jPanel96MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel96MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel96MouseEntered

    private void jPanel96MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel96MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel96MouseExited

    private void jLabel80MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel80MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel80MouseEntered

    private void jPanel97MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel97MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel97MouseEntered

    private void jPanel97MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel97MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel97MouseExited

    private void jPanel98MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel98MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel98MouseEntered

    private void jPanel98MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel98MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel98MouseExited

    private void jLabel83MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel83MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel83MouseEntered

    private void jPanel99MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel99MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel99MouseEntered

    private void jPanel99MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel99MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel99MouseExited

    private void jPanel100MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel100MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel100MouseEntered

    private void jPanel100MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel100MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel100MouseExited

    private void jLabel86MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel86MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel86MouseEntered

    private void jPanel101MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel101MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel101MouseEntered

    private void jPanel101MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel101MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel101MouseExited

    private void jPanel102MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel102MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel102MouseEntered

    private void jPanel102MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel102MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel102MouseExited

    private void jLabel89MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel89MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel89MouseEntered

    private void jPanel103MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel103MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel103MouseEntered

    private void jPanel103MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel103MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel103MouseExited

    private void jPanel104MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel104MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel104MouseEntered

    private void jPanel104MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel104MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel104MouseExited

    private void jLabel92MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel92MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel92MouseEntered

    private void jPanel105MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel105MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel105MouseEntered

    private void jPanel105MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel105MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel105MouseExited

    private void jPanel106MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel106MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel106MouseEntered

    private void jPanel106MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel106MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel106MouseExited

    private void jLabel95MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel95MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel95MouseEntered

    private void jLabel96MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel96MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel96MouseEntered

    private void jPanel107MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel107MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel107MouseEntered

    private void jPanel107MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel107MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel107MouseExited

    private void jButton222ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton222ActionPerformed
        // TODO add your handling code here:
        search.setVisible(false);
            jButton6.setVisible(false);
          jPanel91.setVisible(true);
         jPanel40.removeAll();
          jButton27.setForeground(Color.white);
        //jButton26.setForeground(Color.white);
        jButton28.setForeground(Color.white);
        jPanel40.repaint();
        jPanel40.revalidate();

        jPanel40.add(jPanel91);
       jPanel40.repaint();
        jPanel40.revalidate();
         jPanel9.setBounds(1680, 80, 230, 310);
            jPanel9.setVisible(false);
        
        
        jButton2.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton1.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
          jButton3.setBorder(BorderFactory.createMatteBorder(0, 2, 0, 2, Color.red));
          jButton4.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
         jButton5.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.red));
          jButton222.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.red));
    }//GEN-LAST:event_jButton222ActionPerformed
public void trendingnow_on(Rectangle r)
{
    JButton dif[]=new JButton[11];
    dif[0]=jButton248;
    dif[1]=jButton249;
    dif[2]=jButton250;
    dif[3]=jButton251;
    dif[4]=jButton252;
    dif[5]=jButton255;
    dif[6]=jButton256;
    dif[7]=jButton257;
    dif[8]=jButton258;
    dif[9]=jButton259;
    
   int i=0;
    
    for(i=0;i<10;i++)
    {
        if(dif[i].getBounds().equals(r))
        {
            if(i>=0 && i<5)
            {
                 System.out.println("this is i value"+i);
                dell=i;
                System.out.println("this is dell value"+dell);
                 String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+dif[dell].getName()+".png";
                
              
                Thread th= new Thread()
                {
                    @Override
                    public void run()
                    {
                        
                        try
                        {
                            System.out.println("this is  value"+dell);
                            int rep=0;
                            while(rep<30)
                            {
                                for(int zx=0;zx<dell;zx++)
                                {
                                    dif[zx].setBounds(dif[zx].getX()-1,dif[zx].getY(),dif[zx].getWidth(),dif[zx].getHeight());
                                }
                                for(int zx=4;zx>dell;zx--)
                                {
                                     System.out.println("this is dell sgh value"+dell);
                                    dif[zx].setBounds(dif[zx].getX()+1,dif[zx].getY(),dif[zx].getWidth(),dif[zx].getHeight());
                                }
                                dif[dell].setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(dif[dell].getWidth()+1, dif[dell].getHeight()+1, Image.SCALE_DEFAULT)));
                                dif[dell].setBounds(dif[dell].getX(),dif[dell].getY(),dif[dell].getWidth()+1,dif[dell].getHeight()+1);
                                rep++;
                                Thread.sleep(1);
                            }
                        }
                        catch(Exception ex)
                        {
                            JOptionPane.showMessageDialog(null,"u have an error sir"); 
                        }
                    }
                 
                };th.start();
            }
            else
            {
                 dell=i;
                  System.out.println("this is dell342 value"+dell);
                 String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+dif[dell].getName()+".png";
                Thread th1=new Thread()
                {
                    @Override
                    public void run()
                    {
                        
                        try
                        {
                            int rep=0;
                            while(rep<30)
                            {
                                for(int zx=5;zx<dell;zx++)
                                {
                                    dif[zx].setBounds(dif[zx].getX()-1,dif[zx].getY(),dif[zx].getWidth(),dif[zx].getHeight());
                                }
                                for(int zx=9;zx>dell;zx--)
                                {
                                    dif[zx].setBounds(dif[zx].getX()+1,dif[zx].getY(),dif[zx].getWidth(),dif[zx].getHeight());
                                }
                                dif[dell].setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(dif[dell].getWidth()+1, dif[dell].getHeight()+1, Image.SCALE_DEFAULT)));
                                dif[dell].setBounds(dif[dell].getX(),dif[dell].getY(),dif[dell].getWidth()+1,dif[dell].getHeight()+1);
                                rep++;
                                Thread.sleep(1);
                            }
                        }
                        catch(Exception ex)
                        {
                            JOptionPane.showMessageDialog(null,"u have an error sir"); 
                        }
                    }
                };th1.start();
            }
        }
    }
    
}
public void trendingnow_exit(Rectangle r)
{
    JButton dif[]=new JButton[11];
    dif[0]=jButton248;
    dif[1]=jButton249;
    dif[2]=jButton250;
    dif[3]=jButton251;
    dif[4]=jButton252;
    dif[5]=jButton255;
    dif[6]=jButton256;
    dif[7]=jButton257;
    dif[8]=jButton258;
    dif[9]=jButton259;
    
    int i=0;
    
    for(i=0;i<10;i++)
    {
        if(dif[i].getBounds().equals(r))
        {
            if(i>=0 && i<6)
            {
               
                dell=i;
                 String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+dif[dell].getName()+".png";
                Thread th=new Thread()
                {
                    @Override
                    public void run()
                    {
                        
                        try
                        {
                            int rep=0;
                            while(rep<30)
                            {
                                for(int zx=0;zx<dell;zx++)
                                {
                                    dif[zx].setBounds(dif[zx].getX()+1,dif[zx].getY(),dif[zx].getWidth(),dif[zx].getHeight());
                                }
                                for(int zx=4;zx>dell;zx--)
                                {
                                    dif[zx].setBounds(dif[zx].getX()-1,dif[zx].getY(),dif[zx].getWidth(),dif[zx].getHeight());
                                }
                                dif[dell].setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(dif[dell].getWidth()-1, dif[dell].getHeight()-1, Image.SCALE_DEFAULT)));
                                dif[dell].setBounds(dif[dell].getX(),dif[dell].getY(),dif[dell].getWidth()-1,dif[dell].getHeight()-1);
                                rep++;
                                Thread.sleep(1);
                            }
                        }
                        catch(Exception ex)
                        {
                            JOptionPane.showMessageDialog(null,"u have an error sir"); 
                        }
                    }
                };th.start();
            }
            else
            {
                 dell=i;
                 String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+dif[dell].getName()+".png";
                Thread th=new Thread()
                {
                    @Override
                    public void run()
                    {
                        
                        try
                        {
                            int rep=0;
                            while(rep<30)
                            {
                                for(int zx=5;zx<dell;zx++)
                                {
                                    dif[zx].setBounds(dif[zx].getX()+1,dif[zx].getY(),dif[zx].getWidth(),dif[zx].getHeight());
                                }
                                for(int zx=9;zx>dell;zx--)
                                {
                                    dif[zx].setBounds(dif[zx].getX()-1,dif[zx].getY(),dif[zx].getWidth(),dif[zx].getHeight());
                                }
                                dif[dell].setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(dif[dell].getWidth()-1, dif[dell].getHeight()-1, Image.SCALE_DEFAULT)));
                                dif[dell].setBounds(dif[dell].getX(),dif[dell].getY(),dif[dell].getWidth()-1,dif[dell].getHeight()-1);
                                rep++;
                                Thread.sleep(1);
                            }
                        }
                        catch(Exception ex)
                        {
                            JOptionPane.showMessageDialog(null,"u have an error sir"); 
                        }
                    }
                };th.start();
            }
        }
    }
    
}
static int dell;
public void detective_on(Rectangle r)
{
    int mg=0;
    //jPanel19.setOpaque(false);
    JButton dif[]=new JButton[11];
    
    if(jButton241.isEnabled())
    {
        dif[0]=jButton236;
        dif[1]=jButton237;
        dif[2]=jButton238;
        dif[3]=jButton239;
        dif[4]=jButton240;
        Thread tm=new Thread()
        {
            @Override
            public void run()
            {
                try
                {
                    Thread.sleep(1000);
                    detective_on_check(dif,0,5,1,r);
                }
                catch(Exception ex)
                {
                    
                }
            }
        };tm.start();
        
    }
    else
    {
        dif[0]=jButton243;
        dif[1]=jButton244;
        dif[2]=jButton245;
        dif[3]=jButton246;
        dif[4]=jButton247;
        Thread tm=new Thread()
        {
            @Override
            public void run()
            {
                try
                {
                    Thread.sleep(1000);
                    detective_on_check(dif,0,5,1,r);
                }
                catch(Exception ex)
                {
                    
                }
            }
        };tm.start();
    }
    
}
public void detective_off(Rectangle r)
{
    JButton dif[]=new JButton[11];
    
    if(jButton241.isEnabled())
    {
        dif[0]=jButton236;
        dif[1]=jButton237;
        dif[2]=jButton238;
        dif[3]=jButton239;
        dif[4]=jButton240;
        Thread tm=new Thread()
        {
            @Override
            public void run()
            {
                try
                {
                    Thread.sleep(1000);
                    detective_on_check(dif,0,5,0,r);
                }
                catch(Exception ex)
                {
                    
                }
            }
        };tm.start();
    }
    else
    {
        dif[0]=jButton243;
        dif[1]=jButton244;
        dif[2]=jButton245;
        dif[3]=jButton246;
        dif[4]=jButton247;
        Thread tm=new Thread()
        {
            @Override
            public void run()
            {
                try
                {
                    Thread.sleep(1000);
                    detective_on_check(dif,0,5,0,r);
                }
                catch(Exception ex)
                {
                    
                }
            }
        };tm.start();
    }
    
}
public boolean detective_on_check(JButton dif[],int start,int end,int state,Rectangle r)
{
   final int value;
    int i=0;
    if(state==1)
    {
        value=1;
    }
    else
    {
        value=-1;
    }
      for(i=0;i<5;i++)
    {
        if(dif[i].getBounds().equals(r))
        {
           
                 System.out.println("this is i value"+i);
                dell=i;
                System.out.println("this is dell value"+dell);
                 String path_suggestme="C://Users//dines//Desktop//se7en//originals//"+dif[dell].getName()+".png";
                System.out.println("this is  value"+dell);
              
                Thread th= new Thread()
                {
                    @Override
                    public void run()
                    {
                        System.out.println("this is  value"+dell);
                        try
                        {
                            
                            int rep=0;
                            while(rep<30)
                            {
                                Thread.sleep(1);
                                for(int zx=0;zx<dell;zx++)
                                {
                                    dif[zx].setBounds(dif[zx].getX()-value,dif[zx].getY(),dif[zx].getWidth(),dif[zx].getHeight());
                                }
                                for(int zx=4;zx>dell;zx--)
                                {
                                     //System.out.println("this is dell sgh value"+dell);
                                    dif[zx].setBounds(dif[zx].getX()+value,dif[zx].getY(),dif[zx].getWidth(),dif[zx].getHeight());
                                }
                                dif[dell].setIcon(new ImageIcon(new ImageIcon(path_suggestme).getImage().getScaledInstance(dif[dell].getWidth()+value, dif[dell].getHeight()+value, Image.SCALE_DEFAULT)));
                                dif[dell].setBounds(dif[dell].getX(),dif[dell].getY(),dif[dell].getWidth()+value,dif[dell].getHeight()+value);
                                rep++;
                                
                                
                            }
                           //return 1; 
                        }
                        catch(Exception ex)
                        {
                            JOptionPane.showMessageDialog(null,"u have an error sir"); 
                        }
                    }
                 
                };th.start();
            
       
        }
    }
      return true;
}
    private void jButton250MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton250MouseEntered
        // TODO add your handling code here:
        Rectangle r=jButton250.getBounds();
        trendingnow_on(r);
    }//GEN-LAST:event_jButton250MouseEntered

    private void jButton250MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton250MouseExited
        // TODO add your handling code here:
         Rectangle r=jButton250.getBounds();
       trendingnow_exit(r);
    }//GEN-LAST:event_jButton250MouseExited

    private void jButton249MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton249MouseEntered
        // TODO add your handling code here:
        Rectangle r=jButton249.getBounds();
        trendingnow_on(r);
    }//GEN-LAST:event_jButton249MouseEntered

    private void jButton249MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton249MouseExited
        // TODO add your handling code here:
         Rectangle r=jButton249.getBounds();
        trendingnow_on(r);
    }//GEN-LAST:event_jButton249MouseExited

    private void jButton238ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton238ActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_jButton238ActionPerformed

    private void jButton238MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton238MouseEntered
        // TODO add your handling code here:
         Rectangle r=jButton238.getBounds(shift);
        detective_on(r);
    }//GEN-LAST:event_jButton238MouseEntered

    private void jButton238MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton238MouseExited
        // TODO add your handling code here:
        Rectangle r=jButton238.getBounds();
        detective_off(r);
    }//GEN-LAST:event_jButton238MouseExited

    private void jButton237MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton237MouseEntered
        // TODO add your handling code here:
          Rectangle r=jButton237.getBounds();
        detective_on(r);
    }//GEN-LAST:event_jButton237MouseEntered

    private void jButton239MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton239MouseEntered
        // TODO add your handling code here:
        Rectangle r=jButton239.getBounds();
        detective_on(r);
    }//GEN-LAST:event_jButton239MouseEntered

    private void jButton240MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton240MouseEntered
        // TODO add your handling code here:
        Rectangle r=jButton240.getBounds();
        detective_on(r);
    }//GEN-LAST:event_jButton240MouseEntered

    private void jButton244MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton244MouseEntered
        // TODO add your handling code here:
        Rectangle r=jButton244.getBounds();
        detective_on(r);
    }//GEN-LAST:event_jButton244MouseEntered

    private void jButton245MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton245MouseEntered
        // TODO add your handling code here:
        Rectangle r=jButton245.getBounds();
        detective_on(r);
    }//GEN-LAST:event_jButton245MouseEntered

    private void jButton246MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton246MouseEntered
        // TODO add your handling code here:
        Rectangle r=jButton246.getBounds();
        detective_on(r);
    }//GEN-LAST:event_jButton246MouseEntered

    private void jButton247MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton247MouseEntered
        // TODO add your handling code here:
        Rectangle r=jButton247.getBounds();
        detective_on(r);
    }//GEN-LAST:event_jButton247MouseEntered

    private void jButton243MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton243MouseExited
        // TODO add your handling code here:
        Rectangle r=jButton243.getBounds();
        detective_off(r);
    }//GEN-LAST:event_jButton243MouseExited

    private void jButton244MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton244MouseExited
        // TODO add your handling code here:
          Rectangle r=jButton244.getBounds();
        detective_off(r);
    }//GEN-LAST:event_jButton244MouseExited

    private void jButton245MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton245MouseExited
        // TODO add your handling code here:
          Rectangle r=jButton245.getBounds();
        detective_off(r);
    }//GEN-LAST:event_jButton245MouseExited

    private void jButton246MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton246MouseExited
        // TODO add your handling code here:
          Rectangle r=jButton46.getBounds();
        detective_off(r);
    }//GEN-LAST:event_jButton246MouseExited

    private void jButton247MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton247MouseExited
        // TODO add your handling code here:
          Rectangle r=jButton247.getBounds();
        detective_off(r);
    }//GEN-LAST:event_jButton247MouseExited

    private void jButton236MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton236MouseExited
        // TODO add your handling code here:
          Rectangle r=jButton236.getBounds();
        detective_off(r);
    }//GEN-LAST:event_jButton236MouseExited

    private void jButton237MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton237MouseExited
        // TODO add your handling code here:
          Rectangle r=jButton237.getBounds();
        detective_off(r);
    }//GEN-LAST:event_jButton237MouseExited

    private void jButton239MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton239MouseExited
        // TODO add your handling code here:
          Rectangle r=jButton239.getBounds();
        detective_off(r);
    }//GEN-LAST:event_jButton239MouseExited

    private void jButton240MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton240MouseExited
        // TODO add your handling code here:
          Rectangle r=jButton240.getBounds();
        detective_off(r);
    }//GEN-LAST:event_jButton240MouseExited

    private void jButton320ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton320ActionPerformed
        // TODO add your handling code here:
        Desktop d=Desktop.getDesktop();
        try
        {
            d.browse(new URI("https://www.youtube.com/watch?v=jeiuLjLyjIc"));
        }
        catch(Exception ex)
        {
            
        }
        
    }//GEN-LAST:event_jButton320ActionPerformed

    private void jButton321ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton321ActionPerformed
        // TODO add your handling code here:
        Desktop d=Desktop.getDesktop();
        try
        {
            d.browse(new URI("https://www.youtube.com/watch?v=atHBOUvgBI8"));
        }
        catch(Exception ex)
        {
            
        }
    }//GEN-LAST:event_jButton321ActionPerformed

    private void jButton322ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton322ActionPerformed
        // TODO add your handling code here:
           Desktop d=Desktop.getDesktop();
        try
        {
            d.browse(new URI("https://www.youtube.com/watch?v=OP4VYnQ5q3Q"));
        }
        catch(Exception ex)
        {
            
        }
    }//GEN-LAST:event_jButton322ActionPerformed

    private void jButton323ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton323ActionPerformed
        // TODO add your handling code here:
              Desktop d=Desktop.getDesktop();
        try
        {
            d.browse(new URI("https://www.youtube.com/watch?v=u2ncERi6TgU"));
        }
        catch(Exception ex)
        {
            
        }
    }//GEN-LAST:event_jButton323ActionPerformed

    private void jButton324ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton324ActionPerformed
        // TODO add your handling code here:
                Desktop d=Desktop.getDesktop();
        try
        {
            d.browse(new URI("https://www.youtube.com/watch?v=wlVAQMB7TDY"));
        }
        catch(Exception ex)
        {
            
        }
        
    }//GEN-LAST:event_jButton324ActionPerformed

    private void jButton325ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton325ActionPerformed
        // TODO add your handling code here:
                Desktop d=Desktop.getDesktop();
        try
        {
            d.browse(new URI("https://www.youtube.com/watch?v=Jq0hwEXhnJ0"));
        }
        catch(Exception ex)
        {
            
        }
        
    }//GEN-LAST:event_jButton325ActionPerformed

    private void jButton326ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton326ActionPerformed
        // TODO add your handling code here:
                 Desktop d=Desktop.getDesktop();
        try
        {
            d.browse(new URI("https://www.youtube.com/watch?v=tg52up16eq0"));
        }
        catch(Exception ex)
        {
            
        }
    }//GEN-LAST:event_jButton326ActionPerformed

    private void jButton327ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton327ActionPerformed
        // TODO add your handling code here:
                     Desktop d=Desktop.getDesktop();
        try
        {
            d.browse(new URI("https://www.youtube.com/watch?v=USPd0vX2sdc"));
        }
        catch(Exception ex)
        {
            
        }
    }//GEN-LAST:event_jButton327ActionPerformed
public void watch_list()
{
  JButton [] but=new JButton[25];
        but[0]=jButton68;
        but[1]=jButton69;
        but[2]=jButton70;
        but[3]=jButton71;
        but[4]=jButton72;
        but[5]=jButton78;
        but[6]=jButton84;
        but[7]=jButton87;
        but[8]=jButton88;
        but[9]=jButton89;
        but[10]=jButton90;
        but[11]=jButton96;
        but[12]=jButton98;
        but[13]=jButton99;
        but[14]=jButton100;
        but[15]=jButton101;
        but[16]=jButton102;
        but[17]=jButton103;
        but[18]=jButton104;
        but[19]=jButton105;
      
        
            try
            {
                String sql="select * from my_list where flick='"+movie+"'";
                ResultSet res=stmt.executeQuery(sql);
                if(res.next())
                {
                }
                else{
                 
                            sql="select genre from movies where movie_name='"+movie+"' limit 1";
                            res=stmt.executeQuery(sql);
                            if(res.next())
                            {
                                String gend=res.getString("genre");
                                String u=jLabel16.getText();
                                String chim="movie";
                                try{sql="insert into my_list(flick,genre,users,type) values('"+movie+"','"+gend+"','"+u+"','"+chim+"')";stmt.executeUpdate(sql);}
                                catch(Exception ex){JOptionPane.showMessageDialog(this,"hi ra mammaaaa");}
                                       
                                    for(int i=18;i>=0;i--)
                                    {
                                        Icon ic=but[i].getIcon();
                                        
                                        but[i+1].setIcon(ic);
                                        but[i+1].setText(but[i].getText());
                                    }
                                       String loc="C://Users//dines//Desktop//se7en//originals//";
                                                loc=loc+movie+".png";
                                                but[0].setIcon(new ImageIcon(loc));
                                                but[0].setText(movie);
                                                but[ram].setVisible(true);
                                                ram++;
                                                for(int i=ram;i<20;i++)
                                                {
                                                    but[i].setVisible(false);
                                                }
                                    
                            }
                    
                }
             }
            catch(Exception ex)
            {
                  JOptionPane.showMessageDialog(this,"u have an error sir");       
            }
          
}
public void watch_list1()
{
     JButton [] but=new JButton[25];
        but[0]=jButton68;
        but[1]=jButton69;
        but[2]=jButton70;
        but[3]=jButton71;
        but[4]=jButton72;
        but[5]=jButton78;
        but[6]=jButton84;
        but[7]=jButton87;
        but[8]=jButton88;
        but[9]=jButton89;
        but[10]=jButton90;
        but[11]=jButton96;
        but[12]=jButton98;
        but[13]=jButton99;
        but[14]=jButton100;
        but[15]=jButton101;
        but[16]=jButton102;
        but[17]=jButton103;
        but[18]=jButton104;
        but[19]=jButton105;
      
        
            try
            {
                String sql="select * from my_list where flick='"+show+"'";
                ResultSet res=stmt.executeQuery(sql);
                if(res.next())
                {}
                else{
                 
                            sql="select genre from tv_shows where show_name REGEXP '"+show+"' limit 1";
                            res=stmt.executeQuery(sql);
                            if(res.next())
                            {
                                String gend=res.getString("genre");
                                String u=jLabel16.getText();
                                String chim="show";
                                sql="insert into my_list(flick,genre,users,type) values('"+show+"','"+gend+"','"+u+"','"+chim+"')";
                                       stmt.executeUpdate(sql);
                                    for(int i=18;i>=0;i--)
                                    {
                                        Icon ic=but[i].getIcon();
                                        
                                        but[i+1].setIcon(ic);
                                        but[i+1].setText(but[i].getText());
                                    }
                                    String temp[]=show.split(" [0-9]$");
                                       String loc="C://Users//dines//Desktop//se7en//originals//";
                                                loc=loc+temp[0]+".png";
                                                but[0].setIcon(new ImageIcon(loc));
                                                but[0].setText(show);
                                                but[ram].setVisible(true);
                                                ram++;
                                                for(int i=ram;i<20;i++)
                                                {
                                                    but[i].setVisible(false);
                                                }
                                    
                            }
                    
                }
             }
            catch(Exception ex)
            {
                  JOptionPane.showMessageDialog(this,"1.......");       
            } 
}
public  void fav_list()
{
    System.out.println("hello mama");
    JButton [] but=new JButton[25];
        but[0]=jButton223;
        but[1]=jButton296;
        but[2]=jButton297;
        but[3]=jButton298;
        but[4]=jButton299;
        but[5]=jButton300;
        but[6]=jButton306;
        but[7]=jButton307;
        but[8]=jButton308;
        but[9]=jButton309;
        but[10]=jButton310;
        but[11]=jButton311;
        but[12]=jButton312;
        but[13]=jButton313;
        but[14]=jButton314;
        but[15]=jButton315;
        but[16]=jButton316;
        but[17]=jButton317;
        but[18]=jButton318;
        but[19]=jButton319;
      
        String sql;
        ResultSet res;
        try
        {
            sql="select * from movies where movie_name='"+movie+"'";
            res=stmt.executeQuery(sql);
            if(res.next())
            {
                for(int i=18;i>=0;i--)
                {
                    but[i+1].setIcon(but[i].getIcon());
                    but[i+1].setText(but[i].getText());
                }
                String ramadasu="C://Users//dines//Desktop//se7en//originals//"+movie+".png";
                but[0].setIcon(new ImageIcon(ramadasu));
                but[0].setText(movie);
                movie="";
                jPanel30.setVisible(false);
            }
            else
            {
                sql="select * from tv_shows where show_name='"+show+"'";
                res=stmt.executeQuery(sql);
                if(res.next())
                {
                    for(int i=18;i>=0;i--)
                    {
                         but[i+1].setIcon(but[i].getIcon());
                         but[i+1].setText(but[i].getText());
                    }
                         String ramadasu="C://Users//dines//Desktop//se7en//originals//"+movie+".png";
                         but[0].setIcon(new ImageIcon(ramadasu));
                         but[0].setText(show);
                         System.out.println("---------"+show);
                }
            }
        }
        catch(Exception ex)
        {
             JOptionPane.showMessageDialog(this,"Error at My fav panel");
        }
        
      
}
    /**
     * @param args the command line arguments
     */
   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(index.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(index.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(index.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(index.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
       
          
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new index().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton action_btn1;
    private javax.swing.JButton action_btn2;
    private javax.swing.JPanel action_panel;
    private javax.swing.JPanel comedy_show;
    private javax.swing.JPanel crime_show;
    private javax.swing.JButton drama_btn1;
    private javax.swing.JButton drama_btn2;
    private javax.swing.JPanel drama_panel;
    private javax.swing.JPanel drama_show;
    private javax.swing.JButton ep_btn1;
    private javax.swing.JButton ep_btn2;
    private javax.swing.JButton ep_btn3;
    private javax.swing.JButton ep_btn4;
    private javax.swing.JButton ep_btn5;
    private javax.swing.JButton ep_btn6;
    private javax.swing.JButton ep_btn7;
    private javax.swing.JButton ep_btn8;
    private javax.swing.JPanel horror_panel;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton100;
    private javax.swing.JButton jButton101;
    private javax.swing.JButton jButton102;
    private javax.swing.JButton jButton103;
    private javax.swing.JButton jButton104;
    private javax.swing.JButton jButton105;
    private javax.swing.JButton jButton106;
    private javax.swing.JButton jButton107;
    private javax.swing.JButton jButton108;
    private javax.swing.JButton jButton109;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton110;
    private javax.swing.JButton jButton111;
    private javax.swing.JButton jButton112;
    private javax.swing.JButton jButton113;
    private javax.swing.JButton jButton114;
    private javax.swing.JButton jButton115;
    private javax.swing.JButton jButton116;
    private javax.swing.JButton jButton117;
    private javax.swing.JButton jButton118;
    private javax.swing.JButton jButton119;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton120;
    private javax.swing.JButton jButton121;
    private javax.swing.JButton jButton122;
    private javax.swing.JButton jButton123;
    private javax.swing.JButton jButton124;
    private javax.swing.JButton jButton125;
    private javax.swing.JButton jButton126;
    private javax.swing.JButton jButton127;
    private javax.swing.JButton jButton128;
    private javax.swing.JButton jButton129;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton130;
    private javax.swing.JButton jButton131;
    private javax.swing.JButton jButton132;
    private javax.swing.JButton jButton133;
    private javax.swing.JButton jButton134;
    private javax.swing.JButton jButton135;
    private javax.swing.JButton jButton136;
    private javax.swing.JButton jButton137;
    private javax.swing.JButton jButton138;
    private javax.swing.JButton jButton139;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton140;
    private javax.swing.JButton jButton141;
    private javax.swing.JButton jButton142;
    private javax.swing.JButton jButton143;
    private javax.swing.JButton jButton144;
    private javax.swing.JButton jButton145;
    private javax.swing.JButton jButton146;
    private javax.swing.JButton jButton147;
    private javax.swing.JButton jButton148;
    private javax.swing.JButton jButton149;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton150;
    private javax.swing.JButton jButton151;
    private javax.swing.JButton jButton152;
    private javax.swing.JButton jButton153;
    private javax.swing.JButton jButton154;
    private javax.swing.JButton jButton155;
    private javax.swing.JButton jButton156;
    private javax.swing.JButton jButton157;
    private javax.swing.JButton jButton158;
    private javax.swing.JButton jButton159;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton160;
    private javax.swing.JButton jButton161;
    private javax.swing.JButton jButton162;
    private javax.swing.JButton jButton163;
    private javax.swing.JButton jButton164;
    private javax.swing.JButton jButton165;
    private javax.swing.JButton jButton166;
    private javax.swing.JButton jButton167;
    private javax.swing.JButton jButton168;
    private javax.swing.JButton jButton169;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton170;
    private javax.swing.JButton jButton171;
    private javax.swing.JButton jButton172;
    private javax.swing.JButton jButton173;
    private javax.swing.JButton jButton174;
    private javax.swing.JButton jButton175;
    private javax.swing.JButton jButton176;
    private javax.swing.JButton jButton177;
    private javax.swing.JButton jButton178;
    private javax.swing.JButton jButton179;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton180;
    private javax.swing.JButton jButton181;
    private javax.swing.JButton jButton182;
    private javax.swing.JButton jButton183;
    private javax.swing.JButton jButton184;
    private javax.swing.JButton jButton185;
    private javax.swing.JButton jButton186;
    private javax.swing.JButton jButton187;
    private javax.swing.JButton jButton188;
    private javax.swing.JButton jButton189;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton190;
    private javax.swing.JButton jButton191;
    private javax.swing.JButton jButton192;
    private javax.swing.JButton jButton193;
    private javax.swing.JButton jButton194;
    private javax.swing.JButton jButton195;
    private javax.swing.JButton jButton196;
    private javax.swing.JButton jButton197;
    private javax.swing.JButton jButton198;
    private javax.swing.JButton jButton199;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton200;
    private javax.swing.JButton jButton201;
    private javax.swing.JButton jButton202;
    private javax.swing.JButton jButton203;
    private javax.swing.JButton jButton204;
    private javax.swing.JButton jButton205;
    private javax.swing.JButton jButton206;
    private javax.swing.JButton jButton207;
    private javax.swing.JButton jButton208;
    private javax.swing.JButton jButton209;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton210;
    private javax.swing.JButton jButton211;
    private javax.swing.JButton jButton212;
    private javax.swing.JButton jButton213;
    private javax.swing.JButton jButton214;
    private javax.swing.JButton jButton215;
    private javax.swing.JButton jButton216;
    private javax.swing.JButton jButton217;
    private javax.swing.JButton jButton218;
    private javax.swing.JButton jButton219;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton220;
    private javax.swing.JButton jButton221;
    private javax.swing.JButton jButton222;
    private javax.swing.JButton jButton223;
    private javax.swing.JButton jButton224;
    private javax.swing.JButton jButton225;
    private javax.swing.JButton jButton226;
    private javax.swing.JButton jButton227;
    private javax.swing.JButton jButton228;
    private javax.swing.JButton jButton229;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton230;
    private javax.swing.JButton jButton231;
    private javax.swing.JButton jButton232;
    private javax.swing.JButton jButton233;
    private javax.swing.JButton jButton234;
    private javax.swing.JButton jButton235;
    private javax.swing.JButton jButton236;
    private javax.swing.JButton jButton237;
    private javax.swing.JButton jButton238;
    private javax.swing.JButton jButton239;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton240;
    private javax.swing.JButton jButton241;
    private javax.swing.JButton jButton242;
    private javax.swing.JButton jButton243;
    private javax.swing.JButton jButton244;
    private javax.swing.JButton jButton245;
    private javax.swing.JButton jButton246;
    private javax.swing.JButton jButton247;
    private javax.swing.JButton jButton248;
    private javax.swing.JButton jButton249;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton250;
    private javax.swing.JButton jButton251;
    private javax.swing.JButton jButton252;
    private javax.swing.JButton jButton253;
    private javax.swing.JButton jButton254;
    private javax.swing.JButton jButton255;
    private javax.swing.JButton jButton256;
    private javax.swing.JButton jButton257;
    private javax.swing.JButton jButton258;
    private javax.swing.JButton jButton259;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton260;
    private javax.swing.JButton jButton261;
    private javax.swing.JButton jButton262;
    private javax.swing.JButton jButton263;
    private javax.swing.JButton jButton264;
    private javax.swing.JButton jButton265;
    private javax.swing.JButton jButton266;
    private javax.swing.JButton jButton267;
    private javax.swing.JButton jButton268;
    private javax.swing.JButton jButton269;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton270;
    private javax.swing.JButton jButton271;
    private javax.swing.JButton jButton272;
    private javax.swing.JButton jButton273;
    private javax.swing.JButton jButton274;
    private javax.swing.JButton jButton275;
    private javax.swing.JButton jButton276;
    private javax.swing.JButton jButton277;
    private javax.swing.JButton jButton278;
    private javax.swing.JButton jButton279;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton280;
    private javax.swing.JButton jButton281;
    private javax.swing.JButton jButton282;
    private javax.swing.JButton jButton283;
    private javax.swing.JButton jButton284;
    private javax.swing.JButton jButton285;
    private javax.swing.JButton jButton286;
    private javax.swing.JButton jButton287;
    private javax.swing.JButton jButton288;
    private javax.swing.JButton jButton289;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton290;
    private javax.swing.JButton jButton291;
    private javax.swing.JButton jButton292;
    private javax.swing.JButton jButton293;
    private javax.swing.JButton jButton294;
    private javax.swing.JButton jButton295;
    private javax.swing.JButton jButton296;
    private javax.swing.JButton jButton297;
    private javax.swing.JButton jButton298;
    private javax.swing.JButton jButton299;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton300;
    private javax.swing.JButton jButton301;
    private javax.swing.JButton jButton302;
    private javax.swing.JButton jButton303;
    private javax.swing.JButton jButton304;
    private javax.swing.JButton jButton305;
    private javax.swing.JButton jButton306;
    private javax.swing.JButton jButton307;
    private javax.swing.JButton jButton308;
    private javax.swing.JButton jButton309;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton310;
    private javax.swing.JButton jButton311;
    private javax.swing.JButton jButton312;
    private javax.swing.JButton jButton313;
    private javax.swing.JButton jButton314;
    private javax.swing.JButton jButton315;
    private javax.swing.JButton jButton316;
    private javax.swing.JButton jButton317;
    private javax.swing.JButton jButton318;
    private javax.swing.JButton jButton319;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton320;
    private javax.swing.JButton jButton321;
    private javax.swing.JButton jButton322;
    private javax.swing.JButton jButton323;
    private javax.swing.JButton jButton324;
    private javax.swing.JButton jButton325;
    private javax.swing.JButton jButton326;
    private javax.swing.JButton jButton327;
    private javax.swing.JButton jButton33;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton36;
    private javax.swing.JButton jButton37;
    private javax.swing.JButton jButton38;
    private javax.swing.JButton jButton39;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton40;
    private javax.swing.JButton jButton41;
    private javax.swing.JButton jButton42;
    private javax.swing.JButton jButton43;
    private javax.swing.JButton jButton44;
    private javax.swing.JButton jButton45;
    private javax.swing.JButton jButton46;
    private javax.swing.JButton jButton47;
    private javax.swing.JButton jButton48;
    private javax.swing.JButton jButton49;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton50;
    private javax.swing.JButton jButton51;
    private javax.swing.JButton jButton52;
    private javax.swing.JButton jButton53;
    private javax.swing.JButton jButton54;
    private javax.swing.JButton jButton55;
    private javax.swing.JButton jButton56;
    private javax.swing.JButton jButton57;
    private javax.swing.JButton jButton58;
    private javax.swing.JButton jButton59;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton60;
    private javax.swing.JButton jButton61;
    private javax.swing.JButton jButton62;
    private javax.swing.JButton jButton63;
    private javax.swing.JButton jButton64;
    private javax.swing.JButton jButton65;
    private javax.swing.JButton jButton66;
    private javax.swing.JButton jButton67;
    private javax.swing.JButton jButton68;
    private javax.swing.JButton jButton69;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton70;
    private javax.swing.JButton jButton71;
    private javax.swing.JButton jButton72;
    private javax.swing.JButton jButton73;
    private javax.swing.JButton jButton74;
    private javax.swing.JButton jButton75;
    private javax.swing.JButton jButton76;
    private javax.swing.JButton jButton77;
    private javax.swing.JButton jButton78;
    private javax.swing.JButton jButton79;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton80;
    private javax.swing.JButton jButton81;
    private javax.swing.JButton jButton82;
    private javax.swing.JButton jButton83;
    private javax.swing.JButton jButton84;
    private javax.swing.JButton jButton85;
    private javax.swing.JButton jButton86;
    private javax.swing.JButton jButton87;
    private javax.swing.JButton jButton88;
    private javax.swing.JButton jButton89;
    private javax.swing.JButton jButton9;
    private javax.swing.JButton jButton90;
    private javax.swing.JButton jButton91;
    private javax.swing.JButton jButton92;
    private javax.swing.JButton jButton93;
    private javax.swing.JButton jButton94;
    private javax.swing.JButton jButton95;
    private javax.swing.JButton jButton96;
    private javax.swing.JButton jButton97;
    private javax.swing.JButton jButton98;
    private javax.swing.JButton jButton99;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel100;
    private javax.swing.JPanel jPanel101;
    private javax.swing.JPanel jPanel102;
    private javax.swing.JPanel jPanel103;
    private javax.swing.JPanel jPanel104;
    private javax.swing.JPanel jPanel105;
    private javax.swing.JPanel jPanel106;
    private javax.swing.JPanel jPanel107;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel49;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel50;
    private javax.swing.JPanel jPanel51;
    private javax.swing.JPanel jPanel52;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel55;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel jPanel59;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel60;
    private javax.swing.JPanel jPanel61;
    private javax.swing.JPanel jPanel62;
    private javax.swing.JPanel jPanel63;
    private javax.swing.JPanel jPanel64;
    private javax.swing.JPanel jPanel65;
    private javax.swing.JPanel jPanel66;
    private javax.swing.JPanel jPanel67;
    private javax.swing.JPanel jPanel68;
    private javax.swing.JPanel jPanel69;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel70;
    private javax.swing.JPanel jPanel71;
    private javax.swing.JPanel jPanel72;
    private javax.swing.JPanel jPanel73;
    private javax.swing.JPanel jPanel74;
    private javax.swing.JPanel jPanel75;
    private javax.swing.JPanel jPanel76;
    private javax.swing.JPanel jPanel77;
    private javax.swing.JPanel jPanel78;
    private javax.swing.JPanel jPanel79;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel80;
    private javax.swing.JPanel jPanel81;
    private javax.swing.JPanel jPanel82;
    private javax.swing.JPanel jPanel83;
    private javax.swing.JPanel jPanel84;
    private javax.swing.JPanel jPanel85;
    private javax.swing.JPanel jPanel86;
    private javax.swing.JPanel jPanel87;
    private javax.swing.JPanel jPanel88;
    private javax.swing.JPanel jPanel89;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel jPanel90;
    private javax.swing.JPanel jPanel91;
    private javax.swing.JPanel jPanel92;
    private javax.swing.JPanel jPanel93;
    private javax.swing.JPanel jPanel94;
    private javax.swing.JPanel jPanel95;
    private javax.swing.JPanel jPanel96;
    private javax.swing.JPanel jPanel97;
    private javax.swing.JPanel jPanel98;
    private javax.swing.JPanel jPanel99;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JPasswordField jPasswordField2;
    private javax.swing.JPasswordField jPasswordField3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton recom_btn1;
    private javax.swing.JButton recom_btn2;
    private javax.swing.JPanel recom_panel;
    private javax.swing.JPanel recom_show;
    private javax.swing.JButton recomshow_btn1;
    private javax.swing.JButton recomshow_btn2;
    private javax.swing.JButton rom_com_btn1;
    private javax.swing.JButton rom_com_btn2;
    private javax.swing.JPanel rom_com_panel;
    private javax.swing.JButton sarkar;
    private javax.swing.JButton sarkar1;
    private javax.swing.JButton sarkar2;
    private javax.swing.JButton sarkar3;
    private javax.swing.JButton sarkar4;
    private javax.swing.JButton sarkar_add_list8;
    private javax.swing.JButton sarkar_fav8;
    private javax.swing.JButton sarkar_wt8;
    private javax.swing.JButton scifi_btn1;
    private javax.swing.JButton scifi_btn2;
    private javax.swing.JPanel scifi_panel;
    private javax.swing.JPanel scifi_show;
    private javax.swing.JTextField search;
    private javax.swing.JButton search_add_list;
    private javax.swing.JButton search_fav;
    private javax.swing.JButton search_wt;
    private javax.swing.JButton sug1;
    private javax.swing.JButton sug2;
    private javax.swing.JButton sug3;
    private javax.swing.JButton thriller_btn1;
    private javax.swing.JButton thriller_btn2;
    private javax.swing.JPanel thriller_panel;
    private javax.swing.JPanel thriller_show;
    private javax.swing.JButton top10_btn1;
    private javax.swing.JButton top10_btn2;
    private javax.swing.JPanel top10_show;
    // End of variables declaration//GEN-END:variables
}
